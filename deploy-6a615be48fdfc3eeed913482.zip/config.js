/*
  SkillSwape AI public runtime configuration.

  Netlify setup:
  1. Create a Supabase project.
  2. Run supabase/schema.sql in Supabase SQL Editor.
  3. Paste the Project URL and Publishable/anon key below.

  The publishable/anon key is designed for browser apps. Never place a
  service_role key, database password, or payment secret in this file.
*/
window.SKILLSWAPE_CONFIG = {
  supabaseUrl: 'https://jzcmhxpqiqeijhcdjmzt.supabase.co',
  supabaseAnonKey: 'sb_publishable_CBjb-8waH0cTmxrNbfsUFw_SmTaHKVC',
  siteUrl: window.location.origin,
  demoMode: false,
  aiEndpoint: ''
};
