(function () {
  'use strict';
  const chatState = { conversations: [], selected: null, messages: [], filter: 'all', channel: null, typingTimer: null, lastTypingSent: 0, attachmentFile: null, attachmentKind: '', attachmentPreviewUrl: '', sending: false };

  function formatBytes(bytes) {
    const value = Number(bytes || 0);
    if (!value) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    const index = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
    const amount = value / Math.pow(1024, index);
    return (amount >= 10 || index === 0 ? amount.toFixed(0) : amount.toFixed(1)) + ' ' + units[index];
  }

  function fileTypeLabel(kind) {
    return kind === 'photo' ? 'Photo' : kind === 'video' ? 'Video' : 'Document';
  }

  function cloudAvatar(profile, size) {
    profile = profile || {};
    const name = profile.full_name || profile.display_title || 'Member';
    const photo = profile.avatar_url || profile.display_avatar || '';
    return '<div class="avatar ' + (size || 'sm') + '">' + (photo ? '<img src="' + esc(photo) + '" alt="">' : esc(name.charAt(0).toUpperCase())) + '</div>';
  }

  function ownId() { return SkillCloud.state.session && SkillCloud.state.session.user && SkillCloud.state.session.user.id || uid(); }

  async function initChat() {
    if (!SkillCloud.configured) {
      $('conversationListLive').innerHTML = '<div class="cloud-state"><h2>Live setup required</h2><p>' + esc(SkillCloud.setupMessage()) + '</p><a class="btn" href="setup.html">Setup guide</a></div>';
      return;
    }
    try {
      await SkillCloud.requireUser();
      await loadConversations();
      const requestedUser = new URLSearchParams(location.search).get('user');
      const requestedConversation = new URLSearchParams(location.search).get('conversation');
      if (requestedConversation && chatState.conversations.some(function (row) { return row.conversation_id === requestedConversation; })) selectConversation(requestedConversation);
      else if (requestedUser && requestedUser !== ownId()) await startDirect(requestedUser);
      else if (chatState.conversations.length) selectConversation(chatState.conversations[0].conversation_id);
    } catch (error) { $('conversationListLive').innerHTML = '<div class="cloud-state"><h2>Inbox unavailable</h2><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>'; }
  }

  async function loadConversations() {
    chatState.conversations = await SkillCloud.conversations();
    renderConversations();
  }

  window.renderConversations = function () {
    const query = String($('conversationSearch').value || '').trim().toLowerCase();
    const rows = chatState.conversations.filter(function (row) {
      return (chatState.filter === 'all' || row.kind === chatState.filter) && [row.display_title,row.last_message,row.other_headline].join(' ').toLowerCase().includes(query);
    });
    $('conversationListLive').innerHTML = rows.map(function (row) {
      return '<button class="conversation-item ' + (chatState.selected && chatState.selected.conversation_id === row.conversation_id ? 'active' : '') + '" onclick="selectConversation(\'' + row.conversation_id + '\')">' + cloudAvatar(row, 'sm') + '<span class="conversation-item-copy"><b>' + esc(row.display_title || 'Conversation') + '</b><p>' + esc(row.last_message || 'No messages yet') + '</p></span>' + (Number(row.unread_count) ? '<span class="unread-badge">' + Number(row.unread_count) + '</span>' : '') + '</button>';
    }).join('') || '<div class="cloud-state" style="box-shadow:none;border:0"><h2>No conversations yet</h2><p>Start by messaging someone from the network.</p><button class="btn" onclick="openNewChat()">Find people</button></div>';
  };

  window.setConversationFilter = function (filter) {
    chatState.filter = filter;
    ['All','Direct','Group'].forEach(function (name) { const el = $('tab' + name); if (el) el.classList.toggle('active', name.toLowerCase() === filter); });
    renderConversations();
  };

  window.selectConversation = async function (id) {
    if (chatState.sending) return toast('File upload complete hone dein, phir conversation change karein.');
    const conversation = chatState.conversations.find(function (row) { return row.conversation_id === id; });
    if (!conversation) return;
    if (chatState.selected && chatState.selected.conversation_id !== id) removeChatAttachment(true);
    chatState.selected = conversation;
    renderConversations();
    $('chatLiveLayout').classList.add('chat-open');
    $('chatEmptyLive').classList.add('hide'); $('chatActiveLive').classList.remove('hide');
    $('chatHeaderAvatar').innerHTML = cloudAvatar(conversation, 'sm');
    $('chatHeaderName').textContent = conversation.display_title || 'Conversation';
    $('chatHeaderActions').innerHTML = conversation.kind === 'direct' && conversation.other_user_id ? '<a class="btn secondary" href="profile.html?u=' + encodeURIComponent(conversation.other_user_id) + '">Profile</a>' : '<a class="btn secondary" href="groups.html">Groups</a>';
    $('chatHeaderStatus').innerHTML = '<span class="status-pulse" style="width:6px;height:6px;display:inline-block;margin-right:6px"></span>' + (conversation.kind === 'group' ? 'Group chat · live' : 'Realtime connected');
    $('messageStream').innerHTML = '<div class="live-loading">Loading conversation</div>';
    if (chatState.channel) SkillCloud.removeChannel(chatState.channel);
    try {
      chatState.messages = await SkillCloud.messages(id);
      renderMessages();
      await SkillCloud.markConversationRead(id);
      conversation.unread_count = 0; renderConversations();
      chatState.channel = SkillCloud.chatChannel(id, receiveMessage, receiveTyping);
      setTimeout(function () { $('chatMessageLive').focus(); }, 30);
    } catch (error) { $('messageStream').innerHTML = '<div class="cloud-state"><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>'; }
  };

  function renderMessages() {
    const stream = $('messageStream');
    if (!chatState.messages.length) {
      stream.innerHTML = '<div class="chat-empty-live"><div><h2>Say hello</h2><p>This is a private realtime conversation. Messages will appear here on both accounts instantly.</p></div></div>';
      return;
    }
    stream.innerHTML = chatState.messages.map(messageMarkup).join('');
    stream.scrollTop = stream.scrollHeight;
  }

  function messageMarkup(message) {
    const mine = message.sender_id === ownId();
    let attachment = '';
    const type = String(message.attachment_type || '');
    const name = message.attachment_name || 'Attachment';
    const size = message.attachment_size ? formatBytes(message.attachment_size) : '';
    if (message.attachment_url && /^image\//.test(type)) {
      attachment = '<a class="message-media-link" href="' + esc(message.attachment_url) + '" target="_blank" rel="noopener" aria-label="Open ' + esc(name) + '"><img class="message-attachment" src="' + esc(message.attachment_url) + '" alt="' + esc(name) + '"></a><a class="message-media-caption" href="' + esc(message.attachment_url) + '" target="_blank" rel="noopener"><span>' + esc(name) + '</span>' + (size ? '<small>' + esc(size) + '</small>' : '') + '</a>';
    } else if (message.attachment_url && /^video\//.test(type)) {
      attachment = '<video class="message-video-attachment" src="' + esc(message.attachment_url) + '" controls playsinline preload="metadata"></video><a class="message-media-caption" href="' + esc(message.attachment_url) + '" target="_blank" rel="noopener"><span>' + esc(name) + '</span>' + (size ? '<small>' + esc(size) + ' · Download</small>' : '<small>Download video</small>') + '</a>';
    } else if (message.attachment_url) {
      const extension = String(name).split('.').pop().slice(0, 5).toUpperCase() || 'FILE';
      attachment = '<a class="file-attachment" href="' + esc(message.attachment_url) + '" target="_blank" rel="noopener"><span class="file-attachment-icon">' + esc(extension) + '</span><span><b>' + esc(name) + '</b><small>' + esc(size || 'Document') + '</small></span><i>↓</i></a>';
    }
    return '<div class="message-row ' + (mine ? 'mine' : '') + '" data-message-id="' + esc(message.id) + '">' + (!mine && chatState.selected && chatState.selected.kind === 'group' ? cloudAvatar(message.sender, 'sm') : '') + '<div class="message-bubble">' + (chatState.selected && chatState.selected.kind === 'group' && !mine ? '<b style="font-size:9px;display:block;margin-bottom:4px">' + esc(message.sender && message.sender.full_name || 'Member') + '</b>' : '') + attachment + (message.body ? '<p>' + esc(message.body) + '</p>' : '') + '<small>' + new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + (mine ? ' · ✓✓' : '') + '</small></div></div>';
  }

  function receiveMessage(message) {
    if (!chatState.messages.some(function (row) { return row.id === message.id; })) chatState.messages.push(message);
    else chatState.messages = chatState.messages.map(function (row) { return row.id === message.id ? message : row; });
    renderMessages();
    if (message.sender_id !== ownId()) SkillCloud.markConversationRead(chatState.selected.conversation_id).catch(function () {});
    loadConversations().catch(function () {});
  }

  function receiveTyping(payload) {
    if (!payload || payload.user_id === ownId()) return;
    clearTimeout(chatState.typingTimer);
    $('typingLive').textContent = payload.name ? payload.name + ' is typing...' : 'Typing...';
    chatState.typingTimer = setTimeout(function () { $('typingLive').textContent = ''; }, 1600);
  }

  window.chatTyping = function () {
    const nowTime = Date.now();
    if (nowTime - chatState.lastTypingSent < 900 || !chatState.channel) return;
    chatState.lastTypingSent = nowTime;
    SkillCloud.sendTyping(chatState.channel, { user_id: ownId(), name: user().name });
  };

  window.chatKeydown = function (event) {
    if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendLiveMessage(); }
  };

  window.resizeChatComposer = function () {
    const textarea = $('chatMessageLive');
    if (!textarea) return;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 116) + 'px';
  };

  function setAttachmentMenu(open) {
    const menu = $('chatAttachmentMenu');
    const button = $('chatAttachmentButton');
    if (!menu || !button) return;
    menu.classList.toggle('open', !!open);
    button.classList.toggle('active', !!open);
    button.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  window.toggleChatAttachmentMenu = function () {
    if (chatState.sending) return;
    setAttachmentMenu(!$('chatAttachmentMenu').classList.contains('open'));
  };

  window.chooseChatAttachment = function (kind) {
    if (chatState.sending) return;
    const input = kind === 'photo' ? $('chatPhotoLive') : kind === 'video' ? $('chatVideoLive') : $('chatDocumentLive');
    setAttachmentMenu(false);
    if (input) input.click();
  };

  window.selectChatAttachment = function (input, expectedKind) {
    const file = input && input.files && input.files[0];
    if (!file) return;
    const maxBytes = SkillCloud.chatMaxBytes || 50 * 1024 * 1024;
    const actualKind = SkillCloud.chatFileKind(file);
    if (file.size > maxBytes) {
      input.value = '';
      return toast('File 50MB ya us se choti honi chahiye.');
    }
    if (!actualKind || actualKind !== expectedKind) {
      input.value = '';
      return toast('Sahi ' + fileTypeLabel(expectedKind).toLowerCase() + ' format select karein.');
    }
    removeChatAttachment(true);
    chatState.attachmentFile = file;
    chatState.attachmentKind = actualKind;
    if (actualKind === 'photo' || actualKind === 'video') chatState.attachmentPreviewUrl = URL.createObjectURL(file);
    const thumb = $('chatAttachmentThumb');
    if (actualKind === 'photo') thumb.innerHTML = '<img src="' + esc(chatState.attachmentPreviewUrl) + '" alt="">';
    else if (actualKind === 'video') thumb.innerHTML = '<video src="' + esc(chatState.attachmentPreviewUrl) + '" muted playsinline preload="metadata"></video><span class="chat-video-badge">▶</span>';
    else thumb.innerHTML = '<span class="chat-document-badge">' + esc(String(file.name).split('.').pop().slice(0, 5).toUpperCase() || 'FILE') + '</span>';
    $('chatAttachmentName').textContent = file.name;
    $('chatAttachmentMeta').textContent = fileTypeLabel(actualKind) + ' · ' + formatBytes(file.size) + ' · Ready to send';
    $('chatAttachmentPreview').classList.remove('hide');
    $('chatUploadProgress').classList.add('hide');
    $('chatUploadProgressBar').style.width = '0%';
    input.value = '';
    setAttachmentMenu(false);
    $('chatMessageLive').focus();
  };

  window.removeChatAttachment = function (silent) {
    if (chatState.sending && !silent) return;
    if (chatState.attachmentPreviewUrl) URL.revokeObjectURL(chatState.attachmentPreviewUrl);
    chatState.attachmentFile = null;
    chatState.attachmentKind = '';
    chatState.attachmentPreviewUrl = '';
    ['chatPhotoLive','chatVideoLive','chatDocumentLive'].forEach(function (id) { if ($(id)) $(id).value = ''; });
    if ($('chatAttachmentThumb')) $('chatAttachmentThumb').innerHTML = '';
    if ($('chatAttachmentPreview')) $('chatAttachmentPreview').classList.add('hide');
    if ($('chatUploadProgress')) $('chatUploadProgress').classList.add('hide');
  };

  function showUploadProgress(uploaded, total) {
    const percent = total ? Math.max(0, Math.min(100, Math.round(uploaded / total * 100))) : 0;
    $('chatUploadProgress').classList.remove('hide');
    $('chatUploadProgress').setAttribute('aria-valuenow', String(percent));
    $('chatUploadProgressBar').style.width = percent + '%';
    $('chatAttachmentMeta').textContent = percent >= 100 ? 'Upload complete · Sending message…' : 'Uploading · ' + percent + '% · ' + formatBytes(uploaded) + ' of ' + formatBytes(total);
  };

  window.sendLiveMessage = async function () {
    if (!chatState.selected) return toast('Conversation select karein.');
    if (chatState.sending) return;
    const body = $('chatMessageLive').value.trim(); const file = chatState.attachmentFile;
    if (!body && !file) return;
    const button = $('chatSendLive');
    chatState.sending = true;
    button.disabled = true;
    button.textContent = '…';
    $('chatAttachmentButton').disabled = true;
    $('chatAttachmentRemove').disabled = true;
    setAttachmentMenu(false);
    try {
      const message = await SkillCloud.sendMessage(chatState.selected.conversation_id, body, file, showUploadProgress);
      $('chatMessageLive').value = '';
      resizeChatComposer();
      removeChatAttachment(true);
      receiveMessage(message);
    } catch (error) {
      if (file) {
        $('chatUploadProgress').classList.add('hide');
        $('chatAttachmentMeta').textContent = fileTypeLabel(chatState.attachmentKind) + ' · ' + formatBytes(file.size) + ' · Upload failed, try again';
      }
      toast(SkillCloud.cleanError(error));
    }
    finally {
      chatState.sending = false;
      button.disabled = false;
      button.textContent = '➤';
      $('chatAttachmentButton').disabled = false;
      $('chatAttachmentRemove').disabled = false;
      $('chatMessageLive').focus();
    }
  };

  window.openNewChat = function () { $('newChatModal').classList.add('open'); $('newChatSearch').value = ''; $('newChatResults').innerHTML = '<p class="muted">Type a name to search.</p>'; setTimeout(function () { $('newChatSearch').focus(); }, 20); };
  window.closeNewChat = function () { $('newChatModal').classList.remove('open'); };
  let searchTimer = null;
  window.searchNewChatUsers = function () {
    clearTimeout(searchTimer);
    const query = $('newChatSearch').value.trim();
    if (query.length < 2) { $('newChatResults').innerHTML = '<p class="muted">Enter at least 2 characters.</p>'; return; }
    searchTimer = setTimeout(async function () {
      $('newChatResults').innerHTML = '<div class="live-loading">Searching people</div>';
      try {
        const rows = (await SkillCloud.listProfiles(query)).filter(function (profile) { return profile.id !== ownId(); });
        $('newChatResults').innerHTML = rows.map(function (profile) {
          const canMessage = !profile.is_private || profile.relationship === 'friends';
          const action = canMessage
            ? '<button class="btn secondary" onclick="startDirect(\'' + profile.id + '\')">Message</button>'
            : '<span class="new-chat-private"><b>Private</b><small>Add as friend first</small></span>';
          return '<div class="conversation-item">' + cloudAvatar(profile, 'sm') + '<span class="conversation-item-copy"><b>' + esc(profile.full_name) + (profile.is_private ? ' · Private' : '') + '</b><p>' + esc(profile.headline || 'SkillSwape Member') + (profile.location ? ' · ' + esc(profile.location) : '') + '</p></span><span class="new-chat-actions">' + action + '<a class="btn secondary" href="profile.html?u=' + encodeURIComponent(profile.id) + '">Profile</a></span></div>';
        }).join('') || '<p class="muted">No matching members found.</p>';
      } catch (error) { $('newChatResults').innerHTML = '<p class="muted">' + esc(SkillCloud.cleanError(error)) + '</p>'; }
    }, 300);
  };

  window.startDirect = async function (profileId) {
    try {
      const id = await SkillCloud.openDirect(profileId); closeNewChat(); await loadConversations();
      const row = chatState.conversations.find(function (item) { return item.conversation_id === id; });
      if (row) selectConversation(id);
    } catch (error) { toast(SkillCloud.cleanError(error)); }
  };

  window.closeMobileChat = function () { $('chatLiveLayout').classList.remove('chat-open'); };
  document.addEventListener('click', function (event) {
    const anchor = document.querySelector('.chat-attachment-anchor');
    if (anchor && !anchor.contains(event.target)) setAttachmentMenu(false);
  });
  document.addEventListener('keydown', function (event) { if (event.key === 'Escape') setAttachmentMenu(false); });
  window.addEventListener('beforeunload', function () {
    if (chatState.channel) SkillCloud.removeChannel(chatState.channel);
    if (chatState.attachmentPreviewUrl) URL.revokeObjectURL(chatState.attachmentPreviewUrl);
  });
  initChat();
})();
