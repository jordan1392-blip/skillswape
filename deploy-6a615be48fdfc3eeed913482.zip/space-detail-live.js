(function () {
  'use strict';
  const id = new URLSearchParams(location.search).get('id');
  const state = { space: null, posts: [], subscription: null };

  function cloudAvatar(profile, size) { profile = profile || {}; const name = profile.full_name || 'Member'; return '<div class="avatar ' + (size || 'sm') + '">' + (profile.avatar_url ? '<img src="' + esc(profile.avatar_url) + '" alt="">' : esc(name.charAt(0).toUpperCase())) + '</div>'; }
  function ownId() { return SkillCloud.state.session && SkillCloud.state.session.user.id || uid(); }
  function postMediaItems(post) {
    if (!post || !post.media_url) return [];
    let urls = [];
    try { const parsed = JSON.parse(post.media_url); if (Array.isArray(parsed)) urls = parsed.filter(Boolean); } catch (_) {}
    if (!urls.length) urls = [post.media_url];
    return urls.map(function (url) { return { url: String(url), type: post.media_type === 'video' ? 'video' : 'image' }; });
  }
  function postMediaMarkup(post) {
    const media = postMediaItems(post);
    if (!media.length) return '';
    if (media.length === 1) return media[0].type === 'video'
      ? '<video class="post-live-media" src="' + esc(media[0].url) + '" controls playsinline></video>'
      : '<img class="post-live-media" src="' + esc(media[0].url) + '" alt="" loading="lazy">';
    return '<div class="profile-post-gallery">' + media.map(function (item, index) { return '<div><img class="post-live-media" src="' + esc(item.url) + '" alt="Post photo ' + (index + 1) + '" loading="lazy"></div>'; }).join('') + '</div><small class="profile-gallery-hint">Swipe to see all ' + media.length + ' photos</small>';
  }

  async function initSpace() {
    if (!id) { $('spaceDetailRoot').innerHTML = '<div class="cloud-state"><h2>Space not found</h2><p>Open a community or group from its listing page.</p></div>'; return; }
    try {
      await SkillCloud.requireUser(); state.space = await SkillCloud.getSpace(id); state.posts = await SkillCloud.listPosts({ spaceId: id }); renderSpace();
      state.subscription = SkillCloud.subscribe('space_posts', function () { reloadPosts(); }, 'space_id=eq.' + id);
    } catch (error) { $('spaceDetailRoot').innerHTML = '<div class="cloud-state"><h2>Space unavailable</h2><p>' + esc(SkillCloud.cleanError(error)) + '</p><a class="btn" href="communities.html">Browse communities</a></div>'; }
  }

  async function reloadPosts() { try { state.posts = await SkillCloud.listPosts({ spaceId: id }); renderPostList(); } catch (_) {} }

  function membershipAction() {
    const s = state.space;
    if (s.is_member) return '<a class="btn" href="chat.html?conversation=' + encodeURIComponent(s.conversation_id) + '">Open group chat</a><button class="btn secondary" onclick="openSpacePost()">Create post</button>';
    if (s.privacy === 'private') return '<button class="btn" onclick="requestDetailAccess()">Request access</button>';
    return '<button class="btn" onclick="joinDetailSpace()">Join ' + esc(s.space_type) + '</button>';
  }

  function renderSpace() {
    const s = state.space;
    document.title = s.name + ' — SkillSwape AI';
    $('spaceDetailRoot').innerHTML = '<section class="space-hero-live">' + (s.cover_url ? '<img src="' + esc(s.cover_url) + '" alt="">' : '') + '<div class="space-hero-copy"><div><span class="space-type-label">' + esc(s.privacy) + ' ' + esc(s.space_type) + ' · ' + esc(s.category) + '</span><h1>' + esc(s.name) + '</h1><p>' + esc(s.description) + '</p></div><div class="top-actions">' + membershipAction() + '</div></div></section>' +
      '<section style="display:grid;grid-template-columns:minmax(0,1fr);gap:18px;max-width:790px;margin:24px auto 0">' +
      '<div class="composer-live"><div class="composer-live-head">' + avatar(user(),'sm') + '<button class="composer-live-trigger" onclick="' + (s.is_member ? 'openSpacePost()' : (s.privacy === 'public' ? 'joinDetailSpace()' : 'requestDetailAccess()')) + '">' + (s.is_member ? 'Share an update with ' + esc(s.name) + '...' : 'Join to publish and enter the live chat') + '</button></div></div>' +
      ((s.my_role === 'owner' || s.my_role === 'moderator') ? '<section id="spaceRequestsPanel" class="composer-live"><h3 style="margin-top:0">Pending member requests</h3><div id="spaceRequestList"><div class="live-loading">Loading requests</div></div></section>' : '') +
      '<section id="spacePostList"><div class="live-loading">Loading posts</div></section></section>';
    renderPostList(); if (s.my_role === 'owner' || s.my_role === 'moderator') loadRequests();
  }

  function renderPostList() {
    const root = $('spacePostList'); if (!root) return;
    if (!state.space.is_member && state.space.privacy === 'private') { root.innerHTML = '<div class="cloud-state"><div class="state-icon">↗</div><h2>Private group</h2><p>Group posts and live chat are visible after an admin approves your request.</p><button class="btn" onclick="requestDetailAccess()">Request access</button></div>'; return; }
    root.innerHTML = '<div class="feed-live-grid">' + (state.posts.map(postMarkup).join('') || '<div class="cloud-state"><div class="state-icon">+</div><h2>No posts yet</h2><p>Start this space with a useful update or question.</p>' + (state.space.is_member ? '<button class="btn" onclick="openSpacePost()">Create first post</button>' : '') + '</div>') + '</div>';
  }

  function postMarkup(post) {
    const author = post.author || {}, own = post.author_id === ownId();
    const media = postMediaMarkup(post);
    return '<article class="post-live"><div class="post-live-body"><div class="post-live-head"><a class="post-live-author" href="profile.html?u=' + encodeURIComponent(post.author_id) + '">' + cloudAvatar(author,'sm') + '<span><b>' + esc(author.full_name || 'Member') + '</b><small>' + esc(author.headline || '') + ' · ' + timeAgo(post.created_at) + '</small></span></a><span class="post-space-pill">' + esc(post.category) + '</span></div>' + (post.title ? '<h2>' + esc(post.title) + '</h2>' : '') + '<p class="post-copy">' + esc(post.body) + '</p></div>' + media + '<div class="post-live-meta"><span>' + post.like_count + ' likes</span><span>' + post.comment_count + ' comments</span></div><div class="post-live-actions"><button class="' + (post.liked ? 'liked' : '') + '" onclick="likeSpacePost(\'' + post.id + '\')">♡ <span>Like</span></button><button onclick="toggleSpaceComments(\'' + post.id + '\')">○ <span>Comment</span></button><button onclick="shareSpacePost(\'' + post.id + '\')">↗ <span>Share</span></button>' + (own ? '<button onclick="deleteSpacePost(\'' + post.id + '\')">× <span>Delete</span></button>' : '<a href="chat.html?user=' + encodeURIComponent(post.author_id) + '">✦ <span>Message</span></a>') + '</div><div id="spaceComments_' + post.id + '" class="post-comments-live" data-loaded="false"></div></article>';
  }

  window.joinDetailSpace = async function () { try { await SkillCloud.joinSpace(id); toast('Joined successfully'); state.space = await SkillCloud.getSpace(id); state.posts = await SkillCloud.listPosts({ spaceId:id }); renderSpace(); } catch (error) { toast(SkillCloud.cleanError(error)); } };
  window.requestDetailAccess = async function () { try { await SkillCloud.requestSpace(id); toast('Request sent to group admin'); } catch (error) { toast(SkillCloud.cleanError(error)); } };
  window.openSpacePost = function () { if (!state.space.is_member) return; $('spacePostModal').classList.add('open'); };
  window.closeSpacePost = function () { $('spacePostModal').classList.remove('open'); };
  window.publishSpacePost = async function () {
    const body = $('spacePostBody').value.trim(); if (!body) return toast('Post text required hai.');
    const button = $('spacePostButton'); button.disabled = true; button.textContent = 'Publishing...';
    try { await SkillCloud.createPost({ space_id:id, category:$('spacePostCategory').value, title:$('spacePostTitle').value.trim(), body:body }, $('spacePostMedia').files[0]); $('spacePostBody').value='';$('spacePostTitle').value='';$('spacePostMedia').value='';$('spacePostMediaName').textContent='';closeSpacePost();toast('Post is live');await reloadPosts(); }
    catch (error) { $('spacePostStatus').textContent=SkillCloud.cleanError(error);toast(SkillCloud.cleanError(error)); }
    finally { button.disabled=false;button.textContent='Publish'; }
  };
  window.likeSpacePost = async function (postId) { const post=state.posts.find(function(p){return p.id===postId});if(!post)return;try{await SkillCloud.toggleLike(post);await reloadPosts()}catch(error){toast(SkillCloud.cleanError(error))} };
  window.deleteSpacePost = async function(postId){if(!confirm('Delete this post permanently?'))return;try{await SkillCloud.deletePost(postId);await reloadPosts()}catch(error){toast(SkillCloud.cleanError(error))}};
  window.shareSpacePost = async function(postId){const url=location.href.split('#')[0]+'#post-'+postId;try{if(navigator.share)await navigator.share({title:state.space.name,url:url});else{await navigator.clipboard.writeText(url);toast('Link copied')}}catch(_){}};
  window.toggleSpaceComments = async function(postId){const box=$('spaceComments_'+postId);box.classList.toggle('open');if(!box.classList.contains('open')||box.dataset.loaded==='true')return;box.innerHTML='<div class="live-loading">Loading comments</div>';try{const rows=await SkillCloud.comments(postId);box.dataset.loaded='true';box.innerHTML='<div>'+(rows.map(function(c){return '<div class="comment-live">'+cloudAvatar(c.author,'sm')+'<div class="comment-bubble"><b>'+esc(c.author&&c.author.full_name||'Member')+'</b><p>'+esc(c.body)+'</p></div></div>'}).join('')||'<p class="muted">No comments yet.</p>')+'</div><div class="comment-compose"><input id="spaceCommentInput_'+postId+'" placeholder="Write a comment..."><button class="btn secondary" onclick="addSpaceComment(\''+postId+'\')">Post</button></div>'}catch(error){box.innerHTML='<p class="muted">'+esc(SkillCloud.cleanError(error))+'</p>'}};
  window.addSpaceComment=async function(postId){const input=$('spaceCommentInput_'+postId);if(!input||!input.value.trim())return;try{await SkillCloud.addComment(postId,input.value.trim());const box=$('spaceComments_'+postId);box.dataset.loaded='false';box.classList.remove('open');await toggleSpaceComments(postId);await reloadPosts()}catch(error){toast(SkillCloud.cleanError(error))}};

  async function loadRequests(){try{const rows=await SkillCloud.listJoinRequests(id);$('spaceRequestList').innerHTML=rows.map(function(r){return '<div class="member-request-card">'+cloudAvatar(r.requester,'sm')+'<div><b>'+esc(r.requester&&r.requester.full_name||'Member')+'</b><small>'+esc(r.requester&&r.requester.headline||'')+'</small></div><button class="btn" onclick="reviewDetailRequest(\''+r.id+'\',true)">Approve</button><button class="btn secondary" onclick="reviewDetailRequest(\''+r.id+'\',false)">Decline</button></div>'}).join('')||'<p class="muted">No pending requests.</p>'}catch(error){$('spaceRequestList').innerHTML='<p class="muted">'+esc(SkillCloud.cleanError(error))+'</p>'}};
  window.reviewDetailRequest=async function(requestId,approve){try{await SkillCloud.reviewSpaceRequest(requestId,approve);toast(approve?'Member approved':'Request declined');await loadRequests()}catch(error){toast(SkillCloud.cleanError(error))}};
  window.addEventListener('beforeunload',function(){if(state.subscription)SkillCloud.removeSubscription(state.subscription)});
  initSpace();
})();
