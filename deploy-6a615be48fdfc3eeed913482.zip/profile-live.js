(function () {
  'use strict';
  const state = { profile: null, posts: [], spaces: [] };
  const avatarCrop = { image: null, url: '', zoom: 1, x: 0, y: 0, baseScale: 1, dragging: false, startX: 0, startY: 0, originX: 0, originY: 0 };
  let channel = null;

  function ownId() {
    return SkillCloud.state.session && SkillCloud.state.session.user.id || uid();
  }

  function cloudAvatar(profile, size) {
    profile = profile || {};
    const name = profile.full_name || 'Member';
    return '<div class="avatar ' + (size || 'sm') + '">' + (profile.avatar_url
      ? '<img src="' + esc(profile.avatar_url) + '" alt="">'
      : esc(name.charAt(0).toUpperCase())) + '</div>';
  }


  function profileMedia(post) {
    if (!post || !post.media_url) return [];
    let urls = [];
    try { const parsed = JSON.parse(post.media_url); if (Array.isArray(parsed)) urls = parsed.filter(Boolean); } catch (_) {}
    if (!urls.length) urls = [post.media_url];
    return urls.map(function (url) { return { url: String(url), type: post.media_type === 'video' ? 'video' : 'image' }; });
  }

  function profileMediaMarkup(post) {
    const media = profileMedia(post);
    if (!media.length) return '';
    if (media.length === 1) return media[0].type === 'video'
      ? '<video class="post-live-media" src="' + esc(media[0].url) + '" controls playsinline></video>'
      : '<img class="post-live-media" src="' + esc(media[0].url) + '" alt="" loading="lazy">';
    return '<div class="profile-post-gallery">' + media.map(function (item, index) {
      return '<div><img class="post-live-media" src="' + esc(item.url) + '" alt="Post photo ' + (index + 1) + '" loading="lazy"></div>';
    }).join('') + '</div><small class="profile-gallery-hint">Swipe to see all ' + media.length + ' photos</small>';
  }

  async function loadProfile() {
    const id = new URLSearchParams(location.search).get('u') || ownId();
    const profile = await SkillCloud.getProfile(id);
    const own = profile.id === ownId();
    const canView = own || profile.can_view_full;
    state.profile = profile;
    state.posts = [];
    state.spaces = [];
    if (canView) {
      const results = await Promise.all([SkillCloud.listPosts({ authorId: id }), SkillCloud.listSpaces()]);
      state.posts = results[0];
      state.spaces = results[1].filter(function (space) {
        return (space.members || []).some(function (member) { return member.user_id === id; });
      });
    }
    renderProfile();
  }

  async function initProfile() {
    if (!SkillCloud.configured) {
      $('profileLiveRoot').innerHTML = '<div class="cloud-state"><h2>Live setup required</h2><p>' + esc(SkillCloud.setupMessage()) + '</p><a class="btn" href="setup.html">Setup guide</a></div>';
      return;
    }
    try {
      await SkillCloud.requireUser();
      await loadProfile();
      channel = SkillCloud.subscribe('friendships', function () {
        loadProfile().catch(function () {});
      });
    } catch (error) {
      $('profileLiveRoot').innerHTML = '<div class="cloud-state"><h2>Profile unavailable</h2><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>';
    }
  }

  function profilePostMarkup(post) {
    const media = profileMediaMarkup(post);
    return '<article class="post-live"><div class="post-live-body"><div class="post-live-head"><span class="post-space-pill">' +
      esc(post.space && post.space.name || 'Public feed') + '</span><small class="muted">' + timeAgo(post.created_at) + '</small></div>' +
      (post.title ? '<h2>' + esc(post.title) + '</h2>' : '') + (post.body ? '<p class="post-copy">' + esc(post.body) + '</p>' : '') + '</div>' + media +
      '<div class="post-live-meta"><span>' + post.like_count + ' likes</span><span>' + post.comment_count + ' comments</span></div>' +
      '<div class="post-live-actions"><a href="daily-feed.html#post-' + encodeURIComponent(post.id) + '">Open in feed</a></div></article>';
  }

  function renderProfile() {
    const profile = state.profile;
    const own = profile.id === ownId();
    const locked = profile.is_private && !profile.can_view_full && !own;
    const privacy = profile.is_private ? '<span class="privacy-badge">Private account</span>' : '<span class="privacy-badge public">Public account</span>';
    const skills = (profile.skills || []).map(function (skill) {
      return '<span class="chip">' + esc(skill) + '</span>';
    }).join('');
    const actions = own
      ? '<a class="btn secondary" href="settings.html#privacy">Privacy</a><button class="btn" onclick="openProfileEditor()">Edit profile</button>'
      : friendControlsHTML(profile, { message: true });

    document.title = profile.full_name + ' — SkillSwape AI';
    let details = '';
    if (locked) {
      details = '<div class="private-profile-gate"><div class="private-gate-icon">●</div><div><h2>This account is private</h2><p>Send a friend request to see ' + esc(profile.full_name) + '\'s bio, skills, posts and stories.</p></div></div>';
    } else {
      details = '<p class="profile-live-bio">' + esc(profile.bio || 'No bio added yet.') + '</p>' +
        '<div class="skill-row">' + (skills || '<span class="chip">Skills coming soon</span>') + '</div>' +
        '<div class="profile-stat-line"><span>' + state.posts.length + ' posts</span><span>' + state.spaces.length + ' communities & groups</span>' +
        '<span>' + esc(profile.location || 'Location not added') + '</span><span>Joined ' + new Date(profile.created_at).toLocaleDateString([], { month: 'short', year: 'numeric' }) + '</span></div>';
    }

    const posts = locked ? '' : '<section class="profile-post-section"><div class="profile-section-head"><h2>Recent posts</h2>' +
      (own ? '<button class="btn secondary" onclick="location.href=\'daily-feed.html?compose=1\'">Create post</button>' : '') + '</div>' +
      '<div class="feed-live-grid">' + (state.posts.map(profilePostMarkup).join('') || '<div class="cloud-state"><h2>No posts yet</h2><p>Published community updates will appear here.</p></div>') + '</div></section>';

    $('profileLiveRoot').innerHTML = '<section class="profile-live-card"><div class="profile-live-cover">' +
      (profile.cover_url ? '<img src="' + esc(profile.cover_url) + '" alt="">' : '') + '</div><div class="profile-live-main">' +
      '<div class="profile-live-identity">' + cloudAvatar(profile, 'xl') + '<div class="profile-live-name"><div class="name-with-badge"><h1>' + esc(profile.full_name) + '</h1>' + privacy + '</div>' +
      '<p>' + esc(profile.headline || 'SkillSwape Member') + '</p><small class="muted">' + Number(profile.friend_count || 0) + ' friends</small></div>' +
      '<div class="top-actions profile-friend-actions">' + actions + '</div></div>' + details + '</div></section>' + posts;
  }

  function resetAvatarCrop() {
    if (avatarCrop.url) URL.revokeObjectURL(avatarCrop.url);
    avatarCrop.image = null; avatarCrop.url = ''; avatarCrop.zoom = 1; avatarCrop.x = 0; avatarCrop.y = 0; avatarCrop.dragging = false;
    if ($('avatarCropBox')) $('avatarCropBox').hidden = true;
    if ($('avatarCropZoom')) $('avatarCropZoom').value = '1';
  }

  function renderAvatarCrop() {
    if (!avatarCrop.image) return;
    const stage = $('avatarCropStage');
    const img = $('avatarCropImage');
    const width = stage.clientWidth || 280;
    const height = stage.clientHeight || 280;
    avatarCrop.baseScale = Math.max(width / avatarCrop.image.naturalWidth, height / avatarCrop.image.naturalHeight);
    const scale = avatarCrop.baseScale * avatarCrop.zoom;
    const displayWidth = avatarCrop.image.naturalWidth * scale;
    const displayHeight = avatarCrop.image.naturalHeight * scale;
    const maxX = Math.max(0, (displayWidth - width) / 2);
    const maxY = Math.max(0, (displayHeight - height) / 2);
    avatarCrop.x = Math.max(-maxX, Math.min(maxX, avatarCrop.x));
    avatarCrop.y = Math.max(-maxY, Math.min(maxY, avatarCrop.y));
    img.style.width = displayWidth + 'px';
    img.style.height = displayHeight + 'px';
    img.style.transform = 'translate(calc(-50% + ' + avatarCrop.x + 'px), calc(-50% + ' + avatarCrop.y + 'px))';
  }

  window.setAvatarZoom = function (value) {
    const old = avatarCrop.zoom || 1;
    avatarCrop.zoom = Math.max(1, Math.min(3, Number(value) || 1));
    avatarCrop.x *= avatarCrop.zoom / old;
    avatarCrop.y *= avatarCrop.zoom / old;
    renderAvatarCrop();
  };

  window.prepareAvatarCrop = function () {
    const file = $('profileAvatarLive').files[0];
    resetAvatarCrop();
    if (!file) { $('profileAvatarName').textContent = ''; return; }
    if (file.size > 5 * 1024 * 1024) {
      $('profileSaveStatus').textContent = 'Profile photo 5MB se choti honi chahiye.';
      $('profileAvatarLive').value = '';
      return;
    }
    $('profileAvatarName').textContent = file.name;
    avatarCrop.url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = function () {
      avatarCrop.image = image;
      $('avatarCropImage').src = avatarCrop.url;
      $('avatarCropBox').hidden = false;
      avatarCrop.zoom = 1; avatarCrop.x = 0; avatarCrop.y = 0;
      requestAnimationFrame(renderAvatarCrop);
    };
    image.onerror = function () { $('profileSaveStatus').textContent = 'Selected photo read nahi ho saki.'; resetAvatarCrop(); };
    image.src = avatarCrop.url;
  };

  async function croppedAvatarFile() {
    if (!avatarCrop.image) return $('profileAvatarLive').files[0] || null;
    const stage = $('avatarCropStage');
    const stageWidth = stage.clientWidth || 280;
    const stageHeight = stage.clientHeight || 280;
    const scale = avatarCrop.baseScale * avatarCrop.zoom;
    const displayWidth = avatarCrop.image.naturalWidth * scale;
    const displayHeight = avatarCrop.image.naturalHeight * scale;
    const left = (stageWidth - displayWidth) / 2 + avatarCrop.x;
    const top = (stageHeight - displayHeight) / 2 + avatarCrop.y;
    const sx = Math.max(0, -left / scale);
    const sy = Math.max(0, -top / scale);
    const sw = Math.min(avatarCrop.image.naturalWidth - sx, stageWidth / scale);
    const sh = Math.min(avatarCrop.image.naturalHeight - sy, stageHeight / scale);
    const canvas = document.createElement('canvas');
    canvas.width = 900; canvas.height = 900;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(avatarCrop.image, sx, sy, sw, sh, 0, 0, 900, 900);
    const blob = await new Promise(function (resolve, reject) {
      canvas.toBlob(function (value) { value ? resolve(value) : reject(new Error('Profile photo crop failed')); }, 'image/jpeg', .92);
    });
    return new File([blob], 'profile-photo-' + Date.now() + '.jpg', { type: 'image/jpeg' });
  }

  window.openProfileEditor = function () {
    const profile = state.profile;
    resetAvatarCrop();
    $('profileEditForm').reset();
    $('profileAvatarName').textContent = ''; $('profileCoverName').textContent = '';
    $('profileSaveStatus').textContent = 'Use a clear photo and drag/zoom it before saving.';
    $('profileNameLive').value = profile.full_name || '';
    $('profileHeadlineLive').value = profile.headline || '';
    $('profileBioLive').value = profile.bio || '';
    $('profileLocationLive').value = profile.location || '';
    $('profileSkillsLive').value = (profile.skills || []).join(', ');
    $('profileEditModal').classList.add('open');
  };

  window.closeProfileEditor = function () {
    $('profileEditModal').classList.remove('open');
    resetAvatarCrop();
  };

  window.saveLiveProfile = async function () {
    const button = $('profileSaveButton');
    button.disabled = true;
    button.textContent = 'Saving...';
    try {
      const values = {
        full_name: $('profileNameLive').value.trim(),
        headline: $('profileHeadlineLive').value.trim(),
        bio: $('profileBioLive').value.trim(),
        location: $('profileLocationLive').value.trim(),
        skills: $('profileSkillsLive').value.split(',').map(function (item) { return item.trim(); }).filter(Boolean).slice(0, 20)
      };
      const originalAvatarFile = $('profileAvatarLive').files[0];
      const coverFile = $('profileCoverLive').files[0];
      const avatarFile = originalAvatarFile ? await croppedAvatarFile() : null;
      if (avatarFile) values.avatar_url = (await SkillCloud.upload('avatars', avatarFile, { maxMb: 5, contentType: 'image/jpeg' })).url;
      if (coverFile) values.cover_url = (await SkillCloud.upload('avatars', coverFile, { maxMb: 5 })).url;
      state.profile = await SkillCloud.updateProfile(values);
      closeProfileEditor();
      const mini = document.querySelector('.mini-profile');
      if (mini) {
        const localUser = user();
        mini.innerHTML = '<div>' + avatar(localUser, 'sm') + '</div><div><b>' + esc(localUser.name || state.profile.full_name) + '</b><p>' + esc(localUser.role || state.profile.headline || 'SkillSwape Member') + '</p></div>';
      }
      toast('Profile updated everywhere');
      renderProfile();
    } catch (error) {
      $('profileSaveStatus').textContent = SkillCloud.cleanError(error);
      toast(SkillCloud.cleanError(error));
    } finally {
      button.disabled = false;
      button.textContent = 'Save profile';
    }
  };

  window.addEventListener('skillswape:friendship-change', function () {
    $('profileLiveRoot').innerHTML = '<div class="live-loading">Refreshing profile</div>';
    loadProfile().catch(function (error) { toast(SkillCloud.cleanError(error)); });
  });
  window.addEventListener('beforeunload', function () {
    if (channel) SkillCloud.removeSubscription(channel);
  });

  const cropStage = $('avatarCropStage');
  if (cropStage) {
    cropStage.addEventListener('pointerdown', function (event) {
      if (!avatarCrop.image) return;
      avatarCrop.dragging = true;
      avatarCrop.startX = event.clientX; avatarCrop.startY = event.clientY;
      avatarCrop.originX = avatarCrop.x; avatarCrop.originY = avatarCrop.y;
      cropStage.setPointerCapture(event.pointerId);
    });
    cropStage.addEventListener('pointermove', function (event) {
      if (!avatarCrop.dragging) return;
      avatarCrop.x = avatarCrop.originX + event.clientX - avatarCrop.startX;
      avatarCrop.y = avatarCrop.originY + event.clientY - avatarCrop.startY;
      renderAvatarCrop();
    });
    ['pointerup','pointercancel'].forEach(function (name) { cropStage.addEventListener(name, function () { avatarCrop.dragging = false; }); });
  }

  initProfile();
})();
