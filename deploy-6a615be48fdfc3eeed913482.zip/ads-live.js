(function () {
  'use strict';
  const adState = { packages: [], campaigns: [], selected: null };
  function money(value) { return 'PKR ' + Number(value || 0).toLocaleString('en-PK'); }

  async function initAds() {
    if (!SkillCloud.configured) { $('packageGridLive').innerHTML = '<div class="cloud-state"><h2>Live setup required</h2><p>' + esc(SkillCloud.setupMessage()) + '</p><a class="btn" href="setup.html">Setup guide</a></div>'; return; }
    try { await SkillCloud.requireUser(); await loadAdDashboard(); }
    catch (error) { $('packageGridLive').innerHTML = '<div class="cloud-state"><h2>Ads dashboard unavailable</h2><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>'; }
  }

  window.loadAdDashboard = async function () {
    const results = await Promise.all([SkillCloud.adPackages(), SkillCloud.myCampaigns()]); adState.packages = results[0]; adState.campaigns = results[1];
    if (!adState.selected && adState.packages.length) adState.selected = adState.packages[0].id;
    renderPackages(); renderCampaigns(); fillPackageSelect();
  };

  function renderPackages() {
    $('packageGridLive').innerHTML = adState.packages.map(function (pkg, index) {
      return '<article class="package-card-live ' + (pkg.id === adState.selected ? 'selected ' : '') + (index === 2 ? 'popular' : '') + '" onclick="selectAdPackage(' + pkg.id + ')"><h3>' + esc(pkg.name) + '</h3><div class="package-price">' + money(pkg.price_pkr) + '</div><small>' + pkg.duration_days + ' days · ' + esc(pkg.placement) + '</small><ul>' + (pkg.features || []).map(function (feature) { return '<li>' + esc(feature) + '</li>'; }).join('') + '</ul></article>';
    }).join('');
  }

  function renderCampaigns() {
    $('campaignListLive').innerHTML = adState.campaigns.map(function (campaign) {
      return '<article class="campaign-row-live"><img src="' + esc(campaign.creative_url) + '" alt=""><div><b>' + esc(campaign.title) + '</b><small>' + esc(campaign.package && campaign.package.name || '') + ' · ' + money(campaign.package && campaign.package.price_pkr) + '</small></div><span class="status-chip ' + esc(campaign.status) + '">' + esc(campaign.status) + '</span><div><b>' + Number(campaign.impressions || 0).toLocaleString() + '</b><small>impressions</small></div><div><b>' + Number(campaign.clicks || 0).toLocaleString() + '</b><small>clicks</small></div></article>';
    }).join('') || '<div class="cloud-state"><div class="state-icon">AD</div><h2>No campaigns yet</h2><p>Select any package from PKR 1,000 to PKR 10,000 and submit your first creative.</p><button class="btn" onclick="openCampaignCreator()">Create campaign</button></div>';
  }

  function fillPackageSelect() {
    $('campaignPackageLive').innerHTML = adState.packages.map(function (pkg) { return '<option value="' + pkg.id + '">' + esc(pkg.name) + ' — ' + money(pkg.price_pkr) + ' / ' + pkg.duration_days + ' days</option>'; }).join('');
    if (adState.selected) $('campaignPackageLive').value = String(adState.selected);
  }

  window.selectAdPackage = function (id) { adState.selected = id; renderPackages(); fillPackageSelect(); openCampaignCreator(); };
  window.syncSelectedPackage = function () { adState.selected = Number($('campaignPackageLive').value); renderPackages(); };
  window.openCampaignCreator = function () { if (!adState.packages.length) return toast('Packages abhi load ho rahe hain.'); $('campaignCreatorModal').classList.add('open'); fillPackageSelect(); setTimeout(function () { $('campaignTitleLive').focus(); }, 20); };
  window.closeCampaignCreator = function () { $('campaignCreatorModal').classList.remove('open'); };
  window.submitCampaign = async function () {
    const title = $('campaignTitleLive').value.trim(), caption = $('campaignCaptionLive').value.trim(), creative = $('campaignCreativeLive').files[0];
    if (title.length < 3 || caption.length < 5 || !creative) return toast('Title, caption aur creative image required hain.');
    const button = $('campaignSubmitButton'); button.disabled = true; button.textContent = 'Uploading...';
    try {
      await SkillCloud.createCampaign({ package_id:$('campaignPackageLive').value,title:title,caption:caption,audience:$('campaignAudienceLive').value,target_url:$('campaignUrlLive').value.trim(),payment_reference:$('campaignPaymentLive').value.trim() }, creative);
      $('campaignCreatorForm').reset(); $('campaignCreativeName').textContent = ''; closeCampaignCreator(); toast('Campaign submitted for admin approval'); await loadAdDashboard();
    } catch (error) { $('campaignCreateStatus').textContent = SkillCloud.cleanError(error); toast(SkillCloud.cleanError(error)); }
    finally { button.disabled = false; button.textContent = 'Submit for approval'; }
  };
  initAds();
})();
