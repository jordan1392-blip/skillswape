# SkillSwape AI — Realtime Netlify Edition

This package upgrades the original browser-only prototype into a deployable social platform with shared accounts and realtime data.

## What is included

- Supabase email/password and optional Google authentication
- Realtime one-to-one chat between different accounts and devices
- Friend requests with send, accept, decline, cancel and unfriend actions
- Public/private account controls with protected bios, skills, personal posts and stories
- Private chat photos, videos and documents with previews, signed URLs, upload progress and resumable transfers up to 50MB
- Realtime typing indicator, unread counts and read tracking
- Public communities with join, posts, likes, comments and group chat
- Public/private groups with membership requests and admin approval
- 24-hour photo/video stories with view tracking
- Cloud-synced home feed, profiles, people search and marketplace offers
- Advertisement dashboard with five PKR packages: 1,000 / 2,500 / 5,000 / 7,500 / 10,000
- Campaign review, activation dates, impressions and click tracking
- Admin campaign approval panel
- Refined desktop/mobile product UI with compact navigation and clearer content hierarchy
- Persistent light/dark mode that survives page navigation, refreshes and new tabs
- Netlify headers, redirects and security policy
- PostgreSQL Row Level Security for private and owner-only data

## One-time backend setup

1. Create a project at Supabase.
2. Open **SQL Editor**, paste all of `supabase/schema.sql`, and run it.
3. Then paste and run `supabase/migrations/20260723_friendships_privacy.sql`. This adds friend requests, private accounts and their access rules.
4. Then run `supabase/migrations/20260723_story_upload_repair.sql`. This repairs story storage permissions and enables common mobile image/video formats up to 50MB.
5. Then run `supabase/migrations/20260723_chat_attachments_50mb.sql`. This enables private photo, video and document attachments, stores file sizes, and sets the chat bucket limit to 50MB.
6. `config.js` is already connected to the Supabase project used for this build. If you move the website to another project, replace its Project URL and Publishable key.
7. In Supabase **Authentication → URL Configuration**:
   - Set Site URL to `https://YOUR-SITE.netlify.app`
   - Add `https://YOUR-SITE.netlify.app/**` as a Redirect URL
8. For Google login, enable the Google provider in Supabase Auth and add the callback URL shown there to Google Cloud.
9. Create your owner account, then run the admin-promotion query at the bottom of `supabase/schema.sql` with your email.

Never put a Supabase `service_role` key, database password or payment secret in `config.js`. The browser Publishable/anon key is protected by the included Row Level Security policies.

## Deploy to Netlify

There is no build command.

- Drag this whole folder into **Netlify → Deploys**, or connect it to a Git repository.
- Build command: leave blank
- Publish directory: `.`

`netlify.toml` automatically applies redirects and browser security headers.

## Test live chat

1. Register Account A in a normal window.
2. Register Account B in an Incognito window or on another phone.
3. From Account A, open **Find People**, select Account B, and send a message.
4. The message should appear instantly on Account B without a refresh.
5. Select the chat `+` button, attach a photo, video and document, and confirm the preview, upload progress and signed download work on Account B.

## Test friends and privacy

1. In Account B, open **Settings** and enable **Private account**.
2. In Account A, find Account B and select **Add friend**. Account B's protected profile content and new-chat action stay locked.
3. In Account B, open **Friends** or **Notifications** and accept the request.
4. Account A can now see the full profile, private personal posts/stories and start a direct chat.
5. Cancelled, declined and removed relationships immediately update on both accounts.

## Advertisement workflow

1. Advertiser opens **Advertise** and selects a package.
2. Advertiser uploads a landscape creative and payment reference.
3. Campaign status becomes `pending`.
4. An admin reviews it in **Admin Panel** and selects **Approve**.
5. The campaign becomes active for the package duration and appears inside the home feed.

Payment is intentionally marked for manual verification. Connect a trusted server-side payment provider before accepting card details; never process payment secrets in this static frontend.

## Key files

- `config.js` — public runtime configuration
- `live-core.js` — authentication, database, storage and realtime API layer
- `vendor/supabase.js` — pinned Supabase browser client (v2.110.8)
- `vendor/tus.min.js` — pinned resumable-upload browser client (tus-js-client v4.3.1)
- `supabase/schema.sql` — tables, functions, security policies, storage and seed packages
- `supabase/migrations/20260723_friendships_privacy.sql` — private-account and friendship upgrade for this release
- `supabase/migrations/20260723_story_upload_repair.sql` — story bucket, RLS and mobile-media repair
- `supabase/migrations/20260723_chat_attachments_50mb.sql` — private chat bucket, file formats, 50MB limit and attachment-size upgrade
- `chat-live.js` — realtime direct/group messaging
- `friends-live.js` — request inbox, sent requests and friend management
- `feed-live.js` — home feed, stories, comments and sponsored placements
- `spaces-live.js` / `space-detail-live.js` — communities and groups
- `ads-live.js` / `admin-live.js` — campaign and approval panels
- `netlify.toml` — Netlify hosting configuration
- `theme-init.js` — early theme restore that prevents page-to-page theme resets
- `ui-v10.css` — shared responsive UI system used by every page

Open `setup.html` in the deployed website for the short visual checklist.

## Updating an existing deployment

For an existing v12 installation, run only `supabase/migrations/20260723_chat_attachments_50mb.sql`, then upload the updated folder to Netlify as a new deploy. The chat composer now stays inside the viewport and its `+` popup supports private photos, videos and documents up to 50MB with resumable progress.
