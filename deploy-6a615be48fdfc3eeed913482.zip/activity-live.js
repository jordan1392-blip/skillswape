(function () {
  'use strict';
  let channel = null;

  function requestCard(row) {
    const profile = {
      id: row.other_user_id,
      full_name: row.full_name,
      headline: row.headline,
      avatar_url: row.avatar_url,
      is_private: row.is_private,
      relationship: 'incoming',
      friend_request_id: row.request_id
    };
    return '<article class="person-card-live activity-request-card"><span class="status-chip active">FRIEND REQUEST</span>' +
      '<div class="person-card-head"><div class="avatar sm">' + (row.avatar_url ? '<img src="' + esc(row.avatar_url) + '" alt="">' : esc((row.full_name || 'M').charAt(0))) + '</div>' +
      '<div><b>' + esc(row.full_name) + '</b><small>' + esc(row.headline || 'SkillSwape Member') + '</small></div></div>' +
      '<p>Wants to connect with you.</p><div class="space-card-actions friend-card-actions">' + friendControlsHTML(profile) +
      '<a class="btn secondary" href="profile.html?u=' + encodeURIComponent(row.other_user_id) + '">Profile</a></div></article>';
  }

  async function init() {
    if (!SkillCloud.configured) {
      $('activityLiveRoot').innerHTML = '<div class="cloud-state"><h2>Live setup required</h2><p>' + esc(SkillCloud.setupMessage()) + '</p></div>';
      return;
    }
    try {
      await SkillCloud.requireUser();
      await loadActivityLive();
      channel = SkillCloud.subscribe('friendships', function () { loadActivityLive().catch(function () {}); });
    } catch (error) {
      $('activityLiveRoot').innerHTML = '<div class="cloud-state"><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>';
    }
  }

  window.loadActivityLive = async function () {
    const results = await Promise.all([SkillCloud.conversations(), SkillCloud.myCampaigns(), SkillCloud.listSpaces(), SkillCloud.friendships()]);
    const conversations = results[0];
    const campaigns = results[1];
    const spaces = results[2].filter(function (space) { return space.is_member; });
    const friendRows = results[3];
    const requests = friendRows.filter(function (row) { return row.relationship === 'incoming'; });
    const unread = conversations.filter(function (conversation) { return Number(conversation.unread_count) > 0; });
    const reviewed = campaigns.filter(function (campaign) { return ['active', 'rejected', 'paused', 'ended'].includes(campaign.status); });
    const cards = requests.map(requestCard);

    unread.forEach(function (conversation) {
      cards.push('<a class="person-card-live activity-link-card" href="chat.html?conversation=' + encodeURIComponent(conversation.conversation_id) + '"><span class="status-chip active">NEW MESSAGE</span><h3>' + esc(conversation.display_title) + '</h3><p>' + esc(conversation.last_message || 'Open conversation') + '</p><small class="muted">' + Number(conversation.unread_count) + ' unread</small></a>');
    });
    reviewed.forEach(function (campaign) {
      cards.push('<a class="person-card-live activity-link-card" href="ads.html"><span class="status-chip ' + esc(campaign.status) + '">CAMPAIGN ' + esc(campaign.status) + '</span><h3>' + esc(campaign.title) + '</h3><p>' + esc(campaign.review_note || 'Open the ads dashboard for campaign details.') + '</p></a>');
    });
    spaces.slice(0, 4).forEach(function (space) {
      cards.push('<a class="person-card-live activity-link-card" href="space.html?id=' + encodeURIComponent(space.id) + '"><span class="status-chip">' + esc(space.space_type) + '</span><h3>' + esc(space.name) + '</h3><p>' + space.post_count + ' posts · ' + space.member_count + ' members</p></a>');
    });

    $('activityLiveRoot').innerHTML = '<div class="admin-grid-live friend-activity-stats"><div class="admin-stat-card"><span>FRIEND REQUESTS</span><b>' + requests.length + '</b></div>' +
      '<div class="admin-stat-card"><span>UNREAD CHATS</span><b>' + unread.reduce(function (total, item) { return total + Number(item.unread_count); }, 0) + '</b></div>' +
      '<div class="admin-stat-card"><span>MY CAMPAIGNS</span><b>' + campaigns.length + '</b></div><div class="admin-stat-card"><span>JOINED SPACES</span><b>' + spaces.length + '</b></div></div>' +
      '<section class="people-live-grid">' + (cards.join('') || '<div class="cloud-state"><h2>You are all caught up</h2><p>Friend requests, new messages and campaign decisions will appear here.</p><a class="btn" href="search.html">Find people</a></div>') + '</section>';
  };

  window.addEventListener('skillswape:friendship-change', function () {
    loadActivityLive().catch(function (error) { toast(SkillCloud.cleanError(error)); });
  });
  window.addEventListener('beforeunload', function () {
    if (channel) SkillCloud.removeSubscription(channel);
  });
  init();
})();
