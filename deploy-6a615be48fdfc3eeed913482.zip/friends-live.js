(function () {
  'use strict';
  let channel = null;
  let refreshTimer = null;

  function avatarMarkup(profile) {
    const name = profile.full_name || 'Member';
    return '<div class="avatar lg">' + (profile.avatar_url
      ? '<img src="' + esc(profile.avatar_url) + '" alt="">'
      : esc(name.charAt(0).toUpperCase())) + '</div>';
  }

  function friendCard(row) {
    const profile = {
      id: row.other_user_id,
      full_name: row.full_name,
      headline: row.headline,
      avatar_url: row.avatar_url,
      is_private: row.is_private,
      relationship: row.relationship,
      friend_request_id: row.request_id
    };
    const note = row.relationship === 'incoming'
      ? 'Wants to connect with you.'
      : row.relationship === 'outgoing'
        ? 'Waiting for ' + esc(row.full_name) + ' to respond.'
        : 'Connected ' + timeAgo(row.responded_at || row.created_at) + '.';
    return '<article class="person-card-live friend-list-card"><div class="person-card-head">' + avatarMarkup(profile) +
      '<div><div class="name-with-badge"><b>' + esc(row.full_name) + '</b>' + (row.is_private ? '<span class="privacy-badge">Private</span>' : '') + '</div>' +
      '<small>' + esc(row.headline || 'SkillSwape Member') + '</small></div></div><p>' + note + '</p>' +
      '<div class="space-card-actions friend-card-actions">' + friendControlsHTML(profile, { message: row.relationship === 'friends' }) +
      '<a class="btn secondary" href="profile.html?u=' + encodeURIComponent(row.other_user_id) + '">Profile</a></div></article>';
  }

  function emptyState(title, text, action) {
    return '<div class="cloud-state compact-state"><h2>' + esc(title) + '</h2><p>' + esc(text) + '</p>' + (action || '') + '</div>';
  }

  async function loadFriends() {
    const rows = await SkillCloud.friendships();
    const incoming = rows.filter(function (row) { return row.relationship === 'incoming'; });
    const outgoing = rows.filter(function (row) { return row.relationship === 'outgoing'; });
    const accepted = rows.filter(function (row) { return row.relationship === 'friends'; });

    $('friendsCount').textContent = accepted.length;
    $('incomingCount').textContent = incoming.length;
    $('outgoingCount').textContent = outgoing.length;
    $('incomingFriends').innerHTML = incoming.map(friendCard).join('') || emptyState('No pending requests', 'New friend requests will appear here.');
    $('acceptedFriends').innerHTML = accepted.map(friendCard).join('') || emptyState('Build your network', 'Find people by skill, role or city and send your first request.', '<a class="btn" href="search.html">Find people</a>');
    $('outgoingFriends').innerHTML = outgoing.map(friendCard).join('') || emptyState('No sent requests', 'Requests you send will stay here until they are accepted or cancelled.');
    $('incomingFriendsSection').classList.toggle('has-requests', incoming.length > 0);
  }

  function queueRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(function () {
      loadFriends().catch(function (error) { toast(SkillCloud.cleanError(error)); });
    }, 180);
  }

  async function init() {
    if (!SkillCloud.configured) {
      $('incomingFriends').innerHTML = emptyState('Live setup required', SkillCloud.setupMessage());
      return;
    }
    try {
      await SkillCloud.requireUser();
      await loadFriends();
      channel = SkillCloud.subscribe('friendships', queueRefresh);
    } catch (error) {
      $('incomingFriends').innerHTML = emptyState('Friends unavailable', SkillCloud.cleanError(error));
    }
  }

  window.addEventListener('skillswape:friendship-change', queueRefresh);
  window.addEventListener('beforeunload', function () {
    if (channel) SkillCloud.removeSubscription(channel);
  });
  init();
})();
