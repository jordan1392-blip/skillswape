(function () {
  try {
    var mode = localStorage.getItem('skillswape_theme_v10') || localStorage.getItem('skillswape_pro_v3_theme');
    if (mode !== 'dark' && mode !== 'light') {
      mode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    var root = document.documentElement;
    root.setAttribute('data-theme', mode);
    if (!root.getAttribute('data-preset')) root.setAttribute('data-preset', 'neutral');
    root.style.colorScheme = mode;
    var meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'theme-color';
      document.head.appendChild(meta);
    }
    meta.content = mode === 'dark' ? '#080b12' : '#f4f6fb';
  } catch (_) {}
})();
