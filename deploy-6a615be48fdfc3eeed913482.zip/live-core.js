(function () {
  'use strict';
  if (window.SkillCloud) return;

  const cfg = window.SKILLSWAPE_CONFIG || {};
  const configured = /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(String(cfg.supabaseUrl || '').trim())
    && String(cfg.supabaseAnonKey || '').length > 30
    && !String(cfg.supabaseAnonKey || '').includes('YOUR_');
  const client = configured && window.supabase
    ? window.supabase.createClient(cfg.supabaseUrl.trim(), cfg.supabaseAnonKey.trim(), {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
        realtime: { params: { eventsPerSecond: 12 } }
      })
    : null;

  const state = { session: null, profile: null, ready: false };
  const CHAT_MAX_BYTES = 50 * 1024 * 1024;
  const CHAT_RESUMABLE_THRESHOLD = 6 * 1024 * 1024;

  function cleanError(error, fallback) {
    const raw = String((error && (error.message || error.error_description)) || fallback || 'Something went wrong');
    if (/discover_profiles|get_profile_for_viewer|send_friend_request|my_friendships/i.test(raw)) {
      return 'Friend/private account migration abhi Supabase mein run nahi hui. SQL Editor mein 20260723_friendships_privacy.sql run karein.';
    }
    if (/attachment_size|chat-media|chat_attachments_50mb/i.test(raw) && /column|schema|bucket|not found|cache/i.test(raw)) {
      return 'Chat attachment setup pending hai. Supabase SQL Editor mein 20260723_chat_attachments_50mb.sql run karein.';
    }
    if (/payload too large|maximum allowed size|maximum file size|entity too large|object exceeded|status.?413|\b413\b/i.test(raw)) {
      return 'Ye file Supabase Storage limit se bari hai. Chat mein maximum 50MB file send karein.';
    }
    if (/story-media/i.test(raw)) {
      return 'Story storage ready nahi hai. Supabase SQL Editor mein 20260723_story_upload_repair.sql run karein.';
    }
    if (/bucket not found/i.test(raw)) {
      return 'Storage setup pending hai. Supabase SQL Editor mein story aur chat attachment migrations run karein.';
    }
    if (/mime type|content.?type|not supported/i.test(raw)) {
      return 'Ye file format supported nahi. Photo, MP4/WebM/MOV video, PDF, Word, Excel, PowerPoint, TXT ya CSV use karein.';
    }
    if (/row-level security|violates row level security/i.test(raw) && /storage|object|stories/i.test(raw)) {
      return 'Story upload permission missing hai. Supabase mein story upload repair migration run karein.';
    }
    const messages = {
      'Invalid login credentials': 'Email ya password ghalat hai.',
      'Email not confirmed': 'Pehle apna email confirm karein, phir login karein.',
      'User already registered': 'Ye email pehle se registered hai.',
      'This account is private. Send a friend request first.': 'Ye account private hai. Pehle friend request send aur accept honi chahiye.'
    };
    return messages[raw] || raw.replace(/^Database error saving new user$/i, 'Account setup failed. Supabase schema dobara run karein.');
  }

  function setupMessage() {
    return 'Live backend setup required: config.js mein Supabase URL/key add karein, phir schema.sql aur friendships_privacy migration run karein.';
  }

  function assertConfigured() {
    if (!client) {
      if (typeof toast === 'function') toast(setupMessage());
      throw new Error(setupMessage());
    }
    return client;
  }

  function cachedSessionBootstrap() {
    if (!configured) return;
    try {
      const ref = new URL(cfg.supabaseUrl).hostname.split('.')[0];
      const raw = localStorage.getItem('sb-' + ref + '-auth-token');
      const stored = JSON.parse(raw || 'null');
      const authUser = stored && stored.user;
      if (!authUser || (stored.expires_at && stored.expires_at * 1000 < Date.now() - 60000)) return;
      localStorage.setItem(K + 'uid', authUser.id);
      const users = read('users', {});
      if (!users[authUser.id]) {
        users[authUser.id] = {
          uid: authUser.id,
          name: authUser.user_metadata && authUser.user_metadata.full_name || authUser.email && authUser.email.split('@')[0] || 'Member',
          email: authUser.email || '',
          role: authUser.user_metadata && authUser.user_metadata.headline || 'SkillSwape Member',
          location: authUser.user_metadata && authUser.user_metadata.location || '',
          skills: authUser.user_metadata && authUser.user_metadata.skills || [],
          bio: authUser.user_metadata && authUser.user_metadata.bio || '',
          photoURL: authUser.user_metadata && authUser.user_metadata.avatar_url || '',
          coverURL: '',
          gender: authUser.user_metadata && authUser.user_metadata.gender || 'other'
        };
        write('users', users);
      }
    } catch (_) {}
  }

  cachedSessionBootstrap();

  function profileToLocal(profile, authUser) {
    if (!profile && !authUser) return null;
    const metadata = authUser && authUser.user_metadata || {};
    const p = profile || {};
    return {
      uid: p.id || authUser.id,
      name: p.full_name || metadata.full_name || authUser.email && authUser.email.split('@')[0] || 'SkillSwape Member',
      email: authUser && authUser.email || '',
      role: p.headline || metadata.headline || 'SkillSwape Member',
      bio: p.bio || metadata.bio || '',
      location: p.location || metadata.location || '',
      skills: Array.isArray(p.skills) ? p.skills : Array.isArray(metadata.skills) ? metadata.skills : [],
      photoURL: p.avatar_url || metadata.avatar_url || '',
      coverURL: p.cover_url || '',
      gender: p.gender || metadata.gender || 'other',
      isPrivate: !!p.is_private,
      accountRole: p.account_role || 'member',
      appearance: read('appearance_' + (p.id || authUser.id), null) || { mode: getPreferredThemeMode(), preset: genderPreset(p.gender || metadata.gender), primary: '', background: '', font: 'modern' },
      createdAt: p.created_at || authUser && authUser.created_at || now()
    };
  }

  function cacheProfile(profile, authUser) {
    const local = profileToLocal(profile, authUser);
    if (!local) return null;
    const users = read('users', {});
    users[local.uid] = { ...(users[local.uid] || {}), ...local };
    write('users', users);
    localStorage.setItem(K + 'uid', local.uid);
    if (authUser || (state.session && state.session.user && state.session.user.id === local.uid)) state.profile = profile || local;
    return local;
  }

  async function hydrateProfile(authUser) {
    if (!authUser || !client) return null;
    const metadata = authUser.user_metadata || {};
    let data = await rawProfileView(authUser.id);
    const updates = {};
    if ((!data.full_name || data.full_name === 'SkillSwape Member') && metadata.full_name) updates.full_name = metadata.full_name;
    if ((!data.headline || data.headline === 'SkillSwape Member') && metadata.headline) updates.headline = metadata.headline;
    if (!data.bio && metadata.bio) updates.bio = metadata.bio;
    if (!data.location && metadata.location) updates.location = metadata.location;
    if ((!data.skills || !data.skills.length) && Array.isArray(metadata.skills)) updates.skills = metadata.skills;
    if (!data.gender && ['male', 'female', 'other'].includes(metadata.gender)) updates.gender = metadata.gender;
    if (!data.avatar_url && (metadata.avatar_url || metadata.picture)) updates.avatar_url = metadata.avatar_url || metadata.picture;
    let profile = data;
    if (Object.keys(updates).length) {
      const result = await client.from('profiles').update(updates).eq('id', authUser.id);
      if (!result.error) profile = await rawProfileView(authUser.id);
    }
    cacheProfile(profile, authUser);
    return profile;
  }

  const readyPromise = (async function () {
    if (!client) { state.ready = true; return state; }
    try {
      const { data, error } = await client.auth.getSession();
      if (error) throw error;
      state.session = data.session;
      if (data.session && data.session.user) await hydrateProfile(data.session.user);
      else localStorage.removeItem(K + 'uid');
    } catch (error) {
      console.error('SkillSwape cloud init:', error);
    } finally {
      state.ready = true;
    }
    return state;
  })();

  if (client) {
    client.auth.onAuthStateChange(function (_event, session) {
      state.session = session;
      if (session && session.user) setTimeout(function () { hydrateProfile(session.user).catch(console.error); }, 0);
      else { state.profile = null; localStorage.removeItem(K + 'uid'); }
    });
  }

  async function requireUser(options) {
    assertConfigured();
    await readyPromise;
    const result = await client.auth.getUser();
    if (result.error || !result.data.user) {
      if (!options || options.redirect !== false) location.replace('login.html?next=' + encodeURIComponent(location.pathname.split('/').pop() + location.search));
      throw result.error || new Error('Login required');
    }
    if (!state.profile) await hydrateProfile(result.data.user);
    return result.data.user;
  }

  async function upload(bucket, file, options) {
    const authUser = await requireUser({ redirect: false });
    if (!file) return null;
    const maxMb = options && options.maxMb || 15;
    if (file.size > maxMb * 1024 * 1024) throw new Error('File ' + maxMb + 'MB se choti honi chahiye.');
    const nameParts = String(file.name || '').split('.');
    const contentType = options && options.contentType || inferFileMime(file);
    const fallbackExtensions = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/heic': 'heic', 'image/heif': 'heif', 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'video/3gpp': '3gp', 'application/pdf': 'pdf', 'application/msword': 'doc', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx', 'application/vnd.ms-excel': 'xls', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx', 'application/vnd.ms-powerpoint': 'ppt', 'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx', 'text/plain': 'txt', 'text/csv': 'csv' };
    const ext = (nameParts.length > 1 ? nameParts.pop() : fallbackExtensions[contentType] || 'bin').replace(/[^a-z0-9]/gi, '').toLowerCase();
    const path = authUser.id + '/' + Date.now() + '-' + crypto.randomUUID() + '.' + ext;
    const result = await client.storage.from(bucket).upload(path, file, { cacheControl: '3600', upsert: false, contentType: contentType });
    if (result.error) throw result.error;
    if (options && options.private) return { path: result.data.path, url: '' };
    const publicResult = client.storage.from(bucket).getPublicUrl(result.data.path);
    return { path: result.data.path, url: publicResult.data.publicUrl, contentType: contentType };
  }

  function inferFileMime(file) {
    let type = String(file && file.type || '').toLowerCase().trim();
    if (type === 'image/jpg') type = 'image/jpeg';
    if (type && type !== 'application/octet-stream') return type;
    const ext = String(file && file.name || '').split('.').pop().toLowerCase();
    return ({ jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', heic: 'image/heic', heif: 'image/heif', mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', qt: 'video/quicktime', '3gp': 'video/3gpp', pdf: 'application/pdf', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', txt: 'text/plain', csv: 'text/csv', odt: 'application/vnd.oasis.opendocument.text', ods: 'application/vnd.oasis.opendocument.spreadsheet', odp: 'application/vnd.oasis.opendocument.presentation' })[ext] || 'application/octet-stream';
  }

  function chatFileKind(file) {
    const type = inferFileMime(file);
    if (/^image\/(jpeg|png|webp|gif|heic|heif)$/.test(type)) return 'photo';
    if (/^video\/(mp4|webm|quicktime|3gpp|x-m4v)$/.test(type)) return 'video';
    if (/^(application\/(pdf|msword|vnd\.openxmlformats-officedocument\.wordprocessingml\.document|vnd\.ms-excel|vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet|vnd\.ms-powerpoint|vnd\.openxmlformats-officedocument\.presentationml\.presentation|vnd\.oasis\.opendocument\.(text|spreadsheet|presentation))|text\/(plain|csv))$/.test(type)) return 'document';
    return '';
  }

  function chatUploadPath(authUser, file, contentType) {
    const nameParts = String(file && file.name || '').split('.');
    const fallbackExtensions = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/heic': 'heic', 'image/heif': 'heif', 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'video/3gpp': '3gp', 'application/pdf': 'pdf', 'application/msword': 'doc', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx', 'application/vnd.ms-excel': 'xls', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx', 'application/vnd.ms-powerpoint': 'ppt', 'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx', 'text/plain': 'txt', 'text/csv': 'csv', 'application/vnd.oasis.opendocument.text': 'odt', 'application/vnd.oasis.opendocument.spreadsheet': 'ods', 'application/vnd.oasis.opendocument.presentation': 'odp' };
    const ext = (nameParts.length > 1 ? nameParts.pop() : fallbackExtensions[contentType] || 'bin').replace(/[^a-z0-9]/gi, '').toLowerCase() || fallbackExtensions[contentType] || 'bin';
    return authUser.id + '/' + Date.now() + '-' + crypto.randomUUID() + '.' + ext;
  }

  async function uploadChatMedia(file, onProgress) {
    const authUser = await requireUser({ redirect: false });
    if (!file) return null;
    if (file.size > CHAT_MAX_BYTES) throw new Error('File 50MB ya us se choti honi chahiye.');
    const kind = chatFileKind(file);
    if (!kind) throw new Error('Ye file format supported nahi. Photo, video ya document select karein.');
    const contentType = inferFileMime(file);
    const path = chatUploadPath(authUser, file, contentType);
    const report = function (uploaded, total) {
      if (typeof onProgress === 'function') onProgress(uploaded, total || file.size);
    };
    report(0, file.size);

    if (file.size > CHAT_RESUMABLE_THRESHOLD) {
      if (!window.tus || !window.tus.Upload) throw new Error('Large-file uploader load nahi hua. Page refresh karke dobara try karein.');
      const sessionResult = await client.auth.getSession();
      if (sessionResult.error) throw sessionResult.error;
      const session = sessionResult.data && sessionResult.data.session;
      if (!session || !session.access_token) throw new Error('Login session expire ho gayi hai. Dobara login karein.');
      const projectId = new URL(cfg.supabaseUrl).hostname.split('.')[0];
      await new Promise(function (resolve, reject) {
        const resumable = new window.tus.Upload(file, {
          endpoint: 'https://' + projectId + '.storage.supabase.co/storage/v1/upload/resumable',
          retryDelays: [0, 3000, 5000, 10000, 20000],
          headers: { authorization: 'Bearer ' + session.access_token, apikey: cfg.supabaseAnonKey },
          uploadDataDuringCreation: true,
          removeFingerprintOnSuccess: true,
          chunkSize: 6 * 1024 * 1024,
          metadata: { bucketName: 'chat-media', objectName: path, contentType: contentType, cacheControl: '3600' },
          onError: reject,
          onProgress: report,
          onSuccess: resolve
        });
        resumable.start();
      });
    } else {
      const result = await client.storage.from('chat-media').upload(path, file, { cacheControl: '3600', upsert: false, contentType: contentType });
      if (result.error) throw result.error;
      report(file.size, file.size);
    }
    return { path: path, url: '', contentType: contentType, size: file.size, kind: kind };
  }

  async function signedChatUrl(path) {
    if (!path) return '';
    const result = await client.storage.from('chat-media').createSignedUrl(path, 3600);
    return result.error ? '' : result.data.signedUrl;
  }

  async function rawProfileView(id) {
    const result = await client.rpc('get_profile_for_viewer', { p_profile_id: id });
    if (result.error) throw result.error;
    const profile = Array.isArray(result.data) ? result.data[0] : result.data;
    if (!profile) throw new Error('Member not found');
    return profile;
  }

  async function listProfiles(query) {
    await requireUser();
    const result = await client.rpc('discover_profiles', { p_query: String(query || '').trim() || null });
    if (result.error) throw result.error;
    const users = read('users', {});
    (result.data || []).forEach(function (p) { users[p.id] = { ...(users[p.id] || {}), ...profileToLocal(p, null) }; });
    write('users', users);
    return result.data || [];
  }

  async function getProfile(id) {
    await requireUser();
    const profile = await rawProfileView(id);
    cacheProfile(profile, id === state.session?.user?.id ? state.session.user : null);
    return profile;
  }

  async function updateProfile(values) {
    const authUser = await requireUser();
    const allowed = ['full_name','headline','bio','location','skills','avatar_url','cover_url','gender','is_private'];
    const payload = {};
    allowed.forEach(function (key) { if (Object.prototype.hasOwnProperty.call(values, key)) payload[key] = values[key]; });
    const result = await client.from('profiles').update(payload).eq('id', authUser.id);
    if (result.error) throw result.error;
    const profile = await rawProfileView(authUser.id);
    cacheProfile(profile, authUser);
    return profile;
  }

  async function friendshipStatus(otherUserId) {
    await requireUser();
    const result = await client.rpc('friendship_status', { p_other_user: otherUserId });
    if (result.error) throw result.error;
    return Array.isArray(result.data) ? (result.data[0] || { relationship: 'none' }) : result.data;
  }

  async function friendships() {
    await requireUser();
    const result = await client.rpc('my_friendships');
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function sendFriendRequest(otherUserId) {
    await requireUser();
    const result = await client.rpc('send_friend_request', { p_other_user: otherUserId });
    if (result.error) throw result.error;
    return result.data;
  }

  async function respondFriendRequest(requestId, accept) {
    await requireUser();
    const result = await client.rpc('respond_friend_request', { p_request_id: requestId, p_accept: !!accept });
    if (result.error) throw result.error;
  }

  async function cancelFriendRequest(requestId) {
    await requireUser();
    const result = await client.rpc('cancel_friend_request', { p_request_id: requestId });
    if (result.error) throw result.error;
  }

  async function removeFriend(otherUserId) {
    await requireUser();
    const result = await client.rpc('remove_friend', { p_other_user: otherUserId });
    if (result.error) throw result.error;
  }

  async function conversations() {
    await requireUser();
    const result = await client.rpc('my_conversations');
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function openDirect(otherUserId) {
    await requireUser();
    const result = await client.rpc('get_or_create_direct_conversation', { p_other_user: otherUserId });
    if (result.error) throw result.error;
    return result.data;
  }

  async function messages(conversationId) {
    await requireUser();
    const result = await client.from('messages')
      .select('*,sender:profiles!messages_sender_id_fkey(id,full_name,avatar_url,headline)')
      .eq('conversation_id', conversationId).is('deleted_at', null).order('created_at').limit(300);
    if (result.error) throw result.error;
    await Promise.all(result.data.map(async function (message) {
      if (message.attachment_path) message.attachment_url = await signedChatUrl(message.attachment_path);
    }));
    return result.data;
  }

  async function fetchMessage(id) {
    const result = await client.from('messages').select('*,sender:profiles!messages_sender_id_fkey(id,full_name,avatar_url,headline)').eq('id', id).single();
    if (result.error) throw result.error;
    if (result.data.attachment_path) result.data.attachment_url = await signedChatUrl(result.data.attachment_path);
    return result.data;
  }

  async function sendMessage(conversationId, body, file, onProgress) {
    const authUser = await requireUser();
    let attachment = null;
    if (file) attachment = await uploadChatMedia(file, onProgress);
    const payload = {
      conversation_id: conversationId,
      sender_id: authUser.id,
      body: String(body || '').trim(),
      attachment_path: attachment && attachment.path,
      attachment_name: file && file.name,
      attachment_type: attachment && attachment.contentType
    };
    if (attachment) payload.attachment_size = attachment.size;
    const result = await client.from('messages').insert(payload).select('*,sender:profiles!messages_sender_id_fkey(id,full_name,avatar_url,headline)').single();
    if (result.error) {
      if (attachment) await client.storage.from('chat-media').remove([attachment.path]).catch(function () {});
      throw result.error;
    }
    if (attachment) result.data.attachment_url = await signedChatUrl(attachment.path);
    return result.data;
  }

  async function markConversationRead(conversationId) {
    const authUser = await requireUser();
    const result = await client.from('conversation_members').update({ last_read_at: new Date().toISOString() }).eq('conversation_id', conversationId).eq('user_id', authUser.id);
    if (result.error) throw result.error;
  }

  function chatChannel(conversationId, onMessage, onTyping) {
    assertConfigured();
    const channel = client.channel('chat-' + conversationId, { config: { broadcast: { self: false } } })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: 'conversation_id=eq.' + conversationId }, async function (payload) {
        try { onMessage(await fetchMessage(payload.new.id)); } catch (error) { console.error(error); }
      })
      .on('broadcast', { event: 'typing' }, function (payload) { if (onTyping) onTyping(payload.payload || {}); })
      .subscribe();
    return channel;
  }

  function sendTyping(channel, payload) {
    if (channel) channel.send({ type: 'broadcast', event: 'typing', payload: payload || {} });
  }

  function removeChannel(channel) { if (client && channel) client.removeChannel(channel); }

  async function listSpaces(type) {
    const authUser = await requireUser();
    let request = client.from('spaces').select('*,members:space_members(user_id,member_role),posts:space_posts(count)').order('created_at', { ascending: false });
    if (type) request = request.eq('space_type', type);
    const result = await request;
    if (result.error) throw result.error;
    return (result.data || []).map(function (space) {
      space.is_member = (space.members || []).some(function (m) { return m.user_id === authUser.id; });
      space.my_role = ((space.members || []).find(function (m) { return m.user_id === authUser.id; }) || {}).member_role || '';
      space.member_count = (space.members || []).length;
      space.post_count = space.posts && space.posts[0] && Number(space.posts[0].count) || 0;
      return space;
    });
  }

  async function getSpace(id) {
    const spaces = await listSpaces();
    const space = spaces.find(function (s) { return s.id === id; });
    if (!space) throw new Error('Community ya group nahi mila.');
    return space;
  }

  async function createSpace(values, coverFile) {
    await requireUser();
    let cover = '';
    if (coverFile) cover = (await upload('community-media', coverFile, { maxMb: 8 })).url;
    const result = await client.rpc('create_space', {
      p_name: values.name,
      p_description: values.description || '',
      p_space_type: values.space_type,
      p_privacy: values.privacy || 'public',
      p_category: values.category || 'General',
      p_cover_url: cover || null
    });
    if (result.error) throw result.error;
    return result.data;
  }

  async function joinSpace(id) {
    await requireUser();
    const result = await client.rpc('join_space', { p_space_id: id });
    if (result.error) throw result.error;
  }

  async function requestSpace(id) {
    await requireUser();
    const result = await client.rpc('request_space_access', { p_space_id: id });
    if (result.error) throw result.error;
  }

  async function listJoinRequests(spaceId) {
    await requireUser();
    const result = await client.from('space_join_requests')
      .select('*,requester:profiles!space_join_requests_user_id_fkey(id,full_name,headline,avatar_url)')
      .eq('space_id', spaceId).eq('status', 'pending').order('created_at');
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function reviewSpaceRequest(id, approve) {
    await requireUser();
    const result = await client.rpc('review_space_request', { p_request_id: id, p_approve: !!approve });
    if (result.error) throw result.error;
  }

  async function listPosts(options) {
    const authUser = await requireUser();
    options = options || {};
    let request = client.from('space_posts').select(
      '*,author:profiles!space_posts_author_id_fkey(id,full_name,headline,avatar_url),space:spaces(id,name,slug,space_type,privacy),post_likes(user_id),post_comments(id)'
    ).order('created_at', { ascending: false }).limit(options.limit || 80);
    if (options.spaceId) request = request.eq('space_id', options.spaceId);
    if (options.authorId) request = request.eq('author_id', options.authorId);
    if (options.category) request = request.eq('category', options.category);
    const result = await request;
    if (result.error) throw result.error;
    return (result.data || []).map(function (post) {
      post.like_count = (post.post_likes || []).length;
      post.comment_count = (post.post_comments || []).length;
      post.liked = (post.post_likes || []).some(function (like) { return like.user_id === authUser.id; });
      return post;
    });
  }

  async function createPost(values, mediaFiles) {
    const authUser = await requireUser();
    const files = mediaFiles ? Array.from(mediaFiles.length !== undefined && !mediaFiles.name ? mediaFiles : [mediaFiles]).filter(Boolean) : [];
    if (files.length > 10) throw new Error('Ek post mein maximum 10 photos upload ho sakti hain.');
    const videos = files.filter(function (file) { return inferFileMime(file).startsWith('video/'); });
    if (videos.length && files.length > 1) throw new Error('Video ke sath multiple media allowed nahi. Ek video ya maximum 10 photos select karein.');
    if (files.some(function (file) { return file.size > 25 * 1024 * 1024; })) throw new Error('Har photo ya video 25MB se choti honi chahiye.');
    if (files.reduce(function (sum, file) { return sum + file.size; }, 0) > 100 * 1024 * 1024) throw new Error('Selected media ka total size 100MB se chota rakhein.');

    const uploads = [];
    for (const file of files) uploads.push(await upload('community-media', file, { maxMb: 25 }));
    const type = files.length ? (videos.length ? 'video' : 'image') : null;
    const mediaUrl = uploads.length > 1 ? JSON.stringify(uploads.map(function (item) { return item.url; })) : (uploads[0] && uploads[0].url || null);
    const result = await client.from('space_posts').insert({
      space_id: values.space_id || null,
      author_id: authUser.id,
      title: values.title || '',
      body: values.body || '',
      category: values.category || 'Daily Update',
      media_url: mediaUrl,
      media_type: type
    }).select().single();
    if (result.error) throw result.error;
    return result.data;
  }

  async function deletePost(id) {
    await requireUser();
    const result = await client.from('space_posts').delete().eq('id', id);
    if (result.error) throw result.error;
  }

  async function toggleLike(post) {
    const authUser = await requireUser();
    const request = post.liked
      ? client.from('post_likes').delete().eq('post_id', post.id).eq('user_id', authUser.id)
      : client.from('post_likes').insert({ post_id: post.id, user_id: authUser.id });
    const result = await request;
    if (result.error) throw result.error;
  }

  async function comments(postId) {
    await requireUser();
    const result = await client.from('post_comments')
      .select('*,author:profiles!post_comments_author_id_fkey(id,full_name,avatar_url)')
      .eq('post_id', postId).order('created_at').limit(100);
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function addComment(postId, body) {
    const authUser = await requireUser();
    const result = await client.from('post_comments').insert({ post_id: postId, author_id: authUser.id, body: String(body || '').trim() });
    if (result.error) throw result.error;
  }

  async function stories() {
    const authUser = await requireUser();
    const result = await client.from('stories')
      .select('*,author:profiles!stories_author_id_fkey(id,full_name,avatar_url),story_views(viewer_id)')
      .gt('expires_at', new Date().toISOString()).order('created_at', { ascending: false });
    if (result.error) throw result.error;
    return (result.data || []).map(function (story) {
      story.viewed = (story.story_views || []).some(function (view) { return view.viewer_id === authUser.id; });
      story.view_count = (story.story_views || []).length;
      return story;
    });
  }

  async function createStory(file, caption) {
    const authUser = await requireUser();
    if (!file) throw new Error('Story ke liye photo ya video select karein.');
    const contentType = inferFileMime(file);
    const allowed = ['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime','video/3gpp'];
    if (!allowed.includes(contentType)) throw new Error('Unsupported story media type');
    const media = await upload('story-media', file, { maxMb: 50, contentType: contentType });
    const result = await client.from('stories').insert({
      author_id: authUser.id,
      media_url: media.url,
      media_type: contentType.startsWith('video/') ? 'video' : 'image',
      caption: String(caption || '').trim()
    }).select().single();
    if (result.error) {
      await client.storage.from('story-media').remove([media.path]).catch(function () {});
      throw result.error;
    }
    return result.data;
  }

  async function viewStory(id) {
    const authUser = await requireUser();
    const result = await client.from('story_views').upsert({ story_id: id, viewer_id: authUser.id }, { onConflict: 'story_id,viewer_id', ignoreDuplicates: true });
    if (result.error) throw result.error;
  }

  async function adPackages() {
    await requireUser();
    const result = await client.from('ad_packages').select('*').eq('active', true).order('price_pkr');
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function myCampaigns() {
    const authUser = await requireUser();
    const result = await client.from('ad_campaigns')
      .select('*,package:ad_packages(*)').eq('owner_id', authUser.id).order('created_at', { ascending: false });
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function createCampaign(values, creativeFile) {
    const authUser = await requireUser();
    if (!creativeFile) throw new Error('Ad creative image select karein.');
    const creative = await upload('ad-creatives', creativeFile, { maxMb: 10 });
    const result = await client.from('ad_campaigns').insert({
      owner_id: authUser.id,
      package_id: Number(values.package_id),
      title: values.title,
      caption: values.caption,
      creative_url: creative.url,
      target_url: values.target_url || null,
      audience: values.audience || 'All members',
      status: 'pending'
    }).select().single();
    if (result.error) throw result.error;
    if (values.payment_reference) {
      const payment = await client.from('ad_payment_details').insert({ campaign_id: result.data.id, owner_id: authUser.id, payment_reference: values.payment_reference });
      if (payment.error) {
        await client.from('ad_campaigns').delete().eq('id', result.data.id);
        throw payment.error;
      }
    }
    return result.data;
  }

  async function activeAds() {
    await requireUser();
    const result = await client.from('ad_campaigns').select('id,owner_id,package_id,title,caption,creative_url,target_url,audience,status,starts_at,ends_at,impressions,clicks,created_at,owner:profiles!ad_campaigns_owner_id_fkey(full_name,avatar_url),package:ad_packages(name,price_pkr)')
      .eq('status', 'active').or('starts_at.is.null,starts_at.lte.' + new Date().toISOString()).or('ends_at.is.null,ends_at.gt.' + new Date().toISOString()).limit(5);
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function recordAd(id, eventType) {
    await requireUser();
    const result = await client.rpc('record_ad_event', { p_campaign_id: id, p_event_type: eventType });
    if (result.error) throw result.error;
  }

  async function pendingCampaigns() {
    await requireUser();
    const result = await client.from('ad_campaigns')
      .select('*,owner:profiles!ad_campaigns_owner_id_fkey(id,full_name,headline,avatar_url),package:ad_packages(*),payment:ad_payment_details(payment_reference)')
      .in('status', ['pending','active','paused']).order('created_at');
    if (result.error) throw result.error;
    return result.data || [];
  }

  async function reviewCampaign(id, status, note) {
    await requireUser();
    const allowed = ['active','paused','rejected','ended'];
    if (!allowed.includes(status)) throw new Error('Invalid campaign status');
    const payload = { status: status, review_note: note || null };
    if (status === 'active') {
      const campaignResult = await client.from('ad_campaigns').select('package:ad_packages(duration_days)').eq('id', id).single();
      if (campaignResult.error) throw campaignResult.error;
      const days = campaignResult.data.package.duration_days;
      payload.starts_at = new Date().toISOString();
      payload.ends_at = new Date(Date.now() + days * 86400000).toISOString();
    }
    const result = await client.from('ad_campaigns').update(payload).eq('id', id);
    if (result.error) throw result.error;
  }

  function subscribe(table, callback, filter) {
    assertConfigured();
    const spec = { event: '*', schema: 'public', table: table };
    if (filter) spec.filter = filter;
    return client.channel('live-' + table + '-' + crypto.randomUUID()).on('postgres_changes', spec, callback).subscribe();
  }

  async function sidebarStats() {
    await requireUser();
    const results = await Promise.all([
      client.from('profiles').select('id', { count: 'exact', head: true }),
      client.from('space_posts').select('*', { count: 'exact', head: true }),
      client.from('spaces').select('*', { count: 'exact', head: true })
    ]);
    return { members: results[0].count || 0, posts: results[1].count || 0, spaces: results[2].count || 0 };
  }

  window.SkillCloud = {
    configured: configured,
    client: client,
    state: state,
    ready: function () { return readyPromise; },
    requireUser: requireUser,
    setupMessage: setupMessage,
    cleanError: cleanError,
    upload: upload,
    inferFileMime: inferFileMime,
    chatFileKind: chatFileKind,
    chatMaxBytes: CHAT_MAX_BYTES,
    listProfiles: listProfiles,
    getProfile: getProfile,
    updateProfile: updateProfile,
    friendshipStatus: friendshipStatus,
    friendships: friendships,
    sendFriendRequest: sendFriendRequest,
    respondFriendRequest: respondFriendRequest,
    cancelFriendRequest: cancelFriendRequest,
    removeFriend: removeFriend,
    conversations: conversations,
    openDirect: openDirect,
    messages: messages,
    sendMessage: sendMessage,
    markConversationRead: markConversationRead,
    chatChannel: chatChannel,
    sendTyping: sendTyping,
    removeChannel: removeChannel,
    listSpaces: listSpaces,
    getSpace: getSpace,
    createSpace: createSpace,
    joinSpace: joinSpace,
    requestSpace: requestSpace,
    listJoinRequests: listJoinRequests,
    reviewSpaceRequest: reviewSpaceRequest,
    listPosts: listPosts,
    createPost: createPost,
    deletePost: deletePost,
    toggleLike: toggleLike,
    comments: comments,
    addComment: addComment,
    stories: stories,
    createStory: createStory,
    viewStory: viewStory,
    adPackages: adPackages,
    myCampaigns: myCampaigns,
    createCampaign: createCampaign,
    activeAds: activeAds,
    recordAd: recordAd,
    pendingCampaigns: pendingCampaigns,
    reviewCampaign: reviewCampaign,
    subscribe: subscribe,
    removeSubscription: removeChannel,
    sidebarStats: sidebarStats
  };

  window.friendControlsHTML = function (profile, options) {
    profile = profile || {};
    options = options || {};
    const relationship = profile.relationship || 'none';
    const userId = String(profile.id || profile.other_user_id || '');
    const requestId = String(profile.friend_request_id || profile.request_id || '');
    let controls = '';
    if (relationship === 'none') {
      controls += '<button class="btn friend-action" data-friend-action onclick="runFriendAction(this,\'send\',\'' + userId + '\',\'\')">Add friend</button>';
    } else if (relationship === 'outgoing') {
      controls += '<button class="btn secondary friend-action" data-friend-action onclick="runFriendAction(this,\'cancel\',\'' + userId + '\',\'' + requestId + '\')">Requested · Cancel</button>';
    } else if (relationship === 'incoming') {
      controls += '<button class="btn friend-action" data-friend-action onclick="runFriendAction(this,\'accept\',\'' + userId + '\',\'' + requestId + '\')">Accept</button>';
      controls += '<button class="btn secondary friend-action" data-friend-action onclick="runFriendAction(this,\'reject\',\'' + userId + '\',\'' + requestId + '\')">Decline</button>';
    } else if (relationship === 'friends') {
      controls += '<button class="btn secondary friend-action is-friend" data-friend-action onclick="runFriendAction(this,\'remove\',\'' + userId + '\',\'' + requestId + '\')">✓ Friends</button>';
    }
    if (options.message && (!profile.is_private || relationship === 'friends')) {
      controls += '<a class="btn secondary" href="chat.html?user=' + encodeURIComponent(userId) + '">Message</a>';
    }
    return controls;
  };

  window.runFriendAction = async function (button, action, userId, requestId) {
    if (action === 'remove' && !confirm('Remove this person from your friends?')) return;
    const container = button && button.parentElement;
    const buttons = container ? container.querySelectorAll('[data-friend-action]') : [button];
    buttons.forEach(function (item) { if (item) item.disabled = true; });
    try {
      let nextRelationship = 'none';
      let nextRequestId = '';
      if (action === 'send') {
        nextRequestId = await SkillCloud.sendFriendRequest(userId);
        nextRelationship = 'outgoing';
        toast('Friend request sent');
      } else if (action === 'accept') {
        await SkillCloud.respondFriendRequest(requestId, true);
        nextRelationship = 'friends';
        nextRequestId = requestId;
        toast('Friend request accepted');
      } else if (action === 'reject') {
        await SkillCloud.respondFriendRequest(requestId, false);
        toast('Friend request declined');
      } else if (action === 'cancel') {
        await SkillCloud.cancelFriendRequest(requestId);
        toast('Friend request cancelled');
      } else if (action === 'remove') {
        await SkillCloud.removeFriend(userId);
        toast('Friend removed');
      }
      window.dispatchEvent(new CustomEvent('skillswape:friendship-change', { detail: {
        userId: userId,
        requestId: nextRequestId,
        relationship: nextRelationship,
        action: action
      }}));
    } catch (error) {
      toast(SkillCloud.cleanError(error));
      buttons.forEach(function (item) { if (item) item.disabled = false; });
    }
  };

  window.loginUser = async function (email, password) {
    if (!client) { toast(setupMessage()); return false; }
    try {
      const result = await client.auth.signInWithPassword({ email: normalizeEmail(email), password: String(password || '') });
      if (result.error) throw result.error;
      await hydrateProfile(result.data.user);
      toast('Login successful');
      const next = new URLSearchParams(location.search).get('next');
      setTimeout(function () { location.href = next && !next.includes('://') ? next : 'daily-feed.html'; }, 300);
      return true;
    } catch (error) { toast(cleanError(error)); return false; }
  };

  window.signupUser = async function (data) {
    if (!client) { toast(setupMessage()); return false; }
    const name = String(data.name || '').trim();
    const email = normalizeEmail(data.email);
    const password = String(data.password || '');
    const gender = ['male','female','other'].includes(data.gender) ? data.gender : 'other';
    const skills = String(data.skills || '').split(',').map(function (item) { return item.trim(); }).filter(Boolean).slice(0, 20);
    if (!name || !email || password.length < 6) { toast('Name, valid email aur minimum 6-character password required hai.'); return false; }
    try {
      const result = await client.auth.signUp({
        email: email,
        password: password,
        options: {
          emailRedirectTo: (cfg.siteUrl || location.origin) + '/login.html',
          data: { full_name: name, headline: String(data.role || 'SkillSwape Member').trim(), gender: gender, location: String(data.location || '').trim(), bio: String(data.bio || '').trim(), skills: skills }
        }
      });
      if (result.error) throw result.error;
      if (result.data.session) {
        await hydrateProfile(result.data.user);
        toast('Account created successfully');
        setTimeout(function () { location.href = 'daily-feed.html'; }, 500);
      } else {
        toast('Account created. Inbox mein confirmation email check karein.');
        setTimeout(function () { location.href = 'login.html?confirmed=pending'; }, 1200);
      }
      return true;
    } catch (error) { toast(cleanError(error)); return false; }
  };

  window.logout = async function () {
    try { if (client) await client.auth.signOut(); } catch (_) {}
    localStorage.removeItem(K + 'uid');
    toast('Logged out');
    setTimeout(function () { location.href = 'login.html'; }, 250);
  };

  window.requestPasswordReset = async function (email) {
    if (!client) return toast(setupMessage());
    const value = normalizeEmail(email);
    if (!value) return toast('Pehle apna email address enter karein.');
    const result = await client.auth.resetPasswordForEmail(value, { redirectTo: (cfg.siteUrl || location.origin) + '/reset-password.html' });
    toast(result.error ? cleanError(result.error) : 'Password reset link email kar diya gaya hai.');
  };

  window.initGoogleAuth = function (targetId) {
    const target = $(targetId);
    if (!target) return;
    target.innerHTML = '<button type="button" class="google-cloud-button" onclick="SkillCloud.signInGoogle()"><span>G</span> Continue with Google</button>';
  };

  window.SkillCloud.signInGoogle = async function () {
    if (!client) return toast(setupMessage());
    const result = await client.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: (cfg.siteUrl || location.origin) + '/daily-feed.html' } });
    if (result.error) toast(cleanError(result.error));
  };

  let autoHideHeaderBound = false;
  function installAutoHideHeader() {
    if (autoHideHeaderBound) return;
    autoHideHeaderBound = true;
    let lastY = Math.max(0, window.scrollY);
    let ticking = false;
    window.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        const header = document.querySelector('.live-topbar');
        const currentY = Math.max(0, window.scrollY);
        if (header) {
          const movingDown = currentY > lastY + 7;
          const movingUp = currentY < lastY - 5;
          if (currentY < 52 || movingUp || document.body.classList.contains('mobile-menu-open')) header.classList.remove('topbar-hidden');
          else if (movingDown && currentY > 110) header.classList.add('topbar-hidden');
        }
        lastY = currentY;
        ticking = false;
      });
    }, { passive: true });
    document.addEventListener('focusin', function (event) {
      const header = document.querySelector('.live-topbar');
      if (header && header.contains(event.target)) header.classList.remove('topbar-hidden');
    });
  }

  window.toggleMobileMenu = function (show) {
    const sheet = $('mobileNavSheet');
    const trigger = $('mobileMoreButton');
    const open = typeof show === 'boolean' ? show : !(sheet && sheet.classList.contains('open'));
    if (sheet) sheet.classList.toggle('open', open);
    if (trigger) trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.body.classList.toggle('mobile-menu-open', open);
  };

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') toggleMobileMenu(false);
  });

  window.layout = function (active) {
    active = active || 'feed';
    if (!isLoggedIn()) {
      if (client && (location.search.includes('code=') || location.hash.includes('access_token'))) {
        document.write('<div class="page-center"><div class="panel card"><div class="live-loading">Completing secure sign-in</div></div></div>');
        readyPromise.then(function () { location.replace(state.session ? 'daily-feed.html' : 'login.html'); });
        return;
      }
      location.replace('login.html?next=' + encodeURIComponent(location.pathname.split('/').pop() + location.search));
      document.write('<div class="page-center"><div class="panel card"><h2>Login required</h2><p class="muted">Secure session check ho rahi hai...</p></div></div>');
      return;
    }
    const u = user();
    const link = function (key, href, label, badge) { return '<a class="' + (active === key ? 'active' : '') + '" href="' + href + '"><span>' + label + '</span>' + (badge ? '<i class="nav-new">' + badge + '</i>' : '') + '</a>'; };
    const mobileLink = function (key, href, label, icon, extra) { return '<a class="' + (active === key ? 'active ' : '') + (extra || '') + '" href="' + href + '"><i>' + icon + '</i><span>' + label + '</span></a>'; };
    const moreActive = ['feed','friends','chat','groups'].indexOf(active) === -1 ? ' active' : '';
    document.write('<div class="app live-shell"><aside class="sidebar panel">' +
      '<a class="brand" href="daily-feed.html"><div class="logo" aria-hidden="true">S</div><div><h2>SkillSwape <span class="gradient">AI</span></h2><small>Real skills. Real people.</small></div></a>' +
      '<a class="mini-profile" href="profile.html"><div>' + avatar(u, 'sm') + '</div><div><b>' + esc(u.name) + '</b><p>' + esc(u.role) + '</p></div><span class="live-dot" title="Live account"></span></a>' +
      '<div class="section-title">Connect</div><nav class="nav">' +
      link('feed','daily-feed.html','Home Feed') + link('chat','chat.html','Live Chat','LIVE') + link('friends','friends.html','Friends') + link('communities','communities.html','Communities') + link('groups','groups.html','Groups') + link('search','search.html','Find People') +
      '</nav><div class="section-title">Create & grow</div><nav class="nav">' +
      link('market','marketplace.html','Marketplace') + link('ads','ads.html','Advertise') + link('profile','profile.html','My Profile') +
      '</nav><div class="section-title">Tools</div><nav class="nav">' +
      link('ai','ai-assistant.html','AI Assistant') + link('games','games.html','Skill Games') + link('notify','notifications.html','Notifications') + link('settings','settings.html','Settings') +
      '<a id="adminNavLink" class="' + (active === 'admin' ? 'active' : '') + ' hide" href="admin.html"><span>Admin Panel</span></a>' +
      '<button onclick="logout()" class="logout-nav"><span>Logout</span></button></nav>' +
      '<div class="sidebar-theme-row"><span><b>Appearance</b><small>Saved on this device</small></span>' + themeToggleHTML() + '</div>' +
      '<div class="sidebar-live-card"><span class="status-pulse"></span><div><b>Realtime connected</b><small>Messages and posts sync live</small></div></div>' +
      '</aside><nav class="mobile-bottom-nav" aria-label="Mobile navigation">' +
      mobileLink('feed','daily-feed.html','Home','⌂') + mobileLink('friends','friends.html','Friends','◎') + mobileLink('chat','chat.html','Chat','✦','mobile-chat-action') + mobileLink('groups','groups.html','Groups','◉') +
      '<button id="mobileMoreButton" class="mobile-more-action' + moreActive + '" type="button" aria-expanded="false" onclick="toggleMobileMenu()"><i>☰</i><span>More</span></button></nav>' +
      '<div id="mobileNavSheet" class="mobile-nav-sheet" onclick="if(event.target===this)toggleMobileMenu(false)"><section class="mobile-nav-card" role="dialog" aria-modal="true" aria-label="Navigation menu">' +
      '<div class="mobile-nav-head"><a href="profile.html">' + avatar(u, 'sm') + '<span><b>' + esc(u.name) + '</b><small>' + esc(u.role) + '</small></span></a><button type="button" onclick="toggleMobileMenu(false)" aria-label="Close menu">×</button></div>' +
      '<div class="mobile-nav-grid">' + link('communities','communities.html','Communities') + link('search','search.html','Find People') + link('market','marketplace.html','Marketplace') + link('ads','ads.html','Advertise') + link('profile','profile.html','My Profile') + link('ai','ai-assistant.html','AI Assistant') + link('games','games.html','Skill Games') + link('notify','notifications.html','Notifications') + link('settings','settings.html','Settings') +
      '<a id="adminMobileLink" class="' + (active === 'admin' ? 'active' : '') + ' hide" href="admin.html"><span>Admin Panel</span></a></div>' +
      '<div class="mobile-nav-foot"><span><b>Appearance</b><small>Theme stays saved</small></span>' + themeToggleHTML() + '<button class="mobile-logout" onclick="logout()">Logout</button></div></section></div><main class="main">');
    setTimeout(function () {
      SkillCloud.ready().then(function () {
        const role = state.profile && state.profile.account_role;
        if (role === 'admin' || role === 'moderator') {
          const adminLink = $('adminNavLink');
          const adminMobileLink = $('adminMobileLink');
          if (adminLink) adminLink.classList.remove('hide');
          if (adminMobileLink) adminMobileLink.classList.remove('hide');
        }
        SkillCloud.friendships().then(function (rows) {
          const count = rows.filter(function (row) { return row.relationship === 'incoming'; }).length;
          const friendsLink = document.querySelector('.sidebar .nav a[href="friends.html"]');
          if (friendsLink && count) friendsLink.insertAdjacentHTML('beforeend', '<i class="nav-new">' + count + '</i>');
        }).catch(function () {});
      });
    }, 0);
  };

  window.topbar = function (title, subtitle, actions) {
    document.write('<div class="topbar live-topbar"><div><span class="topbar-kicker">SKILLSWAPE NETWORK</span><h1>' + esc(title) + '</h1>' + (subtitle ? '<p>' + esc(subtitle) + '</p>' : '') + '</div><div class="top-actions">' + themeToggleHTML() + (actions || '') + '<a class="icon-profile-link" href="profile.html" title="Profile">' + avatar(user(), 'sm') + '</a></div></div>');
    setTimeout(installAutoHideHeader, 0);
  };

  window.endLayout = function () {
    document.write('</main></div><div id="toast" class="toast"></div>');
  };

  window.renderRight = async function () {
    if (!client || !isLoggedIn()) return;
    try {
      const stats = await sidebarStats();
      if ($('rUsers')) $('rUsers').textContent = stats.members;
      if ($('rPosts')) $('rPosts').textContent = stats.posts;
      if ($('rSpaces')) $('rSpaces').textContent = stats.spaces;
    } catch (_) {}
  };
})();
