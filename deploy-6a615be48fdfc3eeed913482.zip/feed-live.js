(function () {
  'use strict';

  const feedState = {
    posts: [], stories: [], storyGroups: [], ads: [], spaces: [],
    storyGroupIndex: 0, storyItemIndex: 0, storyTimer: null,
    storyPreviewUrl: '', postPreviewUrls: [], subscriptions: [], impressions: new Set(),
    viewerPostId: '', viewerIndex: 0, viewerCommentsOpen: false
  };
  let refreshTimer = null;

  function cloudAvatar(profile, size) {
    profile = profile || {};
    const name = profile.full_name || 'Member';
    return '<div class="avatar ' + (size || 'sm') + '">' + (profile.avatar_url ? '<img src="' + esc(profile.avatar_url) + '" alt="">' : esc(name.charAt(0).toUpperCase())) + '</div>';
  }

  function ownId() { return SkillCloud.state.session && SkillCloud.state.session.user && SkillCloud.state.session.user.id || uid(); }
  function friendlyDate(value) { return new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
  function safeUrl(value) { try { const parsed = new URL(value); return /^https?:$/.test(parsed.protocol) ? parsed.href : ''; } catch (_) { return ''; } }
  function domId(value) { return String(value || '').replace(/[^a-z0-9_-]/gi, ''); }

  function postMedia(post) {
    if (!post || !post.media_url) return [];
    let urls = [];
    try {
      const parsed = JSON.parse(post.media_url);
      if (Array.isArray(parsed)) urls = parsed.filter(Boolean);
    } catch (_) {}
    if (!urls.length) urls = [post.media_url];
    return urls.map(function (url) { return { url: String(url), type: post.media_type === 'video' ? 'video' : 'image' }; });
  }

  async function initFeed() {
    if (!SkillCloud.configured) {
      $('liveFeed').innerHTML = '<div class="cloud-state"><div class="state-icon">DB</div><h2>Connect the live backend</h2><p>' + esc(SkillCloud.setupMessage()) + '</p><a class="btn" href="setup.html">Open setup guide</a></div>';
      $('storyStrip').innerHTML = '';
      return;
    }
    try {
      await SkillCloud.requireUser();
      $('composerAvatar').innerHTML = avatar(user(), 'sm');
      await reloadAll();
      subscribeFeed();
      if (new URLSearchParams(location.search).get('compose') === '1') openPostComposer();
    } catch (error) {
      $('liveFeed').innerHTML = '<div class="cloud-state"><div class="state-icon">!</div><h2>Feed could not load</h2><p>' + esc(SkillCloud.cleanError(error)) + '</p><button class="btn" onclick="location.reload()">Try again</button></div>';
    }
  }

  async function reloadAll() {
    const results = await Promise.all([SkillCloud.listPosts(), SkillCloud.stories(), SkillCloud.activeAds(), SkillCloud.listSpaces()]);
    feedState.posts = results[0];
    feedState.stories = results[1];
    feedState.ads = results[2];
    feedState.spaces = results[3];
    groupStories();
    renderStories();
    renderSpaceOptions();
    renderLiveFeed();
  }

  function scheduleReload() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(function () { reloadAll().catch(console.error); }, 450);
  }

  function subscribeFeed() {
    ['space_posts','post_likes','post_comments','stories','ad_campaigns'].forEach(function (table) {
      feedState.subscriptions.push(SkillCloud.subscribe(table, scheduleReload));
    });
  }

  function renderSpaceOptions() {
    const joined = feedState.spaces.filter(function (space) { return space.is_member; });
    $('postSpaceLive').innerHTML = '<option value="">Public home feed</option>' + joined.map(function (space) {
      return '<option value="' + esc(space.id) + '">' + esc(space.name) + ' · ' + esc(space.space_type) + '</option>';
    }).join('');
  }

  function groupStories() {
    const groups = [];
    const map = new Map();
    feedState.stories.forEach(function (story) {
      const key = story.author_id || (story.author && story.author.id) || story.id;
      let group = map.get(key);
      if (!group) {
        group = { authorId: key, author: story.author || {}, stories: [] };
        map.set(key, group); groups.push(group);
      }
      group.stories.push(story);
    });
    groups.forEach(function (group) {
      group.stories.sort(function (a, b) { return new Date(a.created_at) - new Date(b.created_at); });
      group.unseen = group.stories.some(function (story) { return !story.viewed; });
      group.preview = group.stories[group.stories.length - 1];
    });
    groups.sort(function (a, b) {
      if (a.authorId === ownId()) return -1;
      if (b.authorId === ownId()) return 1;
      return new Date(b.preview.created_at) - new Date(a.preview.created_at);
    });
    feedState.storyGroups = groups;
  }

  function renderStories() {
    const create = '<button class="story-live story-create" onclick="openStoryComposer()"><span class="story-plus">+</span><b>Create story</b></button>';
    const cards = feedState.storyGroups.map(function (group, index) {
      const story = group.preview;
      const media = story.media_type === 'video' ? '<video src="' + esc(story.media_url) + '" muted preload="metadata"></video>' : '<img src="' + esc(story.media_url) + '" alt="">';
      const count = group.stories.length > 1 ? '<span class="story-count">' + group.stories.length + '</span>' : '';
      return '<button class="story-live ' + (group.unseen ? 'unseen' : '') + '" onclick="openStoryViewer(' + index + ')">' + media + cloudAvatar(group.author, 'sm') + count + '<b>' + esc((group.author.full_name || 'Member').split(' ')[0]) + '</b></button>';
    }).join('');
    $('storyStrip').innerHTML = create + cards;
  }

  function mediaMarkup(post) {
    const media = postMedia(post);
    if (!media.length) return '';
    const id = domId(post.id);
    if (media.length === 1) {
      const item = media[0];
      if (item.type === 'video') {
        return '<div class="post-single-media"><video class="post-live-media" src="' + esc(item.url) + '" controls playsinline preload="metadata"></video><button class="post-media-expand" type="button" onclick="openPostMedia(\'' + post.id + '\',0)">⛶ <span>Full screen</span></button></div>';
      }
      return '<button class="post-single-media image" type="button" onclick="openPostMedia(\'' + post.id + '\',0)"><img class="post-live-media" src="' + esc(item.url) + '" alt="Post media" loading="lazy"><span class="post-media-expand">⛶ <span>Full screen</span></span></button>';
    }
    const slides = media.map(function (item, index) {
      return '<button class="post-gallery-slide" type="button" onclick="openPostMedia(\'' + post.id + '\',' + index + ')"><img class="post-live-media" src="' + esc(item.url) + '" alt="Post photo ' + (index + 1) + '" loading="lazy" onload="fitGalleryMedia(this)"></button>';
    }).join('');
    const dots = media.map(function (_, index) { return '<i class="' + (index === 0 ? 'active' : '') + '"></i>'; }).join('');
    return '<div class="post-gallery" id="gallery_' + id + '"><div class="post-gallery-track" onscroll="galleryScrolled(\'' + post.id + '\')">' + slides + '</div><button class="post-gallery-arrow prev" type="button" onclick="scrollGallery(\'' + post.id + '\',-1)">‹</button><button class="post-gallery-arrow next" type="button" onclick="scrollGallery(\'' + post.id + '\',1)">›</button><span class="post-gallery-number">1/' + media.length + '</span><div class="post-gallery-dots">' + dots + '</div></div>';
  }

  function postMarkup(post) {
    const author = post.author || {};
    const own = post.author_id === ownId();
    const media = mediaMarkup(post);
    const space = post.space ? '<a class="post-space-pill" href="space.html?id=' + encodeURIComponent(post.space.id) + '">' + esc(post.space.name) + '</a>' : '<span class="post-space-pill">Public feed</span>';
    return '<article id="post-' + esc(post.id) + '" class="post-live" data-post-id="' + esc(post.id) + '"><div class="post-live-body"><div class="post-live-head"><a class="post-live-author" href="profile.html?u=' + encodeURIComponent(post.author_id) + '">' + cloudAvatar(author, 'sm') + '<span><b>' + esc(author.full_name || 'Member') + '</b><small>' + esc(author.headline || 'SkillSwape Member') + ' · ' + timeAgo(post.created_at) + '</small></span></a>' + space + '</div>' +
      (post.title ? '<h2>' + esc(post.title) + '</h2>' : '') + (post.body ? '<p class="post-copy">' + esc(post.body) + '</p>' : '') + '</div>' + media +
      '<div class="post-live-meta"><span>' + post.like_count + ' likes</span><span>' + post.comment_count + ' comments</span></div>' +
      '<div class="post-live-actions"><button class="' + (post.liked ? 'liked' : '') + '" onclick="feedLike(\'' + post.id + '\')">♡ <span>' + (post.liked ? 'Liked' : 'Like') + '</span></button><button onclick="toggleLiveComments(\'' + post.id + '\')">○ <span>Comment</span></button><button onclick="shareLivePost(\'' + post.id + '\')">↗ <span>Share</span></button>' + (own ? '<button onclick="removeLivePost(\'' + post.id + '\')">× <span>Delete</span></button>' : '<a href="chat.html?user=' + encodeURIComponent(post.author_id) + '">✦ <span>Message</span></a>') + '</div>' +
      '<div id="liveComments_' + post.id + '" class="post-comments-live" data-loaded="false"><div class="live-loading">Loading comments</div></div></article>';
  }

  function adMarkup(ad) {
    if (!feedState.impressions.has(ad.id)) {
      feedState.impressions.add(ad.id);
      SkillCloud.recordAd(ad.id, 'impression').catch(function () {});
    }
    const target = safeUrl(ad.target_url);
    return '<article class="sponsored-card"><img src="' + esc(ad.creative_url) + '" alt="Sponsored creative" loading="lazy"><div class="sponsored-copy"><span class="sponsored-label">SPONSORED · ' + esc(ad.package && ad.package.name || 'SkillSwape Ad') + '</span><h3>' + esc(ad.title) + '</h3><p>' + esc(ad.caption) + '</p>' + (target ? '<a class="btn" href="' + esc(target) + '" target="_blank" rel="noopener" onclick="SkillCloud.recordAd(\'' + ad.id + '\',\'click\')">Learn more</a>' : '') + '</div></article>';
  }

  window.renderLiveFeed = function () {
    const query = String($('feedSearchLive').value || '').trim().toLowerCase();
    const category = $('feedCategoryLive').value;
    const posts = feedState.posts.filter(function (post) {
      const haystack = [post.title, post.body, post.category, post.author && post.author.full_name, post.space && post.space.name].join(' ').toLowerCase();
      return (category === 'All' || post.category === category) && haystack.includes(query);
    });
    if (!posts.length) {
      $('liveFeed').innerHTML = '<div class="cloud-state"><div class="state-icon">+</div><h2>No posts yet</h2><p>Be the first person to share a real update with the SkillSwape community.</p><button class="btn" onclick="openPostComposer()">Create first post</button></div>';
      return;
    }
    const html = [];
    posts.forEach(function (post, index) {
      html.push(postMarkup(post));
      if (index === 1 && feedState.ads.length) html.push(adMarkup(feedState.ads[0]));
    });
    $('liveFeed').innerHTML = '<div class="feed-live-grid">' + html.join('') + '</div>';
  };

  window.fitGalleryMedia = function (image) {
    const gallery = image && image.closest('.post-gallery');
    if (!gallery || !image.naturalWidth || !image.naturalHeight) return;
    const track = gallery.querySelector('.post-gallery-track');
    const activeIndex = track && track.clientWidth ? Math.round(track.scrollLeft / track.clientWidth) : 0;
    const slideIndex = Array.from(gallery.querySelectorAll('.post-gallery-slide')).indexOf(image.closest('.post-gallery-slide'));
    if (slideIndex !== activeIndex) return;
    const availableWidth = Math.max(1, gallery.clientWidth || image.naturalWidth);
    const naturalHeight = availableWidth * (image.naturalHeight / image.naturalWidth);
    const minimum = window.innerWidth <= 760 ? 140 : 180;
    const maximum = Math.min(window.innerHeight * (window.innerWidth <= 760 ? .64 : .72), window.innerWidth <= 760 ? 520 : 680);
    gallery.style.setProperty('--gallery-height', Math.round(Math.max(minimum, Math.min(maximum, naturalHeight))) + 'px');
  };

  window.scrollGallery = function (postId, direction) {
    const gallery = $('gallery_' + domId(postId));
    const track = gallery && gallery.querySelector('.post-gallery-track');
    if (track) track.scrollBy({ left: direction * track.clientWidth, behavior: 'smooth' });
  };

  window.galleryScrolled = function (postId) {
    const gallery = $('gallery_' + domId(postId));
    const track = gallery && gallery.querySelector('.post-gallery-track');
    if (!track || !track.clientWidth) return;
    const index = Math.max(0, Math.min(track.children.length - 1, Math.round(track.scrollLeft / track.clientWidth)));
    gallery.querySelectorAll('.post-gallery-dots i').forEach(function (dot, i) { dot.classList.toggle('active', i === index); });
    const number = gallery.querySelector('.post-gallery-number');
    if (number) number.textContent = (index + 1) + '/' + track.children.length;
    const activeImage = track.children[index] && track.children[index].querySelector('img');
    if (activeImage && activeImage.complete) fitGalleryMedia(activeImage);
  };

  function clearPostPreview() {
    feedState.postPreviewUrls.forEach(function (url) { URL.revokeObjectURL(url); });
    feedState.postPreviewUrls = [];
    $('postMediaPreview').innerHTML = '';
    $('postMediaName').textContent = '';
  }

  window.previewPostMedia = function () {
    clearPostPreview();
    const files = Array.from($('postMediaLive').files || []);
    if (!files.length) return;
    if (files.length > 10) {
      $('postPublishStatus').textContent = 'Maximum 10 photos select karein.';
      $('postMediaLive').value = '';
      return;
    }
    const videos = files.filter(function (file) { return /^video\//.test(file.type); });
    if (videos.length && files.length > 1) {
      $('postPublishStatus').textContent = 'Ek video ya multiple photos select karein—video ke sath gallery allowed nahi.';
      $('postMediaLive').value = '';
      return;
    }
    if (files.some(function (file) { return file.size > 25 * 1024 * 1024; })) {
      $('postPublishStatus').textContent = 'Har selected file 25MB se choti honi chahiye.';
      $('postMediaLive').value = '';
      return;
    }
    feedState.postPreviewUrls = files.map(function (file) { return URL.createObjectURL(file); });
    $('postMediaName').textContent = files.length === 1 ? files[0].name : files.length + ' photos selected · swipe gallery';
    $('postMediaPreview').innerHTML = files.map(function (file, index) {
      return /^video\//.test(file.type)
        ? '<video src="' + esc(feedState.postPreviewUrls[index]) + '" muted controls playsinline></video>'
        : '<img src="' + esc(feedState.postPreviewUrls[index]) + '" alt="Selected photo">';
    }).join('');
    $('postPublishStatus').textContent = files.length > 1 ? 'Instagram-style swipe gallery ready.' : 'Media ready to upload.';
  };

  window.openPostComposer = function (mode) {
    $('postComposerModal').classList.add('open');
    setTimeout(function () { if (mode === 'image') $('postMediaLive').click(); else $('postBodyLive').focus(); }, 30);
  };
  window.closePostComposer = function () { $('postComposerModal').classList.remove('open'); };

  window.publishLivePost = async function () {
    const body = $('postBodyLive').value.trim();
    const files = $('postMediaLive').files;
    if (!body && !files.length) return toast('Text ya media add karein.');
    const button = $('postPublishButton');
    button.disabled = true; button.textContent = 'Publishing...';
    $('postPublishStatus').textContent = 'Media upload aur secure sync ho rahi hai...';
    try {
      await SkillCloud.createPost({ space_id: $('postSpaceLive').value, category: $('postCategoryLive').value, title: $('postTitleLive').value.trim(), body: body }, files);
      $('postComposerForm').reset(); clearPostPreview();
      closePostComposer(); toast('Post is live'); await reloadAll();
    } catch (error) { $('postPublishStatus').textContent = SkillCloud.cleanError(error); toast(SkillCloud.cleanError(error)); }
    finally { button.disabled = false; button.textContent = 'Publish post'; }
  };

  window.feedLike = async function (id) {
    const post = feedState.posts.find(function (item) { return item.id === id; });
    if (!post) return;
    try { await SkillCloud.toggleLike(post); await reloadAll(); } catch (error) { toast(SkillCloud.cleanError(error)); }
  };

  function commentsMarkup(rows, id, viewer) {
    const list = rows.map(function (comment) {
      return '<div class="comment-live">' + cloudAvatar(comment.author, 'sm') + '<div class="comment-bubble"><b>' + esc(comment.author && comment.author.full_name || 'Member') + '</b><p>' + esc(comment.body) + '</p></div></div>';
    }).join('') || '<p class="muted">No comments yet. Start the conversation.</p>';
    if (viewer) return list;
    return '<div>' + list + '</div><div class="comment-compose"><input id="commentInput_' + id + '" maxlength="1500" placeholder="Write a thoughtful comment..."><button class="btn secondary" onclick="submitLiveComment(\'' + id + '\')">Post</button></div>';
  }

  window.toggleLiveComments = async function (id) {
    const box = $('liveComments_' + id);
    if (!box) return;
    box.classList.toggle('open');
    if (!box.classList.contains('open') || box.dataset.loaded === 'true') return;
    try {
      const rows = await SkillCloud.comments(id);
      box.dataset.loaded = 'true';
      box.innerHTML = commentsMarkup(rows, id, false);
    } catch (error) { box.innerHTML = '<p class="muted">' + esc(SkillCloud.cleanError(error)) + '</p>'; }
  };

  window.submitLiveComment = async function (id) {
    const input = $('commentInput_' + id); const body = input && input.value.trim();
    if (!body) return;
    try { await SkillCloud.addComment(id, body); const box = $('liveComments_' + id); box.dataset.loaded = 'false'; box.classList.remove('open'); await toggleLiveComments(id); }
    catch (error) { toast(SkillCloud.cleanError(error)); }
  };

  window.removeLivePost = async function (id) {
    if (!confirm('Delete this post permanently?')) return;
    try { await SkillCloud.deletePost(id); toast('Post deleted'); await reloadAll(); } catch (error) { toast(SkillCloud.cleanError(error)); }
  };

  window.shareLivePost = async function (id) {
    const post = feedState.posts.find(function (item) { return item.id === id; });
    if (!post) return;
    const url = location.origin + location.pathname + '#post-' + id;
    try {
      if (navigator.share) await navigator.share({ title: post.title || 'SkillSwape AI post', text: post.body, url: url });
      else { await navigator.clipboard.writeText(url); toast('Post link copied'); }
    } catch (_) {}
  };

  function currentViewerPost() { return feedState.posts.find(function (post) { return post.id === feedState.viewerPostId; }); }

  function renderViewerActions(post) {
    if (!post) return;
    const commentClass = feedState.viewerCommentsOpen ? 'active' : '';
    $('postMediaActions').innerHTML =
      '<button class="' + (post.liked ? 'liked' : '') + '" onclick="viewerLike()" aria-label="Like post">' +
        '<span class="viewer-action-icon">♡</span><span class="viewer-action-label">Like</span><span class="viewer-action-count">' + Number(post.like_count || 0) + '</span>' +
      '</button>' +
      '<button class="' + commentClass + '" onclick="toggleViewerComments()" aria-label="Open comments">' +
        '<span class="viewer-action-icon">◯</span><span class="viewer-action-label">Comment</span><span class="viewer-action-count">' + Number(post.comment_count || 0) + '</span>' +
      '</button>' +
      '<button onclick="viewerShare()" aria-label="Share post">' +
        '<span class="viewer-action-icon">↗</span><span class="viewer-action-label">Share</span>' +
      '</button>';
  }

  function renderPostViewer() {
    const post = currentViewerPost();
    if (!post) return closePostMedia();
    const media = postMedia(post);
    feedState.viewerIndex = Math.max(0, Math.min(media.length - 1, feedState.viewerIndex));
    const item = media[feedState.viewerIndex];
    const author = post.author || {};
    const modal = $('postMediaModal');
    modal.classList.toggle('comments-open', feedState.viewerCommentsOpen);
    $('postMediaStage').innerHTML = item.type === 'video'
      ? '<div class="post-media-video-ambient" aria-hidden="true"></div><video class="post-media-content" src="' + esc(item.url) + '" controls autoplay playsinline></video>'
      : '<img class="post-media-ambient" src="' + esc(item.url) + '" alt="" aria-hidden="true"><img class="post-media-content" src="' + esc(item.url) + '" alt="Post media">';
    $('postMediaCounter').textContent = media.length > 1 ? (feedState.viewerIndex + 1) + ' / ' + media.length : '';
    $('postMediaPrev').hidden = media.length < 2 || feedState.viewerIndex === 0;
    $('postMediaNext').hidden = media.length < 2 || feedState.viewerIndex === media.length - 1;
    $('postMediaAuthor').innerHTML = '<a href="profile.html?u=' + encodeURIComponent(post.author_id) + '">' + cloudAvatar(author, 'sm') + '<span><b>' + esc(author.full_name || 'Member') + '</b><small>' + timeAgo(post.created_at) + '</small></span></a>';
    $('postMediaCaption').innerHTML = (post.title ? '<h3>' + esc(post.title) + '</h3>' : '') + (post.body ? '<p>' + esc(post.body) + '</p>' : '');
    renderViewerActions(post);
    $('postMediaCommentComposer').innerHTML = '<input id="viewerCommentInput" maxlength="1500" placeholder="Add a comment..."><button onclick="submitViewerComment()">Post</button>';
    if (!feedState.viewerCommentsOpen) $('postMediaViewerComments').innerHTML = '';
  }

  window.openPostMedia = function (id, index) {
    const post = feedState.posts.find(function (item) { return item.id === id; });
    if (!post || !postMedia(post).length) return;
    feedState.viewerPostId = id;
    feedState.viewerIndex = Number(index) || 0;
    feedState.viewerCommentsOpen = false;
    renderPostViewer();
    $('postMediaModal').classList.add('open');
    $('postMediaModal').setAttribute('aria-hidden', 'false');
    document.body.classList.add('media-viewer-open');
  };

  window.closePostMedia = function () {
    const modal = $('postMediaModal');
    if (!modal) return;
    modal.classList.remove('open', 'comments-open');
    modal.setAttribute('aria-hidden', 'true');
    const video = $('postMediaStage') && $('postMediaStage').querySelector('video');
    if (video) video.pause();
    document.body.classList.remove('media-viewer-open');
    feedState.viewerPostId = '';
  };

  window.viewerMove = function (direction) {
    const post = currentViewerPost(); if (!post) return;
    const media = postMedia(post);
    feedState.viewerIndex = Math.max(0, Math.min(media.length - 1, feedState.viewerIndex + direction));
    renderPostViewer();
  };

  window.viewerLike = async function () {
    const post = currentViewerPost(); if (!post) return;
    try {
      await SkillCloud.toggleLike(post);
      post.liked = !post.liked;
      post.like_count = Math.max(0, Number(post.like_count || 0) + (post.liked ? 1 : -1));
      renderLiveFeed(); renderViewerActions(post);
    } catch (error) { toast(SkillCloud.cleanError(error)); }
  };

  window.viewerShare = function () { if (feedState.viewerPostId) shareLivePost(feedState.viewerPostId); };

  window.toggleViewerComments = async function () {
    feedState.viewerCommentsOpen = !feedState.viewerCommentsOpen;
    $('postMediaModal').classList.toggle('comments-open', feedState.viewerCommentsOpen);
    const currentPost = currentViewerPost();
    if (currentPost) renderViewerActions(currentPost);
    if (!feedState.viewerCommentsOpen) return;
    $('postMediaViewerComments').innerHTML = '<div class="live-loading">Loading comments</div>';
    try {
      const rows = await SkillCloud.comments(feedState.viewerPostId);
      $('postMediaViewerComments').innerHTML = commentsMarkup(rows, feedState.viewerPostId, true);
    } catch (error) { $('postMediaViewerComments').innerHTML = '<p class="muted">' + esc(SkillCloud.cleanError(error)) + '</p>'; }
  };

  window.submitViewerComment = async function () {
    const input = $('viewerCommentInput');
    const body = input && input.value.trim();
    if (!body || !feedState.viewerPostId) return;
    try {
      await SkillCloud.addComment(feedState.viewerPostId, body);
      const post = currentViewerPost();
      if (post) post.comment_count = Number(post.comment_count || 0) + 1;
      input.value = '';
      const rows = await SkillCloud.comments(feedState.viewerPostId);
      $('postMediaViewerComments').innerHTML = commentsMarkup(rows, feedState.viewerPostId, true);
      renderLiveFeed(); renderViewerActions(post);
      feedState.viewerCommentsOpen = true;
      $('postMediaModal').classList.add('comments-open');
    } catch (error) { toast(SkillCloud.cleanError(error)); }
  };

  window.openStoryComposer = function () {
    $('storyPublishStatus').textContent = 'Story upload hote hi sab accounts par nazar aayegi aur 24 hours baad expire hogi.';
    $('storyComposerModal').classList.add('open');
  };
  window.closeStoryComposer = function () {
    $('storyComposerModal').classList.remove('open');
    if (feedState.storyPreviewUrl) URL.revokeObjectURL(feedState.storyPreviewUrl);
    feedState.storyPreviewUrl = '';
  };
  window.previewStoryMedia = function () {
    const file = $('storyMediaLive').files[0];
    const preview = $('storyPreviewLive');
    if (feedState.storyPreviewUrl) URL.revokeObjectURL(feedState.storyPreviewUrl);
    feedState.storyPreviewUrl = '';
    if (!file) {
      preview.innerHTML = '<span>Select a photo or short video to preview it here.</span>';
      $('storyMediaName').textContent = '';
      return;
    }
    const sizeMb = file.size / 1024 / 1024;
    $('storyMediaName').textContent = file.name + ' · ' + sizeMb.toFixed(1) + 'MB';
    if (sizeMb > 50) {
      preview.innerHTML = '<span class="story-preview-error">File 50MB se bari hai. Choti video ya image select karein.</span>';
      $('storyPublishStatus').textContent = 'Maximum story size 50MB hai.';
      return;
    }
    feedState.storyPreviewUrl = URL.createObjectURL(file);
    const isVideo = /^video\//.test(file.type) || /\.(mp4|webm|mov|m4v|3gp)$/i.test(file.name);
    preview.innerHTML = isVideo ? '<video src="' + esc(feedState.storyPreviewUrl) + '" controls muted playsinline></video>' : '<img src="' + esc(feedState.storyPreviewUrl) + '" alt="Story preview">';
    $('storyPublishStatus').textContent = 'Ready to share · ' + sizeMb.toFixed(1) + 'MB';
  };

  window.publishStory = async function () {
    const file = $('storyMediaLive').files[0];
    if (!file) return toast('Story media select karein.');
    if (file.size > 50 * 1024 * 1024) return toast('Story file 50MB se choti honi chahiye.');
    const button = $('storyPublishButton'); button.disabled = true; button.textContent = 'Sharing...';
    $('storyPublishStatus').textContent = 'Media upload ho rahi hai—page close na karein...';
    try {
      await SkillCloud.createStory(file, $('storyCaptionLive').value);
      $('storyMediaLive').value = ''; $('storyCaptionLive').value = ''; $('storyMediaName').textContent = '';
      $('storyPreviewLive').innerHTML = '<span>Select a photo or short video to preview it here.</span>';
      closeStoryComposer(); toast('Story added to your existing story icon');
      feedState.stories = await SkillCloud.stories(); groupStories(); renderStories();
      requestAnimationFrame(function () { $('storyStrip').scrollTo({ left: 0, behavior: 'smooth' }); });
    } catch (error) {
      let message = SkillCloud.cleanError(error);
      if (/row-level security/i.test(String(error && error.message || ''))) message = 'Story permission missing hai. Supabase mein story upload repair migration run karein.';
      $('storyPublishStatus').textContent = message; toast(message);
    } finally { button.disabled = false; button.textContent = 'Share story'; }
  };

  function storyProgressMarkup(group, activeIndex) {
    return '<div class="story-view-progress grouped">' + group.stories.map(function (_, index) {
      return '<span class="' + (index < activeIndex ? 'done' : index === activeIndex ? 'active' : '') + '"><i></i></span>';
    }).join('') + '</div>';
  }

  window.openStoryViewer = async function (groupIndex, itemIndex) {
    clearTimeout(feedState.storyTimer);
    feedState.storyGroupIndex = Number(groupIndex) || 0;
    const group = feedState.storyGroups[feedState.storyGroupIndex];
    if (!group) return;
    if (itemIndex === undefined) {
      const firstUnseen = group.stories.findIndex(function (story) { return !story.viewed; });
      feedState.storyItemIndex = firstUnseen >= 0 ? firstUnseen : 0;
    } else feedState.storyItemIndex = Math.max(0, Math.min(group.stories.length - 1, Number(itemIndex) || 0));
    const story = group.stories[feedState.storyItemIndex];
    const media = story.media_type === 'video'
      ? '<video class="story-view-media" src="' + esc(story.media_url) + '" autoplay controls playsinline onended="nextStory()"></video>'
      : '<img class="story-view-media" src="' + esc(story.media_url) + '" alt="Story">';
    $('storyViewerCard').innerHTML = storyProgressMarkup(group, feedState.storyItemIndex) + '<div class="story-view-user">' + cloudAvatar(group.author, 'sm') + '<div><b>' + esc(group.author.full_name || 'Member') + '</b><small>' + friendlyDate(story.created_at) + ' · ' + (feedState.storyItemIndex + 1) + '/' + group.stories.length + '</small></div></div><button class="close-live story-close" onclick="closeStoryViewer()">×</button><button class="story-nav prev" onclick="previousStory()">‹</button><button class="story-nav next" onclick="nextStory()">›</button>' + media + (story.caption ? '<div class="story-view-caption">' + esc(story.caption) + '</div>' : '');
    $('storyViewerModal').classList.add('open');
    story.viewed = true; group.unseen = group.stories.some(function (item) { return !item.viewed; });
    SkillCloud.viewStory(story.id).catch(function () {});
    if (story.media_type !== 'video') feedState.storyTimer = setTimeout(nextStory, 6000);
  };

  window.nextStory = function () {
    const group = feedState.storyGroups[feedState.storyGroupIndex];
    if (group && feedState.storyItemIndex + 1 < group.stories.length) return openStoryViewer(feedState.storyGroupIndex, feedState.storyItemIndex + 1);
    if (feedState.storyGroupIndex + 1 < feedState.storyGroups.length) return openStoryViewer(feedState.storyGroupIndex + 1, 0);
    closeStoryViewer();
  };

  window.previousStory = function () {
    if (feedState.storyItemIndex > 0) return openStoryViewer(feedState.storyGroupIndex, feedState.storyItemIndex - 1);
    if (feedState.storyGroupIndex > 0) {
      const previousGroup = feedState.storyGroups[feedState.storyGroupIndex - 1];
      return openStoryViewer(feedState.storyGroupIndex - 1, previousGroup.stories.length - 1);
    }
  };

  window.closeStoryViewer = function () {
    clearTimeout(feedState.storyTimer);
    $('storyViewerModal').classList.remove('open');
    const video = $('storyViewerCard').querySelector('video'); if (video) video.pause();
    renderStories();
  };

  document.addEventListener('keydown', function (event) {
    if ($('postMediaModal') && $('postMediaModal').classList.contains('open')) {
      if (event.key === 'Escape') closePostMedia();
      if (event.key === 'ArrowRight') viewerMove(1);
      if (event.key === 'ArrowLeft') viewerMove(-1);
    } else if ($('storyViewerModal') && $('storyViewerModal').classList.contains('open')) {
      if (event.key === 'Escape') closeStoryViewer();
      if (event.key === 'ArrowRight') nextStory();
      if (event.key === 'ArrowLeft') previousStory();
    }
  });

  window.addEventListener('beforeunload', function () {
    feedState.subscriptions.forEach(SkillCloud.removeSubscription);
    clearPostPreview();
  });
  initFeed();
})();
