(function () {
  'use strict';
  let timer = null;
  let channel = null;

  function ownId() {
    return SkillCloud.state.session && SkillCloud.state.session.user.id || uid();
  }

  function avatarMarkup(profile) {
    const name = profile.full_name || 'Member';
    return '<div class="avatar lg">' + (profile.avatar_url
      ? '<img src="' + esc(profile.avatar_url) + '" alt="">'
      : esc(name.charAt(0).toUpperCase())) + '</div>';
  }

  function memberCard(profile) {
    const locked = profile.is_private && !profile.can_view_full;
    const privacy = profile.is_private ? '<span class="privacy-badge">Private</span>' : '';
    const details = locked
      ? '<div class="private-preview"><span class="private-lock">●</span><div><b>Private account</b><small>Become friends to see bio, skills, posts and stories.</small></div></div>'
      : '<p>' + esc(profile.bio || 'Open to learning, sharing and professional collaboration.') + '</p>' +
        '<div class="skill-row">' + ((profile.skills || []).slice(0, 4).map(function (skill) {
          return '<span class="chip">' + esc(skill) + '</span>';
        }).join('') || '<span class="chip">Open to connect</span>') + '</div>';

    return '<article class="person-card-live" data-person-id="' + esc(profile.id) + '">' +
      '<div class="person-card-head">' + avatarMarkup(profile) + '<div><div class="name-with-badge"><b>' + esc(profile.full_name) + '</b>' + privacy + '</div>' +
      '<small>' + esc(profile.headline || 'SkillSwape Member') + (locked ? '' : ' · ' + esc(profile.location || 'Online')) + '</small>' +
      '<small>' + Number(profile.friend_count || 0) + ' friends</small></div></div>' +
      details +
      '<div class="space-card-actions friend-card-actions">' + friendControlsHTML(profile, { message: true }) +
      '<a class="btn secondary" href="profile.html?u=' + encodeURIComponent(profile.id) + '">Profile</a></div></article>';
  }

  async function init() {
    if (!SkillCloud.configured) {
      $('peopleGridLive').innerHTML = '<div class="cloud-state"><h2>Live setup required</h2><p>' + esc(SkillCloud.setupMessage()) + '</p><a class="btn" href="setup.html">Setup guide</a></div>';
      return;
    }
    try {
      await SkillCloud.requireUser();
      await searchPeopleLive();
      channel = SkillCloud.subscribe('friendships', function () {
        clearTimeout(timer);
        timer = setTimeout(searchPeopleLive, 180);
      });
    } catch (error) {
      $('peopleGridLive').innerHTML = '<div class="cloud-state"><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>';
    }
  }

  window.queuePeopleSearch = function () {
    clearTimeout(timer);
    timer = setTimeout(searchPeopleLive, 280);
  };

  window.searchPeopleLive = async function () {
    $('peopleGridLive').innerHTML = '<div class="live-loading">Searching members</div>';
    try {
      const rows = (await SkillCloud.listProfiles($('peopleSearchLive').value)).filter(function (profile) {
        return profile.id !== ownId();
      });
      $('peopleGridLive').innerHTML = rows.map(memberCard).join('') || '<div class="cloud-state"><h2>No members found</h2><p>Try a broader skill, role or city.</p></div>';
    } catch (error) {
      $('peopleGridLive').innerHTML = '<div class="cloud-state"><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>';
    }
  };

  window.addEventListener('skillswape:friendship-change', function () {
    searchPeopleLive();
  });
  window.addEventListener('beforeunload', function () {
    if (channel) SkillCloud.removeSubscription(channel);
  });

  init();
})();
