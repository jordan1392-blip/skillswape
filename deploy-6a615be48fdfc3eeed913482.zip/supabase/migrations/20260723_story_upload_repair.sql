-- SkillSwape AI: repair and harden 24-hour story uploads
-- Safe to run more than once in Supabase > SQL Editor.
-- Run 20260723_friendships_privacy.sql before this file.

begin;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'story-media',
  'story-media',
  true,
  52428800,
  array[
    'image/jpeg','image/png','image/webp','image/gif',
    'video/mp4','video/webm','video/quicktime','video/3gpp'
  ]
)
on conflict (id) do update set
  public = true,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

alter table public.stories enable row level security;
alter table public.story_views enable row level security;

drop policy if exists stories_create_own on public.stories;
create policy stories_create_own on public.stories for insert to authenticated
with check (
  author_id = auth.uid()
  and expires_at > now()
  and expires_at <= now() + interval '25 hours'
);

drop policy if exists stories_delete_own on public.stories;
create policy stories_delete_own on public.stories for delete to authenticated
using (author_id = auth.uid());

drop policy if exists story_views_create_own on public.story_views;
create policy story_views_create_own on public.story_views for insert to authenticated
with check (
  viewer_id = auth.uid()
  and public.can_access_story(story_id)
);

drop policy if exists story_media_read_public on storage.objects;
create policy story_media_read_public on storage.objects for select to public
using (bucket_id = 'story-media');

drop policy if exists story_media_upload_own on storage.objects;
create policy story_media_upload_own on storage.objects for insert to authenticated
with check (
  bucket_id = 'story-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists story_media_update_own on storage.objects;
create policy story_media_update_own on storage.objects for update to authenticated
using (
  bucket_id = 'story-media'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id = 'story-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists story_media_delete_own on storage.objects;
create policy story_media_delete_own on storage.objects for delete to authenticated
using (
  bucket_id = 'story-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);

grant select, insert, delete on public.stories to authenticated;
grant select, insert, delete on public.story_views to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'stories'
  ) then
    alter publication supabase_realtime add table public.stories;
  end if;
end $$;

notify pgrst, 'reload schema';

commit;
