-- SkillSwape AI: friend requests and private accounts
-- Run this file once in Supabase > SQL Editor for an existing installation.

begin;

alter table public.profiles
  add column if not exists is_private boolean not null default false;

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'accepted')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  updated_at timestamptz not null default now(),
  constraint friendships_no_self check (requester_id <> addressee_id)
);

create unique index if not exists friendships_unique_pair_idx
  on public.friendships (
    least(requester_id::text, addressee_id::text),
    greatest(requester_id::text, addressee_id::text)
  );
create index if not exists friendships_requester_idx on public.friendships(requester_id, status);
create index if not exists friendships_addressee_idx on public.friendships(addressee_id, status);

drop trigger if exists friendships_touch_updated_at on public.friendships;
create trigger friendships_touch_updated_at before update on public.friendships
for each row execute procedure public.touch_updated_at();

create or replace function public.are_friends(p_first uuid, p_second uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select p_first is not null and p_second is not null and exists (
    select 1
    from public.friendships f
    where f.status = 'accepted'
      and ((f.requester_id = p_first and f.addressee_id = p_second)
        or (f.requester_id = p_second and f.addressee_id = p_first))
  );
$$;

create or replace function public.can_view_private_content(p_profile_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = p_profile_id
      and (p.id = auth.uid() or not p.is_private or public.are_friends(auth.uid(), p.id) or public.is_admin())
  );
$$;

create or replace function public.friendship_status(p_other_user uuid)
returns table (request_id uuid, relationship text, requested_at timestamptz)
language plpgsql stable security definer set search_path = public
as $$
declare
  v_row public.friendships%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_other_user = auth.uid() then
    return query select null::uuid, 'self'::text, null::timestamptz;
    return;
  end if;

  select f.* into v_row
  from public.friendships f
  where (f.requester_id = auth.uid() and f.addressee_id = p_other_user)
     or (f.requester_id = p_other_user and f.addressee_id = auth.uid())
  limit 1;

  if not found then
    return query select null::uuid, 'none'::text, null::timestamptz;
  elsif v_row.status = 'accepted' then
    return query select v_row.id, 'friends'::text, v_row.created_at;
  elsif v_row.requester_id = auth.uid() then
    return query select v_row.id, 'outgoing'::text, v_row.created_at;
  else
    return query select v_row.id, 'incoming'::text, v_row.created_at;
  end if;
end;
$$;

create or replace function public.my_friendships()
returns table (
  request_id uuid,
  other_user_id uuid,
  relationship text,
  created_at timestamptz,
  responded_at timestamptz,
  full_name text,
  headline text,
  avatar_url text,
  is_private boolean
)
language sql stable security definer set search_path = public
as $$
  select
    f.id,
    case when f.requester_id = auth.uid() then f.addressee_id else f.requester_id end,
    case
      when f.status = 'accepted' then 'friends'
      when f.addressee_id = auth.uid() then 'incoming'
      else 'outgoing'
    end,
    f.created_at,
    f.responded_at,
    p.full_name,
    p.headline,
    p.avatar_url,
    p.is_private
  from public.friendships f
  join public.profiles p
    on p.id = case when f.requester_id = auth.uid() then f.addressee_id else f.requester_id end
  where f.requester_id = auth.uid() or f.addressee_id = auth.uid()
  order by
    case when f.status = 'pending' and f.addressee_id = auth.uid() then 0
         when f.status = 'pending' then 1 else 2 end,
    f.updated_at desc;
$$;

create or replace function public.discover_profiles(p_query text default null)
returns table (
  id uuid,
  full_name text,
  headline text,
  bio text,
  location text,
  skills text[],
  avatar_url text,
  cover_url text,
  online_at timestamptz,
  account_role text,
  created_at timestamptz,
  is_private boolean,
  can_view_full boolean,
  relationship text,
  friend_request_id uuid,
  friend_count bigint
)
language sql stable security definer set search_path = public
as $$
  select
    p.id,
    p.full_name,
    p.headline,
    case when access.allowed then p.bio else '' end,
    case when access.allowed then p.location else '' end,
    case when access.allowed then p.skills else '{}'::text[] end,
    p.avatar_url,
    p.cover_url,
    case when access.allowed then p.online_at else null end,
    p.account_role,
    p.created_at,
    p.is_private,
    access.allowed,
    case
      when p.id = auth.uid() then 'self'
      when f.status = 'accepted' then 'friends'
      when f.requester_id = auth.uid() then 'outgoing'
      when f.addressee_id = auth.uid() then 'incoming'
      else 'none'
    end,
    f.id,
    (select count(*) from public.friendships fc
      where fc.status = 'accepted' and (fc.requester_id = p.id or fc.addressee_id = p.id))
  from public.profiles p
  cross join lateral (select public.can_view_private_content(p.id) as allowed) access
  left join public.friendships f
    on (f.requester_id = auth.uid() and f.addressee_id = p.id)
    or (f.requester_id = p.id and f.addressee_id = auth.uid())
  where auth.uid() is not null
    and (
      nullif(trim(coalesce(p_query, '')), '') is null
      or p.full_name ilike '%' || trim(p_query) || '%'
      or p.headline ilike '%' || trim(p_query) || '%'
      or (access.allowed and (
        p.bio ilike '%' || trim(p_query) || '%'
        or p.location ilike '%' || trim(p_query) || '%'
        or array_to_string(p.skills, ' ') ilike '%' || trim(p_query) || '%'
      ))
    )
  order by p.full_name
  limit 200;
$$;

create or replace function public.get_profile_for_viewer(p_profile_id uuid)
returns table (
  id uuid,
  full_name text,
  headline text,
  bio text,
  location text,
  skills text[],
  avatar_url text,
  cover_url text,
  gender text,
  account_role text,
  online_at timestamptz,
  created_at timestamptz,
  updated_at timestamptz,
  is_private boolean,
  can_view_full boolean,
  relationship text,
  friend_request_id uuid,
  friend_count bigint
)
language sql stable security definer set search_path = public
as $$
  select
    p.id,
    p.full_name,
    p.headline,
    case when access.allowed then p.bio else '' end,
    case when access.allowed then p.location else '' end,
    case when access.allowed then p.skills else '{}'::text[] end,
    p.avatar_url,
    p.cover_url,
    case when access.allowed then p.gender else null end,
    p.account_role,
    case when access.allowed then p.online_at else null end,
    p.created_at,
    p.updated_at,
    p.is_private,
    access.allowed,
    case
      when p.id = auth.uid() then 'self'
      when f.status = 'accepted' then 'friends'
      when f.requester_id = auth.uid() then 'outgoing'
      when f.addressee_id = auth.uid() then 'incoming'
      else 'none'
    end,
    f.id,
    (select count(*) from public.friendships fc
      where fc.status = 'accepted' and (fc.requester_id = p.id or fc.addressee_id = p.id))
  from public.profiles p
  cross join lateral (select public.can_view_private_content(p.id) as allowed) access
  left join public.friendships f
    on (f.requester_id = auth.uid() and f.addressee_id = p.id)
    or (f.requester_id = p.id and f.addressee_id = auth.uid())
  where auth.uid() is not null and p.id = p_profile_id;
$$;

create or replace function public.send_friend_request(p_other_user uuid)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  v_row public.friendships%rowtype;
  v_key text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_other_user = auth.uid() then raise exception 'You cannot add yourself'; end if;
  if not exists (select 1 from public.profiles p where p.id = p_other_user) then raise exception 'Member not found'; end if;

  v_key := least(auth.uid()::text, p_other_user::text) || ':' || greatest(auth.uid()::text, p_other_user::text);
  perform pg_advisory_xact_lock(hashtextextended('friend:' || v_key, 0));

  select f.* into v_row
  from public.friendships f
  where (f.requester_id = auth.uid() and f.addressee_id = p_other_user)
     or (f.requester_id = p_other_user and f.addressee_id = auth.uid())
  for update;

  if found then
    if v_row.status = 'accepted' or v_row.requester_id = auth.uid() then
      return v_row.id;
    end if;
    update public.friendships
      set status = 'accepted', responded_at = now()
      where id = v_row.id;
    return v_row.id;
  end if;

  insert into public.friendships(requester_id, addressee_id)
  values (auth.uid(), p_other_user)
  returning id into v_row.id;
  return v_row.id;
end;
$$;

create or replace function public.respond_friend_request(p_request_id uuid, p_accept boolean)
returns void
language plpgsql security definer set search_path = public
as $$
declare v_row public.friendships%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select f.* into v_row from public.friendships f where f.id = p_request_id for update;
  if not found or v_row.addressee_id <> auth.uid() or v_row.status <> 'pending' then
    raise exception 'Friend request is no longer available';
  end if;
  if p_accept then
    update public.friendships set status = 'accepted', responded_at = now() where id = p_request_id;
  else
    delete from public.friendships where id = p_request_id;
  end if;
end;
$$;

create or replace function public.cancel_friend_request(p_request_id uuid)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  delete from public.friendships
  where id = p_request_id and requester_id = auth.uid() and status = 'pending';
  if not found then raise exception 'Friend request is no longer available'; end if;
end;
$$;

create or replace function public.remove_friend(p_other_user uuid)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  delete from public.friendships
  where status = 'accepted'
    and ((requester_id = auth.uid() and addressee_id = p_other_user)
      or (requester_id = p_other_user and addressee_id = auth.uid()));
  if not found then raise exception 'Friendship was not found'; end if;
end;
$$;

create or replace function public.get_or_create_direct_conversation(p_other_user uuid)
returns uuid
language plpgsql
security definer set search_path = public
as $$
declare
  v_id uuid;
  v_key text;
  v_private boolean;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_other_user = auth.uid() then raise exception 'You cannot message yourself'; end if;

  select p.is_private into v_private from public.profiles p where p.id = p_other_user;
  if not found then raise exception 'Member not found'; end if;

  v_key := least(auth.uid()::text, p_other_user::text) || ':' || greatest(auth.uid()::text, p_other_user::text);
  perform pg_advisory_xact_lock(hashtextextended(v_key, 0));
  select c.id into v_id from public.conversations c where c.direct_key = v_key;
  if v_id is not null then return v_id; end if;

  if v_private and not public.are_friends(auth.uid(), p_other_user) then
    raise exception 'This account is private. Send a friend request first.';
  end if;

  insert into public.conversations(kind, direct_key, created_by)
  values ('direct', v_key, auth.uid()) returning id into v_id;
  insert into public.conversation_members(conversation_id, user_id, member_role)
  values (v_id, auth.uid(), 'member'), (v_id, p_other_user, 'member')
  on conflict do nothing;
  return v_id;
end;
$$;

create or replace function public.can_access_post(p_post_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.space_posts p
    where p.id = p_post_id
      and ((p.space_id is null and public.can_view_private_content(p.author_id))
        or (p.space_id is not null and public.can_access_space(p.space_id)))
  );
$$;

create or replace function public.can_access_story(p_story_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.stories s
    where s.id = p_story_id
      and (s.author_id = auth.uid()
        or (s.expires_at > now() and public.can_view_private_content(s.author_id)))
  );
$$;

alter table public.friendships enable row level security;

drop policy if exists friendships_read_related on public.friendships;
create policy friendships_read_related on public.friendships for select to authenticated
using (requester_id = auth.uid() or addressee_id = auth.uid());

drop policy if exists posts_read_accessible on public.space_posts;
create policy posts_read_accessible on public.space_posts for select to authenticated using (
  (space_id is null and public.can_view_private_content(author_id))
  or (space_id is not null and public.can_access_space(space_id))
);

drop policy if exists stories_read_current on public.stories;
create policy stories_read_current on public.stories for select to authenticated
using (public.can_access_story(id));

drop policy if exists story_views_create_own on public.story_views;
create policy story_views_create_own on public.story_views for insert to authenticated
with check (viewer_id = auth.uid() and public.can_access_story(story_id));

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'friendships'
  ) then
    alter publication supabase_realtime add table public.friendships;
  end if;
end $$;

grant select on public.friendships to authenticated;
revoke insert, update, delete on public.friendships from authenticated;

revoke select on public.profiles from authenticated;
grant select (id, full_name, headline, avatar_url, cover_url, account_role, created_at, is_private)
  on public.profiles to authenticated;
revoke update on public.profiles from authenticated;
grant update (full_name, headline, bio, location, skills, avatar_url, cover_url, gender, is_private, online_at, updated_at)
  on public.profiles to authenticated;

revoke execute on function public.friendship_status(uuid) from public, anon;
revoke execute on function public.my_friendships() from public, anon;
revoke execute on function public.discover_profiles(text) from public, anon;
revoke execute on function public.get_profile_for_viewer(uuid) from public, anon;
revoke execute on function public.send_friend_request(uuid) from public, anon;
revoke execute on function public.respond_friend_request(uuid,boolean) from public, anon;
revoke execute on function public.cancel_friend_request(uuid) from public, anon;
revoke execute on function public.remove_friend(uuid) from public, anon;
revoke execute on function public.get_or_create_direct_conversation(uuid) from public, anon;

grant execute on function public.are_friends(uuid,uuid) to authenticated;
grant execute on function public.can_view_private_content(uuid) to authenticated;
grant execute on function public.friendship_status(uuid) to authenticated;
grant execute on function public.my_friendships() to authenticated;
grant execute on function public.discover_profiles(text) to authenticated;
grant execute on function public.get_profile_for_viewer(uuid) to authenticated;
grant execute on function public.send_friend_request(uuid) to authenticated;
grant execute on function public.respond_friend_request(uuid,boolean) to authenticated;
grant execute on function public.cancel_friend_request(uuid) to authenticated;
grant execute on function public.remove_friend(uuid) to authenticated;
grant execute on function public.get_or_create_direct_conversation(uuid) to authenticated;

commit;
