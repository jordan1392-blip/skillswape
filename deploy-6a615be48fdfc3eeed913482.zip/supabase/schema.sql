-- SkillSwape AI production schema for Supabase
-- Run this complete file once in Supabase > SQL Editor.
-- Then run migrations/20260723_friendships_privacy.sql for friend requests and private accounts.
-- Finally run migrations/20260723_story_upload_repair.sql for story storage/mobile formats.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  full_name text not null default 'SkillSwape Member',
  headline text not null default 'SkillSwape Member',
  bio text not null default '',
  location text not null default '',
  skills text[] not null default '{}',
  avatar_url text,
  cover_url text,
  gender text check (gender in ('male','female','other')),
  is_private boolean not null default false,
  account_role text not null default 'member' check (account_role in ('member','moderator','admin')),
  online_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, headline, bio, location, gender)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'full_name', ''), split_part(new.email, '@', 1), 'SkillSwape Member'),
    coalesce(nullif(new.raw_user_meta_data ->> 'headline', ''), 'SkillSwape Member'),
    coalesce(new.raw_user_meta_data ->> 'bio', ''),
    coalesce(new.raw_user_meta_data ->> 'location', ''),
    case when new.raw_user_meta_data ->> 'gender' in ('male','female','other') then new.raw_user_meta_data ->> 'gender' else null end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles
for each row execute procedure public.touch_updated_at();

create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and account_role in ('admin','moderator')
  );
$$;

-- ---------------------------------------------------------------------------
-- Realtime direct and group conversations
-- ---------------------------------------------------------------------------

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'direct' check (kind in ('direct','group')),
  title text,
  description text not null default '',
  avatar_url text,
  direct_key text unique,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  member_role text not null default 'member' check (member_role in ('owner','admin','member')),
  joined_at timestamptz not null default now(),
  last_read_at timestamptz not null default now(),
  muted boolean not null default false,
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null constraint messages_sender_id_fkey references public.profiles(id) on delete cascade,
  body text not null default '',
  attachment_path text,
  attachment_name text,
  attachment_type text,
  attachment_size bigint,
  reply_to uuid references public.messages(id) on delete set null,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  constraint message_has_content check (length(trim(body)) > 0 or attachment_path is not null)
);

alter table public.messages add column if not exists attachment_size bigint;

create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id, conversation_id);

create or replace function public.is_conversation_member(p_conversation_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.conversation_members
    where conversation_id = p_conversation_id and user_id = auth.uid()
  );
$$;

create or replace function public.get_or_create_direct_conversation(p_other_user uuid)
returns uuid
language plpgsql
security definer set search_path = public
as $$
declare
  v_id uuid;
  v_key text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_other_user = auth.uid() then raise exception 'You cannot message yourself'; end if;
  if not exists (select 1 from public.profiles where id = p_other_user) then raise exception 'Member not found'; end if;

  v_key := least(auth.uid()::text, p_other_user::text) || ':' || greatest(auth.uid()::text, p_other_user::text);
  perform pg_advisory_xact_lock(hashtextextended(v_key, 0));

  select id into v_id from public.conversations where direct_key = v_key;
  if v_id is null then
    insert into public.conversations(kind, direct_key, created_by)
    values ('direct', v_key, auth.uid()) returning id into v_id;
  end if;

  insert into public.conversation_members(conversation_id, user_id, member_role)
  values (v_id, auth.uid(), 'member'), (v_id, p_other_user, 'member')
  on conflict do nothing;
  return v_id;
end;
$$;

create or replace function public.bump_conversation_after_message()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.conversations set last_message_at = new.created_at where id = new.conversation_id;
  return new;
end;
$$;

drop trigger if exists messages_bump_conversation on public.messages;
create trigger messages_bump_conversation after insert on public.messages
for each row execute procedure public.bump_conversation_after_message();

create or replace function public.my_conversations()
returns table (
  conversation_id uuid,
  kind text,
  display_title text,
  display_avatar text,
  last_message text,
  last_message_at timestamptz,
  unread_count bigint,
  other_user_id uuid,
  other_full_name text,
  other_headline text
)
language sql stable security definer set search_path = public
as $$
  select
    c.id,
    c.kind,
    case when c.kind = 'direct' then coalesce(other_profile.full_name, 'Member') else coalesce(c.title, 'Group chat') end,
    case when c.kind = 'direct' then other_profile.avatar_url else c.avatar_url end,
    coalesce(last_msg.body, case when last_msg.attachment_path is not null then 'Sent an attachment' else 'No messages yet' end),
    c.last_message_at,
    (
      select count(*) from public.messages unread
      where unread.conversation_id = c.id
        and unread.sender_id <> auth.uid()
        and unread.created_at > cm.last_read_at
        and unread.deleted_at is null
    ),
    other_profile.id,
    other_profile.full_name,
    other_profile.headline
  from public.conversation_members cm
  join public.conversations c on c.id = cm.conversation_id
  left join lateral (
    select p.* from public.conversation_members om
    join public.profiles p on p.id = om.user_id
    where om.conversation_id = c.id and om.user_id <> auth.uid()
    order by om.joined_at limit 1
  ) other_profile on c.kind = 'direct'
  left join lateral (
    select m.body, m.attachment_path from public.messages m
    where m.conversation_id = c.id and m.deleted_at is null
    order by m.created_at desc limit 1
  ) last_msg on true
  where cm.user_id = auth.uid()
  order by c.last_message_at desc;
$$;

-- ---------------------------------------------------------------------------
-- Communities, groups and community posts
-- ---------------------------------------------------------------------------

create table if not exists public.spaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 3 and 80),
  slug text not null unique,
  description text not null default '',
  space_type text not null check (space_type in ('community','group')),
  privacy text not null default 'public' check (privacy in ('public','private')),
  category text not null default 'General',
  cover_url text,
  created_by uuid not null references public.profiles(id) on delete cascade,
  conversation_id uuid references public.conversations(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.space_members (
  space_id uuid not null references public.spaces(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  member_role text not null default 'member' check (member_role in ('owner','moderator','member')),
  joined_at timestamptz not null default now(),
  primary key (space_id, user_id)
);

create table if not exists public.space_join_requests (
  id uuid primary key default gen_random_uuid(),
  space_id uuid not null references public.spaces(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  unique (space_id, user_id)
);

create table if not exists public.space_posts (
  id uuid primary key default gen_random_uuid(),
  space_id uuid references public.spaces(id) on delete cascade,
  author_id uuid not null constraint space_posts_author_id_fkey references public.profiles(id) on delete cascade,
  title text not null default '',
  body text not null default '',
  category text not null default 'Daily Update',
  media_url text,
  media_type text check (media_type in ('image','video')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint post_has_content check (length(trim(body)) > 0 or media_url is not null)
);

create table if not exists public.post_likes (
  post_id uuid not null references public.space_posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.post_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.space_posts(id) on delete cascade,
  author_id uuid not null constraint post_comments_author_id_fkey references public.profiles(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 1500),
  created_at timestamptz not null default now()
);

create index if not exists space_posts_created_idx on public.space_posts(created_at desc);
create index if not exists space_posts_space_created_idx on public.space_posts(space_id, created_at desc);
create index if not exists post_comments_post_idx on public.post_comments(post_id, created_at);

create or replace function public.is_space_member(p_space_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.space_members
    where space_id = p_space_id and user_id = auth.uid()
  );
$$;

create or replace function public.can_access_space(p_space_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.spaces s
    where s.id = p_space_id and (s.privacy = 'public' or public.is_space_member(s.id) or public.is_admin())
  );
$$;

create or replace function public.can_access_post(p_post_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.space_posts p
    where p.id = p_post_id and (p.space_id is null or public.can_access_space(p.space_id))
  );
$$;

create or replace function public.make_space_slug(p_name text)
returns text language sql immutable as $$
  select trim(both '-' from regexp_replace(lower(trim(p_name)), '[^a-z0-9]+', '-', 'g'));
$$;

create or replace function public.create_space(
  p_name text,
  p_description text,
  p_space_type text,
  p_privacy text,
  p_category text,
  p_cover_url text default null
)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  v_space uuid;
  v_chat uuid;
  v_slug text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_space_type not in ('community','group') then raise exception 'Invalid space type'; end if;
  if p_privacy not in ('public','private') then raise exception 'Invalid privacy'; end if;
  if p_space_type = 'community' then p_privacy := 'public'; end if;
  if char_length(trim(p_name)) < 3 then raise exception 'Name is too short'; end if;

  v_slug := public.make_space_slug(p_name) || '-' || substr(replace(gen_random_uuid()::text, '-', ''), 1, 7);
  insert into public.conversations(kind, title, description, created_by)
  values ('group', trim(p_name), coalesce(p_description,''), auth.uid()) returning id into v_chat;
  insert into public.conversation_members(conversation_id, user_id, member_role)
  values (v_chat, auth.uid(), 'owner');

  insert into public.spaces(name, slug, description, space_type, privacy, category, cover_url, created_by, conversation_id)
  values (trim(p_name), v_slug, coalesce(p_description,''), p_space_type, p_privacy, coalesce(nullif(trim(p_category),''),'General'), p_cover_url, auth.uid(), v_chat)
  returning id into v_space;
  insert into public.space_members(space_id, user_id, member_role)
  values (v_space, auth.uid(), 'owner');
  return v_space;
end;
$$;

create or replace function public.join_space(p_space_id uuid)
returns void
language plpgsql security definer set search_path = public
as $$
declare v_chat uuid; v_privacy text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select conversation_id, privacy into v_chat, v_privacy from public.spaces where id = p_space_id;
  if v_privacy is null then raise exception 'Space not found'; end if;
  if v_privacy <> 'public' then raise exception 'Request access to join this private group'; end if;
  insert into public.space_members(space_id, user_id) values (p_space_id, auth.uid()) on conflict do nothing;
  if v_chat is not null then
    insert into public.conversation_members(conversation_id, user_id) values (v_chat, auth.uid()) on conflict do nothing;
  end if;
end;
$$;

create or replace function public.request_space_access(p_space_id uuid)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.spaces where id = p_space_id and privacy = 'private') then
    raise exception 'Private group not found';
  end if;
  insert into public.space_join_requests(space_id, user_id, status)
  values (p_space_id, auth.uid(), 'pending')
  on conflict (space_id, user_id) do update set status = 'pending', created_at = now(), reviewed_at = null;
end;
$$;

create or replace function public.review_space_request(p_request_id uuid, p_approve boolean)
returns void
language plpgsql security definer set search_path = public
as $$
declare v_space uuid; v_user uuid; v_chat uuid;
begin
  select r.space_id, r.user_id, s.conversation_id into v_space, v_user, v_chat
  from public.space_join_requests r join public.spaces s on s.id = r.space_id
  where r.id = p_request_id
    and (s.created_by = auth.uid() or exists (
      select 1 from public.space_members sm where sm.space_id = s.id and sm.user_id = auth.uid() and sm.member_role in ('owner','moderator')
    ) or public.is_admin());
  if v_space is null then raise exception 'Request not found or not permitted'; end if;
  update public.space_join_requests set status = case when p_approve then 'approved' else 'rejected' end, reviewed_at = now() where id = p_request_id;
  if p_approve then
    insert into public.space_members(space_id, user_id) values (v_space, v_user) on conflict do nothing;
    if v_chat is not null then insert into public.conversation_members(conversation_id, user_id) values (v_chat, v_user) on conflict do nothing; end if;
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- 24-hour stories
-- ---------------------------------------------------------------------------

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null constraint stories_author_id_fkey references public.profiles(id) on delete cascade,
  media_url text not null,
  media_type text not null default 'image' check (media_type in ('image','video')),
  caption text not null default '',
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);

create table if not exists public.story_views (
  story_id uuid not null references public.stories(id) on delete cascade,
  viewer_id uuid not null references public.profiles(id) on delete cascade,
  viewed_at timestamptz not null default now(),
  primary key (story_id, viewer_id)
);

create index if not exists stories_expiry_idx on public.stories(expires_at desc);

-- ---------------------------------------------------------------------------
-- Advertisement packages and campaign panel
-- ---------------------------------------------------------------------------

create table if not exists public.ad_packages (
  id smallint primary key,
  name text not null,
  price_pkr integer not null check (price_pkr between 1000 and 10000),
  duration_days integer not null,
  placement text not null,
  features text[] not null default '{}',
  active boolean not null default true
);

insert into public.ad_packages(id, name, price_pkr, duration_days, placement, features) values
  (1, 'Starter', 1000, 3, 'Community feed', array['3-day campaign','Feed placement','Basic targeting']),
  (2, 'Growth', 2500, 7, 'Feed + communities', array['7-day campaign','Community placement','Audience targeting']),
  (3, 'Professional', 5000, 14, 'Priority feed + communities', array['14-day campaign','Priority rotation','Performance summary']),
  (4, 'Business', 7500, 21, 'High-priority network placement', array['21-day campaign','High-priority rotation','Creative review']),
  (5, 'Elite', 10000, 30, 'Premium network placement', array['30-day campaign','Premium rotation','Detailed performance summary'])
on conflict (id) do update set
  name = excluded.name, price_pkr = excluded.price_pkr, duration_days = excluded.duration_days,
  placement = excluded.placement, features = excluded.features, active = true;

create table if not exists public.ad_campaigns (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null constraint ad_campaigns_owner_id_fkey references public.profiles(id) on delete cascade,
  package_id smallint not null references public.ad_packages(id),
  title text not null check (char_length(trim(title)) between 3 and 80),
  caption text not null check (char_length(trim(caption)) between 5 and 500),
  creative_url text not null,
  target_url text,
  audience text not null default 'All members',
  status text not null default 'pending' check (status in ('draft','pending','active','paused','rejected','ended')),
  review_note text,
  starts_at timestamptz,
  ends_at timestamptz,
  impressions bigint not null default 0,
  clicks bigint not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ad_payment_details (
  campaign_id uuid primary key references public.ad_campaigns(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  payment_reference text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.ad_events (
  id bigint generated always as identity primary key,
  campaign_id uuid not null references public.ad_campaigns(id) on delete cascade,
  viewer_id uuid references public.profiles(id) on delete set null,
  event_type text not null check (event_type in ('impression','click')),
  created_at timestamptz not null default now()
);

create index if not exists ad_campaign_status_idx on public.ad_campaigns(status, starts_at, ends_at);

create or replace function public.record_ad_event(p_campaign_id uuid, p_event_type text)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if p_event_type not in ('impression','click') then raise exception 'Invalid event'; end if;
  if not exists (
    select 1 from public.ad_campaigns
    where id = p_campaign_id and status = 'active'
      and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now())
  ) then return; end if;
  insert into public.ad_events(campaign_id, viewer_id, event_type) values (p_campaign_id, auth.uid(), p_event_type);
  update public.ad_campaigns set
    impressions = impressions + case when p_event_type = 'impression' then 1 else 0 end,
    clicks = clicks + case when p_event_type = 'click' then 1 else 0 end
  where id = p_campaign_id;
end;
$$;

drop trigger if exists spaces_touch_updated_at on public.spaces;
create trigger spaces_touch_updated_at before update on public.spaces for each row execute procedure public.touch_updated_at();
drop trigger if exists posts_touch_updated_at on public.space_posts;
create trigger posts_touch_updated_at before update on public.space_posts for each row execute procedure public.touch_updated_at();
drop trigger if exists ads_touch_updated_at on public.ad_campaigns;
create trigger ads_touch_updated_at before update on public.ad_campaigns for each row execute procedure public.touch_updated_at();

-- ---------------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------------

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.spaces enable row level security;
alter table public.space_members enable row level security;
alter table public.space_join_requests enable row level security;
alter table public.space_posts enable row level security;
alter table public.post_likes enable row level security;
alter table public.post_comments enable row level security;
alter table public.stories enable row level security;
alter table public.story_views enable row level security;
alter table public.ad_packages enable row level security;
alter table public.ad_campaigns enable row level security;
alter table public.ad_payment_details enable row level security;
alter table public.ad_events enable row level security;

drop policy if exists profiles_read_authenticated on public.profiles;
create policy profiles_read_authenticated on public.profiles for select to authenticated using (true);
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists conversations_read_members on public.conversations;
create policy conversations_read_members on public.conversations for select to authenticated using (public.is_conversation_member(id));
drop policy if exists conversation_members_read_members on public.conversation_members;
create policy conversation_members_read_members on public.conversation_members for select to authenticated using (public.is_conversation_member(conversation_id));
drop policy if exists conversation_members_update_self on public.conversation_members;
create policy conversation_members_update_self on public.conversation_members for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists messages_read_members on public.messages;
create policy messages_read_members on public.messages for select to authenticated using (public.is_conversation_member(conversation_id));
drop policy if exists messages_send_members on public.messages;
create policy messages_send_members on public.messages for insert to authenticated with check (sender_id = auth.uid() and public.is_conversation_member(conversation_id));
drop policy if exists messages_update_own on public.messages;
create policy messages_update_own on public.messages for update to authenticated using (sender_id = auth.uid()) with check (sender_id = auth.uid() and public.is_conversation_member(conversation_id));

drop policy if exists spaces_read_accessible on public.spaces;
-- Space names/covers are discoverable; private posts and chats remain member-only.
create policy spaces_read_accessible on public.spaces for select to authenticated using (true);
drop policy if exists spaces_update_managers on public.spaces;
create policy spaces_update_managers on public.spaces for update to authenticated using (
  created_by = auth.uid() or exists (select 1 from public.space_members sm where sm.space_id = id and sm.user_id = auth.uid() and sm.member_role in ('owner','moderator')) or public.is_admin()
);
drop policy if exists space_members_read_accessible on public.space_members;
create policy space_members_read_accessible on public.space_members for select to authenticated using (public.can_access_space(space_id));
drop policy if exists join_requests_read_related on public.space_join_requests;
create policy join_requests_read_related on public.space_join_requests for select to authenticated using (
  user_id = auth.uid() or exists (
    select 1 from public.spaces s where s.id = space_id and (
      s.created_by = auth.uid() or public.is_admin() or exists (
        select 1 from public.space_members sm where sm.space_id = s.id and sm.user_id = auth.uid() and sm.member_role in ('owner','moderator')
      )
    )
  )
);

drop policy if exists posts_read_accessible on public.space_posts;
create policy posts_read_accessible on public.space_posts for select to authenticated using (space_id is null or public.can_access_space(space_id));
drop policy if exists posts_create_accessible on public.space_posts;
create policy posts_create_accessible on public.space_posts for insert to authenticated with check (
  author_id = auth.uid() and (space_id is null or public.is_space_member(space_id))
);
drop policy if exists posts_update_own on public.space_posts;
create policy posts_update_own on public.space_posts for update to authenticated using (author_id = auth.uid() or public.is_admin()) with check (author_id = auth.uid() or public.is_admin());
drop policy if exists posts_delete_own on public.space_posts;
create policy posts_delete_own on public.space_posts for delete to authenticated using (author_id = auth.uid() or public.is_admin());

drop policy if exists likes_read_accessible on public.post_likes;
create policy likes_read_accessible on public.post_likes for select to authenticated using (public.can_access_post(post_id));
drop policy if exists likes_create_own on public.post_likes;
create policy likes_create_own on public.post_likes for insert to authenticated with check (user_id = auth.uid() and public.can_access_post(post_id));
drop policy if exists likes_delete_own on public.post_likes;
create policy likes_delete_own on public.post_likes for delete to authenticated using (user_id = auth.uid());
drop policy if exists comments_read_accessible on public.post_comments;
create policy comments_read_accessible on public.post_comments for select to authenticated using (public.can_access_post(post_id));
drop policy if exists comments_create_own on public.post_comments;
create policy comments_create_own on public.post_comments for insert to authenticated with check (author_id = auth.uid() and public.can_access_post(post_id));
drop policy if exists comments_delete_own on public.post_comments;
create policy comments_delete_own on public.post_comments for delete to authenticated using (author_id = auth.uid() or public.is_admin());

drop policy if exists stories_read_current on public.stories;
create policy stories_read_current on public.stories for select to authenticated using (expires_at > now() or author_id = auth.uid());
drop policy if exists stories_create_own on public.stories;
create policy stories_create_own on public.stories for insert to authenticated with check (author_id = auth.uid() and expires_at <= now() + interval '25 hours');
drop policy if exists stories_delete_own on public.stories;
create policy stories_delete_own on public.stories for delete to authenticated using (author_id = auth.uid());
drop policy if exists story_views_read_related on public.story_views;
create policy story_views_read_related on public.story_views for select to authenticated using (
  viewer_id = auth.uid() or exists (select 1 from public.stories s where s.id = story_id and s.author_id = auth.uid())
);
drop policy if exists story_views_create_own on public.story_views;
create policy story_views_create_own on public.story_views for insert to authenticated with check (viewer_id = auth.uid());

drop policy if exists ad_packages_read on public.ad_packages;
create policy ad_packages_read on public.ad_packages for select to authenticated using (active = true or public.is_admin());
drop policy if exists ads_read_owner_active_admin on public.ad_campaigns;
create policy ads_read_owner_active_admin on public.ad_campaigns for select to authenticated using (
  owner_id = auth.uid() or public.is_admin() or (status = 'active' and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now()))
);
drop policy if exists ads_create_own on public.ad_campaigns;
create policy ads_create_own on public.ad_campaigns for insert to authenticated with check (owner_id = auth.uid() and status in ('draft','pending'));
drop policy if exists ads_update_owner_admin on public.ad_campaigns;
create policy ads_update_owner_admin on public.ad_campaigns for update to authenticated
using ((owner_id = auth.uid() and status in ('draft','pending')) or public.is_admin())
with check ((owner_id = auth.uid() and status in ('draft','pending')) or public.is_admin());
drop policy if exists ads_delete_draft on public.ad_campaigns;
create policy ads_delete_draft on public.ad_campaigns for delete to authenticated using ((owner_id = auth.uid() and status in ('draft','pending')) or public.is_admin());
drop policy if exists ad_payment_read_owner_admin on public.ad_payment_details;
create policy ad_payment_read_owner_admin on public.ad_payment_details for select to authenticated using (owner_id = auth.uid() or public.is_admin());
drop policy if exists ad_payment_create_owner on public.ad_payment_details;
create policy ad_payment_create_owner on public.ad_payment_details for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists ad_payment_update_owner on public.ad_payment_details;
create policy ad_payment_update_owner on public.ad_payment_details for update to authenticated using (owner_id = auth.uid() or public.is_admin()) with check (owner_id = auth.uid() or public.is_admin());

-- ---------------------------------------------------------------------------
-- Storage buckets and policies
-- ---------------------------------------------------------------------------

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('avatars','avatars',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('community-media','community-media',true,26214400,array['image/jpeg','image/png','image/webp','video/mp4','video/webm']),
  ('story-media','story-media',true,52428800,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime','video/3gpp']),
  ('ad-creatives','ad-creatives',true,10485760,array['image/jpeg','image/png','image/webp']),
  ('chat-media','chat-media',false,52428800,array['image/jpeg','image/png','image/webp','image/gif','image/heic','image/heif','video/mp4','video/webm','video/quicktime','video/3gpp','video/x-m4v','application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.oasis.opendocument.text','application/vnd.oasis.opendocument.spreadsheet','application/vnd.oasis.opendocument.presentation','text/plain','text/csv'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists public_media_read on storage.objects;
create policy public_media_read on storage.objects for select to public using (bucket_id in ('avatars','community-media','story-media','ad-creatives'));
drop policy if exists authenticated_media_upload on storage.objects;
create policy authenticated_media_upload on storage.objects for insert to authenticated with check (
  bucket_id in ('avatars','community-media','story-media','ad-creatives','chat-media')
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists owner_media_update on storage.objects;
create policy owner_media_update on storage.objects for update to authenticated using ((storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists owner_media_delete on storage.objects;
create policy owner_media_delete on storage.objects for delete to authenticated using ((storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists chat_media_member_read on storage.objects;
create policy chat_media_member_read on storage.objects for select to authenticated using (
  bucket_id = 'chat-media' and exists (
    select 1 from public.messages m
    where m.attachment_path = name and public.is_conversation_member(m.conversation_id)
  )
);

-- ---------------------------------------------------------------------------
-- Realtime and grants
-- ---------------------------------------------------------------------------

do $$
declare t text;
begin
  foreach t in array array['messages','space_posts','post_likes','post_comments','stories','ad_campaigns'] loop
    if not exists (
      select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t
    ) then execute format('alter publication supabase_realtime add table public.%I', t); end if;
  end loop;
end $$;

grant usage on schema public to anon, authenticated;
grant select on public.ad_packages to authenticated;
grant select on public.profiles to authenticated;
revoke update on public.profiles from authenticated;
grant update (full_name, headline, bio, location, skills, avatar_url, cover_url, gender, online_at, updated_at) on public.profiles to authenticated;
grant select on public.conversations to authenticated;
grant select, update on public.conversation_members to authenticated;
grant select, insert, update on public.messages to authenticated;
grant select, update on public.spaces to authenticated;
grant select on public.space_members, public.space_join_requests to authenticated;
grant select, insert, update, delete on public.space_posts, public.post_likes, public.post_comments to authenticated;
grant select, insert, delete on public.stories, public.story_views to authenticated;
grant select, insert, update, delete on public.ad_campaigns to authenticated;
grant select, insert, update on public.ad_payment_details to authenticated;
grant execute on function public.get_or_create_direct_conversation(uuid) to authenticated;
grant execute on function public.my_conversations() to authenticated;
grant execute on function public.create_space(text,text,text,text,text,text) to authenticated;
grant execute on function public.join_space(uuid) to authenticated;
grant execute on function public.request_space_access(uuid) to authenticated;
grant execute on function public.review_space_request(uuid,boolean) to authenticated;
grant execute on function public.record_ad_event(uuid,text) to authenticated;

-- Promote your first account after signup (replace the email):
-- update public.profiles set account_role = 'admin'
-- where id = (select id from auth.users where email = 'you@example.com');
