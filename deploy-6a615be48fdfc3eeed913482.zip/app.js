const GLOBAL_THEME_KEY='skillswape_theme_v10';
const LEGACY_THEME_KEY='skillswape_pro_v3_theme';
function getPreferredThemeMode(){
  const saved=localStorage.getItem(GLOBAL_THEME_KEY)||localStorage.getItem(LEGACY_THEME_KEY);
  if(saved==='dark'||saved==='light')return saved;
  return window.matchMedia&&window.matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light';
}
function updateBrowserTheme(mode){
  const dark=mode==='dark';
  document.documentElement.setAttribute('data-theme',dark?'dark':'light');
  document.documentElement.style.colorScheme=dark?'dark':'light';
  let meta=document.querySelector('meta[name="theme-color"]');
  if(!meta&&document.head){meta=document.createElement('meta');meta.name='theme-color';document.head.appendChild(meta)}
  if(meta)meta.content=dark?'#080b12':'#f4f6fb';
}
updateBrowserTheme(getPreferredThemeMode());

const K='skillswape_pro_v3_';
const $=id=>document.getElementById(id);
const read=(k,f)=>{try{const v=localStorage.getItem(K+k);return v?JSON.parse(v):f}catch{return f}};
const write=(k,v)=>{try{localStorage.setItem(K+k,JSON.stringify(v));return true}catch(e){console.error('LocalStorage write failed:',e);if(typeof toast==='function')toast('Storage full: image thori choti upload karo ya Settings se reset karo');return false}};
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const uid=()=>localStorage.getItem(K+'uid')||'';
const isLoggedIn=()=>!!localStorage.getItem(K+'uid');
const now=()=>new Date().toISOString();
function makeId(p='id'){return p+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)}
const BRAND_LOGO_PATH='assets/skillswape-logo.png';
function installBrandAssets(){
  if(!document.head)return;
  if(!document.head.querySelector('link[data-skillswape-icon]')){
    const icon=document.createElement('link');icon.rel='icon';icon.type='image/png';icon.href=BRAND_LOGO_PATH;icon.dataset.skillswapeIcon='true';document.head.appendChild(icon);
    const touch=document.createElement('link');touch.rel='apple-touch-icon';touch.href=BRAND_LOGO_PATH;touch.dataset.skillswapeIcon='true';document.head.appendChild(touch);
  }
  if(!document.head.querySelector('link[data-skillswape-ui]')){
    const ui=document.createElement('link');ui.rel='stylesheet';ui.href='ui-v10.css';ui.dataset.skillswapeUi='true';document.head.appendChild(ui);
  }
}
installBrandAssets();

const THEME_PRESETS={
  ocean:{name:'Ocean',primary:'#2563eb',secondary:'#0891b2',support:'#0f766e'},
  rose:{name:'Rose',primary:'#d9468f',secondary:'#8b5cf6',support:'#ec4899'},
  neutral:{name:'Classic',primary:'#2563eb',secondary:'#7c3aed',support:'#0f766e'}
};
const FONT_STYLES={
  modern:'Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", Arial, sans-serif',
  friendly:'"Trebuchet MS", "Segoe UI", Arial, sans-serif',
  classic:'Georgia, "Times New Roman", serif',
  compact:'Arial, Helvetica, sans-serif',
  mono:'"SFMono-Regular", Consolas, "Liberation Mono", monospace'
};
function validHex(value){return /^#[0-9a-f]{6}$/i.test(String(value||''))}
function hexRgb(hex){const clean=String(hex||'').replace('#','');if(clean.length!==6)return null;return {r:parseInt(clean.slice(0,2),16),g:parseInt(clean.slice(2,4),16),b:parseInt(clean.slice(4,6),16)}}
function mixHex(hex,target='#ffffff',amount=.2){const a=hexRgb(hex),b=hexRgb(target);if(!a||!b)return hex;const m=n=>Math.max(0,Math.min(255,Math.round(n)));return '#'+[m(a.r+(b.r-a.r)*amount),m(a.g+(b.g-a.g)*amount),m(a.b+(b.b-a.b)*amount)].map(v=>v.toString(16).padStart(2,'0')).join('')}
function rgba(hex,alpha){const c=hexRgb(hex);return c?'rgba('+c.r+','+c.g+','+c.b+','+alpha+')':'rgba(37,99,235,'+alpha+')'}
function isLightColor(hex){const c=hexRgb(hex);if(!c)return false;return ((c.r*299+c.g*587+c.b*114)/1000)>155}
function genderPreset(gender){return gender==='female'?'rose':gender==='male'?'ocean':'neutral'}
function normalizeAppearance(value={}){
  const preset=THEME_PRESETS[value.preset]?value.preset:'neutral';
  return {
    mode:value.mode==='dark'||value.mode==='light'?value.mode:getPreferredThemeMode(),
    preset,
    primary:validHex(value.primary)?value.primary:'',
    background:validHex(value.background)?value.background:'',
    font:FONT_STYLES[value.font]?value.font:'modern'
  };
}
function appearanceKey(){return 'appearance_'+(uid()||'guest')}
function getAppearance(){
  const globalMode=getPreferredThemeMode();
  const stored=read(appearanceKey(),null);
  if(stored){const appearance=normalizeAppearance(stored);appearance.mode=globalMode;return appearance}
  const current=read('users',{})[uid()];
  if(current&&current.appearance){const appearance=normalizeAppearance(current.appearance);appearance.mode=globalMode;return appearance}
  return normalizeAppearance({mode:globalMode,preset:current?genderPreset(current.gender):'neutral',font:'modern'});
}
function applyAppearance(value=getAppearance(),persist=false){
  const appearance=normalizeAppearance(value);
  const preset=THEME_PRESETS[appearance.preset];
  const primary=appearance.primary||preset.primary;
  const root=document.documentElement;
  root.setAttribute('data-theme',appearance.mode);
  root.style.colorScheme=appearance.mode;
  root.setAttribute('data-preset',appearance.preset);
  root.style.setProperty('--font-family',FONT_STYLES[appearance.font]);
  root.style.setProperty('--accent',primary);
  root.style.setProperty('--accent-2',preset.secondary);
  root.style.setProperty('--accent-3',preset.support);
  root.style.setProperty('--cyan',primary);
  root.style.setProperty('--blue',preset.secondary);
  root.style.setProperty('--green',preset.support);
  root.style.setProperty('--violet',preset.secondary);
  root.style.setProperty('--pink',primary);
  root.style.setProperty('--accent-soft',rgba(primary,.12));
  root.style.setProperty('--focus-ring',rgba(primary,.18));
  if(appearance.background){
    const light=appearance.mode==='light';
    const requested=appearance.background;
    const effective=light
      ? (isLightColor(requested)?requested:mixHex(requested,'#ffffff',.88))
      : (isLightColor(requested)?mixHex(requested,'#000000',.80):requested);
    root.setAttribute('data-custom-background','true');
    root.style.setProperty('--bg',effective);
    root.style.setProperty('--bg2',mixHex(effective,light?'#000000':'#ffffff',light?.035:.07));
    root.style.setProperty('--card',light?'rgba(255,255,255,.96)':'rgba(20,25,35,.94)');
    root.style.setProperty('--card2',light?'rgba(255,255,255,.91)':'rgba(13,18,28,.94)');
    root.style.setProperty('--soft',light?'rgba(15,23,42,.055)':'rgba(255,255,255,.075)');
    root.style.setProperty('--line',light?'rgba(15,23,42,.13)':'rgba(255,255,255,.15)');
    root.style.setProperty('--text',light?'#172033':'#f8fafc');
    root.style.setProperty('--muted',light?'#5e6879':'#a8b3c7');
    root.style.setProperty('--muted2',light?'#7a8494':'#78869d');
  }else{
    root.removeAttribute('data-custom-background');
    ['--bg','--bg2','--card','--card2','--soft','--line','--text','--muted','--muted2'].forEach(name=>root.style.removeProperty(name));
  }
  localStorage.setItem(GLOBAL_THEME_KEY,appearance.mode);
  localStorage.setItem(K+'theme',appearance.mode);
  updateBrowserTheme(appearance.mode);
  if(persist){
    write(appearanceKey(),appearance);
    const id=uid(),users=read('users',{});
    if(id&&users[id]){users[id].appearance=appearance;write('users',users)}
  }
  document.querySelectorAll('[data-theme-btn]').forEach(b=>b.classList.toggle('active',b.dataset.themeBtn===appearance.mode));
  document.querySelectorAll('[data-preset-btn]').forEach(b=>b.classList.toggle('active',b.dataset.presetBtn===appearance.preset));
  document.querySelectorAll('[data-theme-toggle]').forEach(button=>{
    button.setAttribute('aria-pressed',String(appearance.mode==='dark'));
    button.setAttribute('aria-label',appearance.mode==='dark'?'Switch to light mode':'Switch to dark mode');
    const icon=button.querySelector('[data-theme-icon]');if(icon)icon.textContent=appearance.mode==='dark'?'☀':'☾';
    const label=button.querySelector('[data-theme-label]');if(label)label.textContent=appearance.mode==='dark'?'Light':'Dark';
  });
  return appearance;
}
function getTheme(){return getAppearance().mode}
function applyTheme(t=getTheme()){const a=getAppearance();a.mode=t==='dark'?'dark':'light';return applyAppearance(a,true)}
function setTheme(t){applyTheme(t);toast((t==='light'?'Light':'Dark')+' mode applied')}
function toggleTheme(){setTheme(getTheme()==='dark'?'light':'dark')}
function setPreset(preset,animate=false){const a=getAppearance();a.preset=THEME_PRESETS[preset]?preset:'neutral';a.primary='';a.background='';applyAppearance(a,true);if(animate)runThemeReveal(a.preset);toast(THEME_PRESETS[a.preset].name+' theme applied')}
function applyGenderTheme(gender,animate=false,persist=true){const a=getAppearance();a.preset=genderPreset(gender);a.primary='';a.background='';applyAppearance(a,persist);if(animate)runThemeReveal(a.preset);return a}
function runThemeReveal(preset='neutral',done){
  if(!document.body){if(done)done();return}
  const old=document.querySelector('.theme-reveal');if(old)old.remove();
  const label=preset==='rose'?'Rose theme ready':preset==='ocean'?'Ocean theme ready':'Your theme is ready';
  const layer=document.createElement('div');layer.className='theme-reveal '+preset;layer.innerHTML='<div class="theme-reveal-orb"></div><div class="theme-reveal-brand"><img class="theme-reveal-logo" src="'+BRAND_LOGO_PATH+'" alt=""><div class="theme-reveal-copy"><span>SkillSwape AI</span><b>'+label+'</b><small>You can customize every color later in Settings.</small></div></div>';
  document.body.appendChild(layer);
  requestAnimationFrame(()=>layer.classList.add('show'));
  setTimeout(()=>layer.classList.add('leave'),1050);
  setTimeout(()=>{layer.remove();if(done)done()},1550);
}
function previewGenderTheme(gender){applyGenderTheme(gender,true,false)}
applyAppearance(getAppearance(),false);
window.addEventListener('storage',event=>{
  if(event.key!==GLOBAL_THEME_KEY||(event.newValue!=='dark'&&event.newValue!=='light'))return;
  const appearance=getAppearance();appearance.mode=event.newValue;applyAppearance(appearance,false);
});
function user(){let users=read('users',{});let id=uid();if(id&&users[id])return users[id];return {uid:'guest',name:'Guest User',email:'guest@skillswape.local',role:'Visitor',bio:'Login to unlock SkillSwape AI.',location:'',photoURL:'',coverURL:'',skills:[],gender:'',appearance:getAppearance()}}
function avatar(u={},cls=''){const name=(u.name||u.email||'U').trim();return `<div class="avatar ${cls}">${u.photoURL?`<img src="${esc(u.photoURL)}" alt="">`:esc(name[0]||'U').toUpperCase()}</div>`}
function demoImage(cat='SkillSwape',title='Premium Post'){const colors={Development:['#22d3ee','#2563eb'],Design:['#ec7eb8','#9b65d5'],Marketing:['#10b981','#22c55e'],Writing:['#f59e0b','#f97316'],Marketplace:['#06b6d4','#10b981'],Question:['#818cf8','#22d3ee'],Offer:['#10b981','#2563eb']};let c=colors[cat]||['#e174b5','#8b6fd6'];let safeTitle=esc(title);let safeCat=esc(cat);let svg=`<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='700' viewBox='0 0 1200 700'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop stop-color='${c[0]}'/><stop offset='1' stop-color='${c[1]}'/></linearGradient><filter id='blur'><feGaussianBlur stdDeviation='38'/></filter></defs><rect width='1200' height='700' fill='#020617'/><circle cx='980' cy='110' r='260' fill='url(#g)' opacity='.42' filter='url(#blur)'/><circle cx='160' cy='610' r='300' fill='url(#g)' opacity='.25' filter='url(#blur)'/><rect x='82' y='82' width='1036' height='536' rx='46' fill='rgba(15,23,42,.80)' stroke='rgba(255,255,255,.22)'/><text x='132' y='180' fill='white' font-family='Arial, sans-serif' font-size='42' font-weight='900'>SkillSwape AI</text><text x='132' y='305' fill='white' font-family='Arial, sans-serif' font-size='68' font-weight='900'>${safeTitle}</text><text x='132' y='370' fill='${c[0]}' font-family='Arial, sans-serif' font-size='30' font-weight='800'>${safeCat}</text><rect x='132' y='460' width='235' height='64' rx='22' fill='url(#g)'/><text x='249' y='501' text-anchor='middle' fill='white' font-family='Arial, sans-serif' font-size='23' font-weight='900'>View Post</text></svg>`;return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg)}
function seed(){
  if(localStorage.getItem(K+'seeded_v3'))return;
  const me={uid:'me',name:'Jordan',email:'jordan@skillswape.local',password:'123456',role:'SkillSwape Creator',location:'Pakistan',skills:['HTML','CSS','JavaScript','AI Tools'],bio:'Building SkillSwape AI with a practical community experience.',photoURL:'',coverURL:'',gender:'male',appearance:{mode:getPreferredThemeMode(),preset:'ocean',primary:'',background:'',font:'modern'},createdAt:now()};
  const users={
    me,
    demo_ayesha:{uid:'demo_ayesha',name:'Ayesha Khan',role:'UI/UX Designer',location:'Karachi',skills:['Figma','Branding','Mobile UI'],bio:'Designing clean mobile apps, dashboards and usable digital products.',photoURL:'',coverURL:'',gender:'female'},
    demo_bilal:{uid:'demo_bilal',name:'Bilal Ahmed',role:'Frontend Developer',location:'Lahore',skills:['React','JavaScript','CSS'],bio:'Frontend developer helping people build accessible web apps.',photoURL:'',coverURL:'',gender:'male'},
    demo_sara:{uid:'demo_sara',name:'Sara Malik',role:'Digital Marketer',location:'Islamabad',skills:['SEO','Content','Social Media'],bio:'Marketing and content strategy for startups and creators.',photoURL:'',coverURL:'',gender:'female'},
    demo_hassan:{uid:'demo_hassan',name:'Hassan Raza',role:'Video Editor',location:'Rawalpindi',skills:['Video Editing','Reels','After Effects'],bio:'Editing clear, engaging reels and short-form videos.',photoURL:'',coverURL:'',gender:'male'}
  };
  write('users',users);
  write('posts',[
    {id:makeId('post'),userId:'demo_bilal',title:'React landing page collaboration',text:'I have finished a responsive landing-page starter and can help someone with clean components and mobile layouts. In exchange, I would appreciate a quick UI review.',category:'Development',imageURL:demoImage('Development','React Development'),createdAt:new Date(Date.now()-1800000).toISOString(),comments:[{by:'demo_ayesha',text:'Happy to review the mobile flow. Send me the key screens.',at:new Date(Date.now()-1200000).toISOString()}]},
    {id:makeId('post'),userId:'demo_ayesha',title:'Dashboard design feedback',text:'I am refining a dashboard in Figma and would value feedback on hierarchy and navigation. I can exchange a design review for JavaScript help.',category:'Design',imageURL:demoImage('Design','Dashboard UI'),createdAt:new Date(Date.now()-4200000).toISOString(),comments:[]},
    {id:makeId('post'),userId:'demo_sara',title:'Portfolio SEO checklist',text:'I made a short checklist for portfolio titles, headings, page speed and project descriptions. Message me if you would like a quick review.',category:'Marketing',imageURL:demoImage('Marketing','SEO Checklist'),createdAt:new Date(Date.now()-8200000).toISOString(),comments:[]},
    {id:makeId('post'),userId:'demo_hassan',title:'Short-video editing exchange',text:'I can edit a 30-second reel with captions and clean transitions. I am looking for help improving my portfolio website.',category:'Marketplace',imageURL:demoImage('Marketplace','Video Editing'),createdAt:new Date(Date.now()-11000000).toISOString(),comments:[]}
  ]);
  write('likes',{});write('shares',{});write('saved',[]);
  write('notifications',[{id:makeId('n'),title:'Welcome to SkillSwape AI',text:'Complete your profile, customize your theme and create your first post.',at:now(),read:false}]);
  localStorage.setItem(K+'seeded_v3','yes');
}
seed();
function migrateV8(){
  if(localStorage.getItem(K+'migration_v8')==='done')return;
  const users=read('users',{});
  const known={me:'male',demo_ayesha:'female',demo_bilal:'male',demo_sara:'female',demo_hassan:'male'};
  Object.entries(known).forEach(([id,gender])=>{if(users[id]&&!users[id].gender)users[id].gender=gender});
  write('users',users);
  const robotic=/For website bugs|Website bugs ke liye|Good point\. Tell me|Acha point hai|Community Feed now supports|Community Feed me image crop|Dark and Light theme works globally|Dark aur Light theme global/i;
  Object.keys(localStorage).filter(key=>key.startsWith(K+'chat_')).forEach(key=>{
    try{
      const arr=JSON.parse(localStorage.getItem(key)||'[]');
      const cleaned=arr.filter(message=>!(String(message.from||'').startsWith('demo_')&&robotic.test(String(message.text||'')))).map(message=>{
        if(message.text==='Hi! Welcome to SkillSwape chat. You can ask in English or Roman Urdu.')return {...message,text:'Hi, good to connect with you. What would you like to collaborate on?'};
        return message;
      });
      localStorage.setItem(key,JSON.stringify(cleaned));
    }catch(_){}
  });
  localStorage.setItem(K+'migration_v8','done');
}
migrateV8();
function toast(t){let el=$('toast');if(!el){el=document.createElement('div');el.id='toast';el.className='toast';document.body.appendChild(el)}el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2800)}
function timeAgo(t){let s=Math.floor((Date.now()-new Date(t||Date.now()).getTime())/1000);if(isNaN(s)||s<0)s=0;if(s<60)return'just now';if(s<3600)return Math.floor(s/60)+'m ago';if(s<86400)return Math.floor(s/3600)+'h ago';return Math.floor(s/86400)+'d ago'}
async function fileData(file,opts={}){return imageFileToDataURL(file,opts)}
async function imageFileToDataURL(file,opts={}){return new Promise((res,rej)=>{if(!file)return res('');if(!file.type||!file.type.startsWith('image/')){toast('Sirf image file upload karo');return res('')}const maxW=opts.maxW||1280,maxH=opts.maxH||1280,quality=opts.quality||0.82;const r=new FileReader();r.onerror=()=>rej(new Error('File read failed'));r.onload=()=>{const img=new Image();img.onerror=()=>rej(new Error('Image load failed'));img.onload=()=>{let w=img.width,h=img.height,scale=Math.min(1,maxW/w,maxH/h);w=Math.max(1,Math.round(w*scale));h=Math.max(1,Math.round(h*scale));const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d');ctx.drawImage(img,0,0,w,h);let out=c.toDataURL('image/jpeg',quality);res(out)};img.src=r.result};r.readAsDataURL(file)})}
async function coverFileData(file){return imageFileToDataURL(file,{maxW:1600,maxH:650,quality:.8})}
function updateUser(data){let users=read('users',{});const id=uid();if(!id){toast('Please login first');return user()}users[id]={...(users[id]||{}),...data,uid:id,updatedAt:now()};write('users',users);let posts=read('posts',[]);posts=posts.map(p=>p.userId===id?{...p,userName:users[id].name,userPhoto:users[id].photoURL}:p);write('posts',posts);return users[id]}
function currentUserOrParam(){const users=read('users',{});const param=new URLSearchParams(location.search).get('u');return users[param]||user()}
function logout(){localStorage.removeItem(K+'uid');toast('Logged out');setTimeout(()=>location.href='login.html',500)}
function normalizeEmail(email){return String(email||'').trim().toLowerCase()}
function finishLogin(account,animate=false){
  localStorage.setItem(K+'uid',account.uid);
  const appearance={...(account.appearance||{preset:genderPreset(account.gender),primary:'',background:'',font:'modern'}),mode:getPreferredThemeMode()};
  applyAppearance(appearance,true);
  toast('Login successful');
  if(animate)runThemeReveal(appearance.preset,()=>location.href='daily-feed.html');
  else setTimeout(()=>location.href='daily-feed.html',450);
  return true;
}
function loginUser(email,password){
  email=normalizeEmail(email);password=String(password||'');
  if(!email||!password){toast('Email aur password required');return false}
  const users=read('users',{});
  let account=Object.values(users).find(item=>normalizeEmail(item.email)===email&&String(item.password||'')===password);
  if(!account&&email==='jordan@skillswape.local'&&password==='123456')account=users.me;
  if(!account){toast('Email ya password ghalat hai');return false}
  return finishLogin(account,false);
}
function signupUser(data){
  const name=String(data.name||'').trim(),email=normalizeEmail(data.email),password=String(data.password||'');
  const role=String(data.role||'SkillSwape Member').trim()||'SkillSwape Member';
  const gender=['male','female','other'].includes(data.gender)?data.gender:'';
  if(!name||!email||!password){toast('Name, email aur password required');return false}
  if(!gender){toast('Please select a gender or Prefer not to say');return false}
  if(password.length<6){toast('Password minimum 6 characters hona chahiye');return false}
  const users=read('users',{});
  if(Object.values(users).some(item=>normalizeEmail(item.email)===email)){toast('Ye email already registered hai');return false}
  const id=makeId('user'),appearance={mode:getPreferredThemeMode(),preset:genderPreset(gender),primary:'',background:'',font:'modern'};
  users[id]={uid:id,name,email,password,role,gender,location:data.location||'Pakistan',bio:data.bio||'',skills:String(data.skills||'').split(',').map(x=>x.trim()).filter(Boolean),photoURL:'',coverURL:'',appearance,createdAt:now()};
  write('users',users);localStorage.setItem(K+'uid',id);write(appearanceKey(),appearance);applyAppearance(appearance,true);
  write('notifications',[{id:makeId('n'),title:'Account created',text:'Welcome to SkillSwape AI. Your starter theme is ready and can be changed anytime.',at:now(),read:false},...read('notifications',[])]);
  toast('Signup successful');
  runThemeReveal(appearance.preset,()=>location.href='daily-feed.html');
  return true;
}

let pendingGoogleProfile=null;
function decodeGoogleCredential(token){
  try{
    const part=String(token||'').split('.')[1];if(!part)return null;
    const normalized=part.replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(part.length/4)*4,'=');
    const binary=atob(normalized),bytes=Uint8Array.from(binary,char=>char.charCodeAt(0));
    return JSON.parse(new TextDecoder().decode(bytes));
  }catch(_){return null}
}
function googleSetupHelp(){toast('Google signup ke liye config.js mein apna Web OAuth Client ID add karein.')}
function initGoogleAuth(targetId){
  const target=$(targetId);if(!target)return;
  const clientId=String((window.SKILLSWAPE_CONFIG||{}).googleClientId||'').trim();
  if(!clientId||clientId.includes('PASTE_')){
    target.innerHTML='<button type="button" class="google-button" onclick="googleSetupHelp()"><span class="google-g">G</span> Continue with Google</button><small class="google-setup-note">Google OAuth Client ID required in config.js</small>';
    return;
  }
  let attempts=0;
  const boot=()=>{
    attempts++;
    if(window.google&&google.accounts&&google.accounts.id){
      google.accounts.id.initialize({client_id:clientId,callback:handleGoogleCredential,auto_select:false,cancel_on_tap_outside:true});
      target.innerHTML='';
      google.accounts.id.renderButton(target,{type:'standard',theme:getTheme()==='dark'?'filled_black':'outline',size:'large',shape:'pill',text:'continue_with',logo_alignment:'left',width:320});
    }else if(attempts<40)setTimeout(boot,150);
    else target.innerHTML='<button type="button" class="google-button" onclick="toast(\'Google sign-in could not load. Check internet and authorized origin.\')"><span class="google-g">G</span> Continue with Google</button>';
  };
  boot();
}
function handleGoogleCredential(response){
  const profile=decodeGoogleCredential(response&&response.credential);
  if(!profile||!profile.email||profile.email_verified===false){toast('Google account verify nahi ho saka.');return}
  const users=read('users',{}),existing=Object.values(users).find(item=>normalizeEmail(item.email)===normalizeEmail(profile.email));
  if(existing&&existing.gender){finishLogin(existing,false);return}
  pendingGoogleProfile={sub:profile.sub||'',name:profile.name||profile.given_name||'Google User',email:profile.email,picture:profile.picture||'',existingId:existing&&existing.uid};
  openGoogleGenderModal();
}
function openGoogleGenderModal(){
  let modal=$('googleGenderModal');
  if(!modal){modal=document.createElement('div');modal.id='googleGenderModal';modal.className='modal google-gender-modal';document.body.appendChild(modal)}
  modal.innerHTML='<div class="modal-card google-gender-card"><div class="modal-head"><div><h2>Choose your starter theme</h2><p class="muted modal-subtitle">This only selects the first look. You can customize it later.</p></div></div><div class="modal-body"><div class="gender-theme-grid"><button type="button" class="gender-theme-card ocean" onclick="completeGoogleSignup(\'male\')"><b>Ocean</b><span>Blue and teal starter theme</span></button><button type="button" class="gender-theme-card rose" onclick="completeGoogleSignup(\'female\')"><b>Rose</b><span>Rose and violet starter theme</span></button><button type="button" class="gender-theme-card neutral" onclick="completeGoogleSignup(\'other\')"><b>Classic</b><span>Balanced neutral starter theme</span></button></div></div></div>';
  modal.classList.add('open');
}
function completeGoogleSignup(gender){
  if(!pendingGoogleProfile)return;
  const users=read('users',{}),profile=pendingGoogleProfile;
  const id=profile.existingId||('google_'+String(profile.sub||makeId('user')).replace(/[^a-z0-9_-]/gi,'').slice(0,48));
  const appearance={mode:getPreferredThemeMode(),preset:genderPreset(gender),primary:'',background:'',font:'modern'};
  users[id]={...(users[id]||{}),uid:id,name:profile.name,email:normalizeEmail(profile.email),role:(users[id]&&users[id].role)||'SkillSwape Member',gender,location:(users[id]&&users[id].location)||'Pakistan',bio:(users[id]&&users[id].bio)||'',skills:(users[id]&&users[id].skills)||[],photoURL:profile.picture||(users[id]&&users[id].photoURL)||'',coverURL:(users[id]&&users[id].coverURL)||'',googleAuth:true,appearance,createdAt:(users[id]&&users[id].createdAt)||now()};
  write('users',users);localStorage.setItem(K+'uid',id);write('appearance_'+id,appearance);applyAppearance(appearance,true);
  const modal=$('googleGenderModal');if(modal)modal.classList.remove('open');
  write('notifications',[{id:makeId('n'),title:'Google account connected',text:'Welcome to SkillSwape AI. Complete your profile when you are ready.',at:now(),read:false},...read('notifications',[])]);
  pendingGoogleProfile=null;runThemeReveal(appearance.preset,()=>location.href='daily-feed.html');
}
function requireAuth(){if(!isLoggedIn()){toast('Please login first');setTimeout(()=>location.href='login.html',450);return false}return true}
function themeSwitchHTML(){const t=getTheme();return '<div class="theme-switch" role="group" aria-label="Color mode"><button data-theme-btn="light" class="'+(t==='light'?'active':'')+'" onclick="setTheme(\'light\')" aria-label="Use light mode">☀ <span>Light</span></button><button data-theme-btn="dark" class="'+(t==='dark'?'active':'')+'" onclick="setTheme(\'dark\')" aria-label="Use dark mode">☾ <span>Dark</span></button><a class="theme-customize-link" href="settings.html" title="Customize appearance">Edit</a></div>'}
function themeToggleHTML(){const dark=getTheme()==='dark';return '<button type="button" class="theme-toggle" data-theme-toggle onclick="toggleTheme()" aria-pressed="'+dark+'" aria-label="'+(dark?'Switch to light mode':'Switch to dark mode')+'"><span class="theme-toggle-icon" data-theme-icon aria-hidden="true">'+(dark?'☀':'☾')+'</span><span data-theme-label>'+(dark?'Light':'Dark')+'</span></button>'}
function layout(active='feed'){
  if(!isLoggedIn()){
    location.replace('login.html');
    document.write(`<div class="page-center"><div class="panel card"><h2>Login required</h2><p class="muted">Redirecting to login...</p><a class="btn" href="login.html">Login</a></div></div>`);
    return;
  }
  let u=user();
  document.write(`<div class="app"><aside class="sidebar panel">
    <div class="brand"><div class="logo" aria-hidden="true">S</div><div><h2>SkillSwape <span class="gradient">AI</span></h2><small>Learn, share and collaborate</small></div></div>
    <a class="mini-profile" href="profile.html"><div>${avatar(u,'sm')}</div><div><b>${esc(u.name)}</b><p>${esc(u.role)}</p></div></a>
    <div class="section-title">Navigation</div>
    <nav class="nav">
      <a class="${active==='feed'?'active':''}" href="daily-feed.html"><span>Community Feed</span></a>
      <a class="${active==='profile'?'active':''}" href="profile.html"><span>Profile</span></a>
      <a class="${active==='market'?'active':''}" href="marketplace.html"><span>Marketplace</span></a>
      <a class="${active==='search'?'active':''}" href="search.html"><span>Find People</span></a>
      <a class="${active==='chat'?'active':''}" href="chat.html"><span>Chat</span></a>
      <a class="${active==='ai'?'active':''}" href="ai-assistant.html"><span>AI Assistant</span></a>
      <a class="${active==='notify'?'active':''}" href="notifications.html"><span>Notifications</span></a>
      <a class="${active==='settings'?'active':''}" href="settings.html"><span>Settings</span></a>
      <button onclick="logout()" style="text-align:left"><span>Logout</span></button>
    </nav>
    <div class="game-block">
      <div class="section-title">Daily Games</div>
      <nav class="nav">
        <a class="${active==='games'?'active':''}" href="games.html"><span>Games Hub</span></a>
        <a class="${active==='game-pinpoint'?'active':''}" href="game-pinpoint.html"><span>Skill Pinpoint</span></a>
        <a class="${active==='game-focus'?'active':''}" href="game-focus-grid.html"><span>Focus Grid</span></a>
        <a class="${active==='game-career'?'active':''}" href="game-career-path.html"><span>Career Sprint</span></a>
      </nav>
      <div class="section-title">Classic Games</div>
      <nav class="nav">
        <a class="${active==='game-color'?'active':''}" href="game-color.html"><span>Name the Color</span></a>
        <a class="${active==='game-timeline'?'active':''}" href="game-timeline.html"><span>Creator Quiz</span></a>
        <a class="${active==='game-typing'?'active':''}" href="game-typing.html"><span>Typing Speed</span></a>
      </nav>
      <div class="section-title">Theme</div><div style="padding:0 12px 14px">${themeSwitchHTML()}</div>
    </div>
  </aside><nav class="mobile-bottom-nav" aria-label="Mobile navigation"><a href="daily-feed.html">Feed</a><a href="marketplace.html">Market</a><a href="chat.html">Chat</a><a href="games.html">Games</a><a href="profile.html">Profile</a></nav><main class="main">`)
}
function topbar(title,subtitle='',actions=''){document.write(`<div class="topbar"><div><h1>${title}</h1>${subtitle?`<p>${subtitle}</p>`:''}</div><div class="top-actions"><a class="btn secondary" href="profile.html">View Profile</a>${themeSwitchHTML()}${actions}</div></div>`)}
function topbarV8(title,subtitle='',actions=''){
  document.write('<div class="topbar"><div><h1>'+esc(title)+'</h1>'+(subtitle?'<p>'+esc(subtitle)+'</p>':'')+'</div><div class="top-actions">'+themeToggleHTML()+actions+'</div></div>');
}
topbar=topbarV8;
function endLayout(){document.write(`</main></div><div id="toast" class="toast"></div>`)}
function renderRight(){const users=Object.values(read('users',{}));const posts=read('posts',[]);if($('rPosts'))$('rPosts').textContent=posts.length;if($('rUsers'))$('rUsers').textContent=users.length;if($('rSkills'))$('rSkills').textContent=new Set(users.flatMap(u=>u.skills||[])).size;if($('onlineUsers'))$('onlineUsers').innerHTML=users.filter(x=>x.uid!==uid()).slice(0,5).map(u=>`<a class="member" href="chat.html?user=${esc(u.uid)}">${avatar(u,'sm')}<div><b>${esc(u.name)}</b><p>${esc(u.role)}</p></div><span class="online"></span></a>`).join('')||'<div class="empty">No members</div>'}
function postCard(p,{compact=false}={}){const users=read('users',{}),u=users[p.userId]||{name:p.userName||'User'},likes=read('likes',{}),l=likes[p.id]||[],liked=l.includes(uid()),can=p.userId===uid();return `<article class="post"><div class="post-head"><a class="user-line" href="profile.html?u=${esc(p.userId)}">${avatar(u,'sm')}<div><b>${esc(u.name)}</b><p>${esc(p.category)} · ${timeAgo(p.createdAt)}</p></div></a><span class="tag">${esc(p.category)}</span></div><h2>${esc(p.title)}</h2><p class="post-text">${esc(p.text)}</p>${p.imageURL&&!compact?`<div class="post-img"><img src="${p.imageURL}" alt=""></div>`:''}${p.videoKey&&!compact?`<a class="post-video-placeholder" href="daily-feed.html"><b>Community video post</b><span>Open Community Feed to play this video</span></a>`:''}<div class="post-actions"><button class="${liked?'liked':''}" onclick="likePost('${p.id}')">Like · ${l.length}</button><button onclick="sharePost('${p.id}')">Share</button><button onclick="savePost('${p.id}')">Save</button><a href="chat.html?user=${esc(p.userId)}">Message</a>${can?`<button class="danger" onclick="deletePost('${p.id}')">Delete</button>`:`<a href="profile.html?u=${esc(p.userId)}">Profile</a>`}</div>${!compact?`<div class="comments"><div>${(p.comments||[]).slice(-2).map(c=>`<div class="comment"><b>${esc((users[c.by]||{}).name||'User')}:</b> ${esc(c.text)}</div>`).join('')}</div><div class="comment-row"><input id="c_${p.id}" placeholder="Write a comment..."><button class="btn secondary" onclick="commentPost('${p.id}')">Send</button></div></div>`:''}</article>`}
function likePost(pid){let likes=read('likes',{});likes[pid]=likes[pid]||[];likes[pid]=likes[pid].includes(uid())?likes[pid].filter(x=>x!==uid()):[...likes[pid],uid()];write('likes',likes);if(window.renderFeed)renderFeed();if(window.renderProfilePosts)renderProfilePosts();toast('Updated')}
function sharePost(pid){let sh=read('shares',{});sh[pid]=sh[pid]||[];if(!sh[pid].includes(uid()))sh[pid].push(uid());write('shares',sh);toast('Post shared to your profile')}
function savePost(pid){let saved=read('saved',[]);if(saved.includes(pid))saved=saved.filter(x=>x!==pid);else saved.unshift(pid);write('saved',saved);toast(saved.includes(pid)?'Post saved':'Post removed from saved')}
function deletePost(pid){let posts=read('posts',[]);let p=posts.find(x=>x.id===pid);if(!p||p.userId!==uid())return toast('Only your own post can be deleted');write('posts',posts.filter(x=>x.id!==pid));toast('Post deleted');if(window.renderFeed)renderFeed();if(window.renderProfilePosts)renderProfilePosts();renderRight()}
function commentPost(pid){let input=$('c_'+pid);if(!input||!input.value.trim())return;let posts=read('posts',[]);let p=posts.find(x=>x.id===pid);if(!p)return;p.comments=p.comments||[];p.comments.push({by:uid(),text:input.value.trim(),at:now()});write('posts',posts);if(window.renderFeed)renderFeed();if(window.renderProfilePosts)renderProfilePosts()}

function detectLanguage(text=''){const t=String(text).toLowerCase();const roman=['kya','kiya','kaise','kesay','hai','hain','ho','hoga','nhi','nahin','mujhe','tum','batao','kero','karna','chahiye','acha','theek','profile','post','chat'];const english=['what','how','why','where','when','please','create','edit','upload','theme','profile','post','chat','marketplace'];let r=roman.filter(w=>new RegExp('\\b'+w+'\\b','i').test(t)).length;let e=english.filter(w=>new RegExp('\\b'+w+'\\b','i').test(t)).length;if(/[\u0600-\u06FF]/.test(text))return 'ur';return r>e?'roman':'en'}
function siteKnowledge(lang='en'){if(lang==='en')return `SkillSwape AI is a responsive skill exchange community with Blush and Plum themes. The Community Feed supports professional text posts, image crop and aspect-ratio adjustment, visual filters, video posts stored in IndexedDB, likes, comments, repost with thoughts, share, save, scheduling and AI writing suggestions. Main pages are Home, Login, Signup, Community Feed, Profile, Marketplace, Chat, Search, Notifications, Settings, AI Assistant and Games. Games include Skill Pinpoint, Focus Grid, Career Sprint, Name the Color, Creator Quiz and Typing Speed.`;return `SkillSwape AI ek responsive skill exchange community hai jisme Blush aur Plum themes hain. Community Feed me professional text posts, image crop, aspect ratio adjustment, filters, IndexedDB video posts, likes, comments, repost with thoughts, share, save, scheduling aur AI writing suggestions hain. Main pages Home, Login, Signup, Community Feed, Profile, Marketplace, Chat, Search, Notifications, Settings, AI Assistant aur Games hain.`}
function assistantReply(message,mode='ai'){const lang=detectLanguage(message);const t=String(message||'').toLowerCase();const en=lang==='en';const has=(...words)=>words.some(w=>t.includes(w));let r;if(has('upload','image','photo','picture','dp','cover'))r=en?`Community Feed now supports image crop, ratios, visual filters and video posts. Images are compressed for LocalStorage, while videos are stored in IndexedDB for better reliability. Open Community Feed > Create Post > Photo or Video. For cover: Profile > Edit Profile > Upload Cover Photo > Save Profile.`:`Community Feed me image crop, ratios, filters aur video posting available hai. Images LocalStorage ke liye compress hoti hain aur videos IndexedDB me save hoti hain. Community Feed > Create Post > Photo ya Video use karo. Cover ke liye: Profile > Edit Profile > Upload Cover Photo > Save Profile.`;else if(has('profile','bio','skill','cover','dp'))r=en?`Go to Profile and click Edit Profile. You can update name, role, location, bio, skills, DP and cover photo. After saving, your profile links and your post avatar update across the website.`:`Profile par jao aur Edit Profile click karo. Wahan name, role, location, bio, skills, DP aur cover photo update kar sakte ho. Save ke baad profile links aur posts par avatar bhi update hota hai.`;else if(has('post','feed','daily'))r=en?`Community Feed supports professional posts, cropped and filtered images, community videos, repost with thoughts, comments, saves, shares, scheduling and AI writing help.`:`Community Feed me professional posts, crop aur filters wali images, community videos, repost with thoughts, comments, saves, shares, scheduling aur AI writing help available hai.`;else if(has('market','service','offer'))r=en?`Marketplace is for skill offers. Use it to show services like Web Development, UI/UX Design, Video Editing, SEO, Writing or any skill exchange offer. Users can message sellers from listings.`:`Marketplace skill offers ke liye hai. Yahan Web Development, UI/UX Design, Video Editing, SEO, Writing ya koi bhi skill exchange offer post kar sakte ho. Listing se direct seller ko message kar sakte ho.`;else if(has('theme','dark','light'))r=en?`Dark and Light theme works globally. You can change it from the topbar, left sidebar Game Section area, or Settings page. The choice is saved in localStorage.`:`Dark aur Light theme global work karti hai. Topbar, left sidebar ke theme area, ya Settings page se change karo. Choice localStorage me save hoti hai.`;else if(has('chat','message','reply','language','english','urdu','roman'))r=en?`Chat has smart local replies. It detects English or Roman Urdu automatically and replies in the same language. It also keeps conversations in localStorage.`:`Chat me smart local replies hain. Ye English ya Roman Urdu automatically detect karta hai aur same language me reply karta hai. Conversations localStorage me save hoti hain.`;else if(has('game','quiz','typing','color'))r=en?`The Games Hub is in the left sidebar. It includes Skill Pinpoint, Focus Grid, Career Sprint and classic games. Scores, best scores and daily streaks are saved locally.`:`Games Hub left sidebar me hai. Isme Skill Pinpoint, Focus Grid, Career Sprint aur classic games hain. Scores, best score aur daily streak locally save hote hain.`;else if(has('login','signup','account'))r=en?`The website opens Home first. Users can Login or Signup before entering the app. Demo login is jordan@skillswape.local with password 123456.`:`Website pehle Home page open karti hai. User Login ya Signup karke app ke andar jata hai. Demo login jordan@skillswape.local hai aur password 123456.`;else r=siteKnowledge(en?'en':'roman');return r}
function chatReplyFor(userObj,msg){const lang=detectLanguage(msg);const t=String(msg||'').toLowerCase();const en=lang==='en';const role=(userObj.role||'').toLowerCase();if(t.includes('hello')||t.includes('hi')||t.includes('salam')||t.includes('assalam'))return en?`Hi! How can I help you with SkillSwape today?`:`Assalam! Batao SkillSwape me kis cheez me help chahiye?`;if(role.includes('design')&&(t.includes('design')||t.includes('figma')||t.includes('ui')||t.includes('ux')))return en?`For design, focus on spacing, typography, colors and reusable components. I can help with Figma style UI ideas.`:`Design ke liye spacing, typography, colors aur reusable components par focus karo. Main Figma style UI ideas me help kar sakti hoon.`;if(role.includes('developer')&&(t.includes('code')||t.includes('website')||t.includes('bug')))return en?`For website bugs, first check console errors, then test localStorage keys, image upload size and duplicated HTML sections.`:`Website bugs ke liye pehle console errors dekho, phir localStorage keys, image upload size aur duplicate HTML sections check karo.`;if(t.includes('image')||t.includes('photo')||t.includes('cover')||t.includes('upload'))return assistantReply(msg,'chat');if(t.includes('theme')||t.includes('profile')||t.includes('post')||t.includes('game')||t.includes('market')||t.includes('chat'))return assistantReply(msg,'chat');return en?`Good point. Tell me a little more detail and I will guide you properly.`:`Acha point hai. Thori aur detail batao phir main properly guide karunga.`}


/* v8 multilingual, website-scoped assistant */
const AI_LANGUAGE_LABELS={auto:'Auto detect',en:'English',roman:'Roman Urdu',ur:'اردو',hi:'हिन्दी',ar:'العربية',es:'Español',fr:'Français',de:'Deutsch',pt:'Português',tr:'Türkçe',bn:'বাংলা',zh:'中文',ja:'日本語',ko:'한국어',ru:'Русский'};
function detectLanguageV8(text=''){
  const raw=String(text||'').trim(),t=raw.toLowerCase();
  if(/[\u3040-\u30ff]/.test(raw))return 'ja';
  if(/[\uac00-\ud7af]/.test(raw))return 'ko';
  if(/[\u4e00-\u9fff]/.test(raw))return 'zh';
  if(/[\u0980-\u09ff]/.test(raw))return 'bn';
  if(/[\u0900-\u097f]/.test(raw))return 'hi';
  if(/[\u0400-\u04ff]/.test(raw))return 'ru';
  if(/[\u0600-\u06ff]/.test(raw))return /[پچژگٹڈڑںھہک]/.test(raw)||/(کیا|کیسے|مجھے|میرا|ہے|ہیں|نہیں|پوسٹ|پروفائل)/.test(raw)?'ur':'ar';
  const groups={
    roman:['kya','kiya','kaise','kesay','hai','hain','nahi','nhi','mujhe','mera','meri','apna','batao','karo','kerna','chahiye','acha','theek'],
    es:['cómo','como','qué','dónde','puedo','cambiar','ajustes','perfil','publicación','tema','gracias','hola'],
    fr:['comment','pourquoi','profil','publication','thème','couleur','bonjour','merci','peux'],
    de:['wie','warum','ändern','profil','beitrag','farbe','hallo','danke','einstellungen'],
    pt:['como','porquê','mudar','posso','configurações','perfil','publicação','tema','cor','olá','obrigado'],
    tr:['nasıl','neden','profil','gönderi','tema','renk','merhaba','teşekkür'],
    en:['what','how','why','where','can','please','profile','post','theme','hello','thanks','settings']
  };
  let best='en',score=0;
  Object.entries(groups).forEach(([lang,words])=>{const n=words.filter(word=>t.includes(word)).length;if(n>score){score=n;best=lang}});
  return best;
}
function resolveAssistantLanguage(message,requested='auto'){
  if(requested&&requested!=='auto'&&AI_LANGUAGE_LABELS[requested])return requested;
  return detectLanguageV8(message);
}
function assistantTopic(message){
  const t=String(message||'').toLowerCase(),has=list=>list.some(word=>t.includes(word));
  if(has(['google','oauth','جوجل','گوگل','गूगल','গুগল','谷歌','グーグル','구글','гугл']))return 'google';
  if(has(['theme','color','colour','background','font','dark','light','رنگ','تھیم','پس منظر','थीम','रंग','tema','fundo','fonte','couleur','farbe','hintergrund','schrift','cor','renk','থিম','রং','ব্যাকগ্রাউন্ড','ফন্ট','主题','背景','字体','テーマ','背景','フォント','테마','색상','배경','글꼴','цвет','фон','шрифт']))return 'theme';
  if(has(['upload','image','photo','video','post','feed','repost','comment','تصویر','ویڈیو','پوسٹ','फोटो','वीडियो','पोस्ट','imagen','publicación','foto','vídeo','beitrag','gönderi','ছবি','ভিডিও','পোস্ট','帖子','照片','视频','发布','画像','写真','動画','投稿','사진','동영상','게시물','фото','видео','пост','лента']))return 'feed';
  if(has(['profile','bio','cover','skill','avatar','dp','پروفائل','بایو','प्रोफ़ाइल','perfil','profil','প্রোফাইল','দক্ষতা','个人资料','技能','头像','プロフィール','スキル','프로필','기술','профиль','навык']))return 'profile';
  if(has(['market','service','offer','listing','hire','مارکیٹ','سروس','बाज़ार','servicio','marché','markt','mercado','pazar','মার্কেট','বিনিময়','市场','交换','マーケット','交換','마켓','교환','рынок','услуг']))return 'market';
  if(has(['chat','message','inbox','reply','چیٹ','پیغام','चैट','mensaje','nachricht','mesaj','চ্যাট','বার্তা','聊天','消息','チャット','メッセージ','채팅','메시지','чат','сообщен']))return 'chat';
  if(has(['game','quiz','typing','pinpoint','focus grid','career sprint','گیم','کھیل','गेम','juego','jeu','spiel','oyun','গেম','খেলা','游戏','ゲーム','게임','игр']))return 'games';
  if(has(['group','community','story','stories','advertise','campaign','ads','گروپ','کمیونٹی','اسٹوری']))return 'overview';
  if(has(['login','signup','sign up','account','password','لاگ ان','اکاؤنٹ','लॉगिन','cuenta','compte','konto','passwort','hesap','şifre','লগইন','সাইনআপ','অ্যাকাউন্ট','পাসওয়ার্ড','登录','注册','账户','密码','ログイン','登録','アカウント','パスワード','로그인','가입','계정','비밀번호','вход','регистрац','аккаунт','пароль']))return 'auth';
  if(has(['skillswape','website','platform','site','ویب سائٹ','वेबसाइट','ওয়েবসাইট','সাইট','sitio','seite','网站','サイト','웹사이트','사이트','сайт']))return 'overview';
  if(has(['hello','hi','hey','salam','assalam','سلام','مرحبا','ہیلو','नमस्ते','হ্যালো','নমস্কার','hola','bonjour','hallo','merhaba','olá','你好','こんにちは','안녕','привет']))return 'greeting';
  return 'scope';
}
const AI_REPLIES={
  en:{
    greeting:'Hi! I can help with SkillSwape AI features, pages and settings. What would you like to do?',
    overview:'SkillSwape AI is a realtime skill-exchange network with cloud profiles, a live feed, 24-hour stories, public communities, private groups, group chat, Marketplace and sponsored campaign packages.',
    feed:'Open Home Feed and select Create Post. Add text, a photo or video and choose the public feed or one of your joined spaces. Comments, likes, stories and new posts sync across devices.',
    profile:'Open Profile and select Edit Profile. You can change your name, role, location, bio, skills, profile photo and cover image, then select Save Profile.',
    theme:'Open Settings > Appearance. Choose Ocean, Rose or Classic, switch Light or Dark mode, then set your own accent color, background color and font. Select Save appearance.',
    market:'Marketplace is for skill-exchange offers. Create a clear listing with the skill, what you offer and what you need, then members can open your profile or message you.',
    chat:'Open Live Chat, select a real member and send text, an image or a PDF. Conversations sync securely across accounts and devices in realtime.',
    games:'Open Games Hub. Skill Pinpoint tests deduction, Focus Grid tests logic, Career Sprint tests workplace decisions, and the classic games test color, creator knowledge and typing.',
    auth:'Use Signup to create a secure Supabase account. Email confirmation and password reset are supported after config.js and supabase/schema.sql are configured.',
    google:'Google login uses the Supabase Google provider. Enable Google in Supabase Authentication and add your Netlify URL to the allowed redirect URLs.',
    scope:'I am the SkillSwape AI website assistant. Ask me about Feed, Stories, Profile, Communities, Groups, Marketplace, Live Chat, Ads, Login or Games.'
  },
  roman:{
    greeting:'Assalam! Main SkillSwape AI ke features, pages aur settings mein help karta hoon. Aap kya karna chahte hain?',
    overview:'SkillSwape AI realtime skill-exchange network hai jisme cloud profiles, live feed, 24-hour stories, public communities, private groups, group chat, Marketplace aur sponsored ads hain.',
    feed:'Home Feed kholen aur Create Post select karein. Public feed ya joined community/group choose karke text, photo ya video share karein. Likes, comments, stories aur posts devices par live sync hote hain.',
    profile:'Profile kholen aur Edit Profile select karein. Name, role, location, bio, skills, profile photo aur cover image change karke Save Profile karein.',
    theme:'Settings > Appearance kholen. Ocean, Rose ya Classic preset choose karein, Light/Dark mode select karein, phir accent color, background color aur font apni marzi se set karke Save appearance karein.',
    market:'Marketplace skill offers ke liye hai. Skill, aap kya offer karte hain aur badle mein kya chahte hain clearly likhein. Members profile khol ya direct message kar sakte hain.',
    chat:'Live Chat kholen, real member select karein aur text, image ya PDF bhejein. Conversation alag accounts aur devices par realtime sync hoti hai.',
    games:'Games Hub mein Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz aur Typing game hain. Har game ka score aur streak locally save hota hai.',
    auth:'Signup se secure Supabase account banayein. config.js aur supabase/schema.sql setup ke baad email confirmation aur password reset kaam karte hain.',
    google:'Google login Supabase Google provider se hota hai. Supabase Authentication mein Google enable karke Netlify URL allowed redirects mein add karein.',
    scope:'Main SkillSwape AI website se related jawab deta hoon. Feed, Stories, Profile, Communities, Groups, Marketplace, Live Chat, Ads, Login ya Games ke bare mein poochhein.'
  },
  ur:{
    greeting:'السلام علیکم! میں SkillSwape AI کے فیچرز، صفحات اور سیٹنگز کے بارے میں مدد کر سکتا ہوں۔ آپ کیا کرنا چاہتے ہیں؟',
    overview:'SkillSwape AI ایک اسکل ایکسچینج کمیونٹی ہے۔ یہاں پروفائل بنائیں، پوسٹس شیئر کریں، مارکیٹ پلیس میں مہارتوں کا تبادلہ کریں، ممبرز سے چیٹ کریں اور گیمز کھیلیں۔',
    feed:'Community Feed کھولیں اور Create Post منتخب کریں۔ متن، تصویر یا ویڈیو شامل کریں۔ تصویر کو crop، reposition اور filter بھی کر سکتے ہیں۔ comment، save، share، schedule اور اپنے خیالات کے ساتھ repost دستیاب ہے۔',
    profile:'Profile کھول کر Edit Profile منتخب کریں۔ نام، رول، مقام، بایو، اسکلز، پروفائل تصویر اور کور تصویر تبدیل کریں، پھر Save Profile دبائیں۔',
    theme:'Settings > Appearance کھولیں۔ Ocean، Rose یا Classic منتخب کریں، Light یا Dark موڈ چنیں، پھر اپنا accent color، background color اور font سیٹ کر کے Save appearance دبائیں۔',
    market:'Marketplace مہارتوں کے تبادلے کی آفرز کے لیے ہے۔ اپنی اسکل، اپنی پیشکش اور مطلوبہ اسکل واضح لکھیں؛ ممبرز پروفائل کھول یا پیغام بھیج سکتے ہیں۔',
    chat:'Chat کھولیں، ممبر منتخب کریں اور عام متن یا تصویر بھیجیں۔ گفتگو اسی براؤزر میں محفوظ رہتی ہے اور ڈیمو جوابات مختصر اور فطری ہیں۔',
    games:'Games Hub میں Skill Pinpoint، Focus Grid، Career Sprint، Color، Creator Quiz اور Typing گیم شامل ہیں۔ اسکور اور streak مقامی طور پر محفوظ ہوتے ہیں۔',
    auth:'مقامی اکاؤنٹ کے لیے Signup استعمال کریں۔ Google signup کے لیے config.js میں Web OAuth Client ID شامل کریں۔ ڈیمو لاگ اِن jordan@skillswape.local اور پاس ورڈ 123456 ہے۔',
    google:'Google signup تیار ہے۔ config.js میں Web OAuth Client ID شامل کریں اور Google Cloud میں Live Server یا Netlify URL کو Authorized JavaScript origins میں شامل کریں۔',
    scope:'میں صرف SkillSwape AI ویب سائٹ سے متعلق سوالات کا جواب دیتا ہوں۔ Feed، Profile، Theme، Marketplace، Chat، Login، Google signup یا Games کے بارے میں پوچھیں۔'
  },
  hi:{
    greeting:'नमस्ते! मैं SkillSwape AI के फीचर्स, पेज और सेटिंग्स में मदद कर सकता हूँ। आप क्या करना चाहते हैं?',
    overview:'SkillSwape AI एक skill-exchange community है। यहाँ प्रोफ़ाइल बनाएँ, पोस्ट शेयर करें, Marketplace में skills exchange करें, members से chat करें और games खेलें।',
    feed:'Community Feed खोलें और Create Post चुनें। Text, photo या video जोड़ें। Photo को crop, reposition और filter कर सकते हैं। Comment, save, share, schedule और thoughts के साथ repost भी उपलब्ध है।',
    profile:'Profile खोलकर Edit Profile चुनें। Name, role, location, bio, skills, profile photo और cover image बदलें, फिर Save Profile दबाएँ।',
    theme:'Settings > Appearance खोलें। Ocean, Rose या Classic चुनें, Light/Dark mode सेट करें और अपना accent color, background color व font चुनकर Save appearance दबाएँ।',
    market:'Marketplace skill-exchange offers के लिए है। अपनी skill, offer और बदले में ज़रूरत स्पष्ट लिखें; members profile खोल या message कर सकते हैं।',
    chat:'Chat खोलें, member चुनें और सामान्य text या image message भेजें। Conversations इसी browser में save होती हैं और demo replies छोटे व natural हैं।',
    games:'Games Hub में Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz और Typing games हैं। Scores और streak local रूप से save होते हैं।',
    auth:'Local account के लिए Signup करें। Google signup के लिए config.js में Web OAuth Client ID जोड़ें। Demo login jordan@skillswape.local और password 123456 है।',
    google:'Google signup तैयार है। config.js में Web OAuth Client ID जोड़ें और Google Cloud में Live Server या Netlify URL को Authorized JavaScript origins में add करें।',
    scope:'मैं केवल SkillSwape AI वेबसाइट से जुड़े सवालों का जवाब देता हूँ। Feed, Profile, Theme, Marketplace, Chat, Login, Google signup या Games के बारे में पूछें।'
  },
  ar:{
    greeting:'مرحباً! أستطيع مساعدتك في ميزات وصفحات وإعدادات SkillSwape AI. ماذا تريد أن تفعل؟',
    overview:'SkillSwape AI مجتمع لتبادل المهارات. يمكنك إنشاء ملف شخصي ونشر المحتوى وتبادل الخدمات في Marketplace والدردشة ولعب ألعاب المهارات.',
    feed:'افتح Community Feed ثم Create Post. أضف نصاً أو صورة أو فيديو، ويمكنك قص الصورة وتحريكها وتطبيق الفلاتر. يتوفر التعليق والحفظ والمشاركة والجدولة وإعادة النشر مع رأيك.',
    profile:'افتح Profile ثم Edit Profile. عدّل الاسم والدور والموقع والنبذة والمهارات وصورة الملف والغلاف ثم اضغط Save Profile.',
    theme:'افتح Settings > Appearance. اختر Ocean أو Rose أو Classic وحدد الوضع الفاتح أو الداكن ثم خصص لون التمييز والخلفية والخط واضغط Save appearance.',
    market:'Marketplace مخصص لعروض تبادل المهارات. اكتب مهارتك وما تقدمه وما تحتاجه بوضوح، ويمكن للأعضاء فتح ملفك أو مراسلتك.',
    chat:'افتح Chat واختر عضواً ثم أرسل رسالة نصية أو صورة. تُحفظ المحادثات في هذا المتصفح، وردود العرض قصيرة وطبيعية.',
    games:'يضم Games Hub ألعاب Skill Pinpoint وFocus Grid وCareer Sprint وألعاب الألوان والاختبار والكتابة. تُحفظ النتائج والسلسلة محلياً.',
    auth:'استخدم Signup لحساب محلي. لتسجيل Google أضف Web OAuth Client ID في config.js. حساب العرض هو jordan@skillswape.local وكلمة المرور 123456.',
    google:'تسجيل Google جاهز. أضف Web OAuth Client ID في config.js وأضف رابط Live Server أو Netlify إلى Authorized JavaScript origins في Google Cloud.',
    scope:'أنا مساعد موقع SkillSwape AI وأجيب عن هذا الموقع فقط. اسأل عن Feed أو Profile أو Theme أو Marketplace أو Chat أو Login أو Google signup أو Games.'
  },
  es:{
    greeting:'¡Hola! Puedo ayudarte con las funciones, páginas y ajustes de SkillSwape AI. ¿Qué quieres hacer?',
    overview:'SkillSwape AI es una comunidad de intercambio de habilidades. Puedes crear un perfil, publicar, intercambiar servicios, chatear y jugar.',
    feed:'Abre Community Feed y pulsa Create Post. Añade texto, foto o vídeo; también puedes recortar, mover y filtrar la foto. Hay comentarios, guardado, compartir, programación y repost con opinión.',
    profile:'Abre Profile > Edit Profile. Cambia nombre, rol, ubicación, biografía, habilidades, foto y portada; después pulsa Save Profile.',
    theme:'Abre Settings > Appearance. Elige Ocean, Rose o Classic, modo Light/Dark, color de acento, fondo y tipografía; después pulsa Save appearance.',
    market:'Marketplace sirve para ofertas de intercambio de habilidades. Explica qué ofreces y qué necesitas; otros miembros pueden abrir tu perfil o enviarte un mensaje.',
    chat:'Abre Chat, elige un miembro y envía texto o imagen. Las conversaciones se guardan en este navegador y las respuestas de demostración son breves y naturales.',
    games:'Games Hub incluye Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz y Typing. Las puntuaciones y rachas se guardan localmente.',
    auth:'Usa Signup para una cuenta local. Para Google añade un Web OAuth Client ID en config.js. Demo: jordan@skillswape.local / 123456.',
    google:'Google signup está listo. Añade el Web OAuth Client ID en config.js y el origen de Live Server o Netlify en Authorized JavaScript origins de Google Cloud.',
    scope:'Soy el asistente del sitio SkillSwape AI y solo respondo sobre esta web. Pregunta por Feed, Profile, Theme, Marketplace, Chat, Login, Google signup o Games.'
  },
  fr:{
    greeting:'Bonjour ! Je peux vous aider avec les fonctions, pages et réglages de SkillSwape AI. Que voulez-vous faire ?',
    overview:'SkillSwape AI est une communauté d’échange de compétences. Créez un profil, publiez, échangez des services, discutez et jouez.',
    feed:'Ouvrez Community Feed puis Create Post. Ajoutez du texte, une photo ou une vidéo. Vous pouvez recadrer, déplacer et filtrer la photo, puis commenter, enregistrer, partager, planifier ou republier avec votre avis.',
    profile:'Ouvrez Profile > Edit Profile. Modifiez le nom, le rôle, le lieu, la bio, les compétences, la photo et la couverture, puis choisissez Save Profile.',
    theme:'Ouvrez Settings > Appearance. Choisissez Ocean, Rose ou Classic, le mode Light/Dark, la couleur d’accent, le fond et la police, puis Save appearance.',
    market:'Marketplace sert aux offres d’échange de compétences. Décrivez ce que vous proposez et recherchez ; les membres peuvent ouvrir votre profil ou vous écrire.',
    chat:'Ouvrez Chat, choisissez un membre et envoyez un texte ou une image. Les conversations restent dans ce navigateur et les réponses de démonstration sont courtes et naturelles.',
    games:'Games Hub contient Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz et Typing. Les scores et séries sont enregistrés localement.',
    auth:'Utilisez Signup pour un compte local. Pour Google, ajoutez un Web OAuth Client ID dans config.js. Démo : jordan@skillswape.local / 123456.',
    google:'Google signup est prêt. Ajoutez le Web OAuth Client ID dans config.js et votre origine Live Server ou Netlify dans Authorized JavaScript origins de Google Cloud.',
    scope:'Je suis l’assistant du site SkillSwape AI et je réponds uniquement sur ce site. Demandez Feed, Profile, Theme, Marketplace, Chat, Login, Google signup ou Games.'
  }
};
AI_REPLIES.de={
  greeting:'Hallo! Ich helfe dir bei Funktionen, Seiten und Einstellungen von SkillSwape AI. Was möchtest du tun?',
  overview:'SkillSwape AI ist eine Community zum Austausch von Fähigkeiten. Du kannst ein Profil erstellen, Beiträge veröffentlichen, Angebote tauschen, chatten und Lernspiele spielen.',
  feed:'Öffne Community Feed und wähle Create Post. Füge Text, Foto oder Video hinzu; Fotos lassen sich zuschneiden, verschieben und filtern. Kommentare, Speichern, Teilen, Planen und Reposts sind verfügbar.',
  profile:'Öffne Profile > Edit Profile. Ändere Name, Rolle, Ort, Bio, Fähigkeiten, Profil- und Titelbild und wähle Save Profile.',
  theme:'Öffne Settings > Appearance. Wähle Ocean, Rose oder Classic, Light/Dark sowie Akzentfarbe, Hintergrund und Schrift und speichere mit Save appearance.',
  market:'Marketplace ist für den Austausch von Fähigkeiten. Beschreibe klar, was du anbietest und suchst; Mitglieder können dein Profil öffnen oder dir schreiben.',
  chat:'Öffne Chat, wähle ein Mitglied und sende Text oder ein Bild. Gespräche werden in diesem Browser gespeichert und Demo-Antworten sind kurz und natürlich.',
  games:'Games Hub enthält Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz und Typing. Punkte und Serien werden lokal gespeichert.',
  auth:'Erstelle über Signup ein lokales Konto. Für Google trägst du die Web OAuth Client ID in config.js ein. Demo: jordan@skillswape.local / 123456.',
  google:'Google-Anmeldung ist vorbereitet. Trage die Web OAuth Client ID in config.js ein und füge deine Live-Server- oder Netlify-Adresse in Google Cloud als Authorized JavaScript origin hinzu.',
  scope:'Ich bin der Assistent der SkillSwape-AI-Website und beantworte nur Fragen zu dieser Website. Frage nach Feed, Profile, Theme, Marketplace, Chat, Login, Google signup oder Games.'
};
AI_REPLIES.pt={
  greeting:'Olá! Posso ajudar com as funções, páginas e configurações do SkillSwape AI. O que você quer fazer?',
  overview:'SkillSwape AI é uma comunidade de troca de habilidades. Você pode criar um perfil, publicar, trocar serviços, conversar e jogar.',
  feed:'Abra Community Feed e selecione Create Post. Adicione texto, foto ou vídeo; também é possível recortar, mover e filtrar a foto. Há comentários, salvar, compartilhar, agendar e repostar.',
  profile:'Abra Profile > Edit Profile. Altere nome, função, localização, bio, habilidades, foto e capa e depois selecione Save Profile.',
  theme:'Abra Settings > Appearance. Escolha Ocean, Rose ou Classic, modo Light/Dark, cor de destaque, fundo e fonte; depois selecione Save appearance.',
  market:'Marketplace é para ofertas de troca de habilidades. Explique o que oferece e procura; outros membros podem abrir seu perfil ou enviar uma mensagem.',
  chat:'Abra Chat, escolha um membro e envie texto ou imagem. As conversas ficam salvas neste navegador e as respostas de demonstração são curtas e naturais.',
  games:'Games Hub inclui Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz e Typing. Pontuações e sequências são salvas localmente.',
  auth:'Use Signup para uma conta local. Para Google, adicione uma Web OAuth Client ID em config.js. Demo: jordan@skillswape.local / 123456.',
  google:'O login do Google está preparado. Adicione a Web OAuth Client ID em config.js e a origem do Live Server ou Netlify em Authorized JavaScript origins no Google Cloud.',
  scope:'Sou o assistente do site SkillSwape AI e respondo apenas sobre este site. Pergunte sobre Feed, Profile, Theme, Marketplace, Chat, Login, Google signup ou Games.'
};
AI_REPLIES.tr={
  greeting:'Merhaba! SkillSwape AI özellikleri, sayfaları ve ayarları konusunda yardımcı olabilirim. Ne yapmak istiyorsunuz?',
  overview:'SkillSwape AI bir beceri paylaşım topluluğudur. Profil oluşturabilir, gönderi paylaşabilir, hizmet takası yapabilir, sohbet edebilir ve oyun oynayabilirsiniz.',
  feed:'Community Feed sayfasını açıp Create Post seçeneğine basın. Metin, fotoğraf veya video ekleyebilir; fotoğrafı kırpabilir, taşıyabilir ve filtreleyebilirsiniz. Yorum, kaydetme, paylaşma, zamanlama ve yeniden paylaşma desteklenir.',
  profile:'Profile > Edit Profile bölümünü açın. Ad, rol, konum, biyografi, beceriler, profil ve kapak fotoğrafını değiştirip Save Profile seçeneğine basın.',
  theme:'Settings > Appearance bölümünü açın. Ocean, Rose veya Classic; Light/Dark modu, vurgu rengi, arka plan ve yazı tipini seçip Save appearance seçeneğine basın.',
  market:'Marketplace beceri takası teklifleri içindir. Ne sunduğunuzu ve ne aradığınızı açıkça yazın; üyeler profilinizi açabilir veya size mesaj gönderebilir.',
  chat:'Chat sayfasını açın, bir üye seçin ve metin ya da görsel gönderin. Konuşmalar bu tarayıcıda saklanır ve demo yanıtları kısa ve doğaldır.',
  games:'Games Hub içinde Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz ve Typing bulunur. Puanlar ve seriler yerel olarak saklanır.',
  auth:'Yerel hesap için Signup kullanın. Google için config.js dosyasına Web OAuth Client ID ekleyin. Demo: jordan@skillswape.local / 123456.',
  google:'Google girişi hazırdır. Web OAuth Client ID değerini config.js dosyasına ekleyin ve Live Server veya Netlify adresinizi Google Cloud Authorized JavaScript origins listesine ekleyin.',
  scope:'Ben SkillSwape AI web sitesi asistanıyım ve yalnızca bu siteyle ilgili soruları yanıtlarım. Feed, Profile, Theme, Marketplace, Chat, Login, Google signup veya Games hakkında sorun.'
};
AI_REPLIES.bn={
  greeting:'হ্যালো! SkillSwape AI-এর ফিচার, পেজ ও সেটিংস নিয়ে আমি সাহায্য করতে পারি। আপনি কী করতে চান?',
  overview:'SkillSwape AI একটি দক্ষতা বিনিময় কমিউনিটি। এখানে প্রোফাইল তৈরি, পোস্ট, সেবা বিনিময়, চ্যাট ও শেখার গেম খেলা যায়।',
  feed:'Community Feed খুলে Create Post চাপুন। লেখা, ছবি বা ভিডিও যোগ করা যায়; ছবি ক্রপ, সরানো ও ফিল্টারও করা যায়। কমেন্ট, সেভ, শেয়ার, শিডিউল ও রিপোস্ট সুবিধা আছে।',
  profile:'Profile > Edit Profile খুলুন। নাম, ভূমিকা, অবস্থান, বায়ো, দক্ষতা, প্রোফাইল ছবি ও কভার বদলে Save Profile চাপুন।',
  theme:'Settings > Appearance খুলুন। Ocean, Rose বা Classic, Light/Dark মোড, অ্যাকসেন্ট রং, ব্যাকগ্রাউন্ড ও ফন্ট বেছে Save appearance চাপুন।',
  market:'Marketplace দক্ষতা বিনিময়ের অফারের জন্য। আপনি কী দেন ও কী চান তা পরিষ্কার লিখুন; সদস্যরা আপনার প্রোফাইল খুলতে বা মেসেজ করতে পারবেন।',
  chat:'Chat খুলে একজন সদস্য বেছে লেখা বা ছবি পাঠান। কথোপকথন এই ব্রাউজারে সেভ হয় এবং ডেমো উত্তর ছোট ও স্বাভাবিক।',
  games:'Games Hub-এ Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz ও Typing আছে। স্কোর ও স্ট্রিক লোকালি সেভ হয়।',
  auth:'লোকাল অ্যাকাউন্টের জন্য Signup ব্যবহার করুন। Google-এর জন্য config.js-এ Web OAuth Client ID দিন। ডেমো: jordan@skillswape.local / 123456।',
  google:'Google লগইন প্রস্তুত। config.js-এ Web OAuth Client ID দিন এবং Google Cloud-এর Authorized JavaScript origins-এ Live Server বা Netlify ঠিকানা যোগ করুন।',
  scope:'আমি SkillSwape AI ওয়েবসাইট সহকারী এবং শুধু এই সাইটের প্রশ্নের উত্তর দিই। Feed, Profile, Theme, Marketplace, Chat, Login, Google signup বা Games সম্পর্কে জিজ্ঞেস করুন।'
};
AI_REPLIES.zh={
  greeting:'你好！我可以帮助你使用 SkillSwape AI 的功能、页面和设置。你想做什么？',
  overview:'SkillSwape AI 是一个技能交换社区。你可以创建个人资料、发布内容、交换服务、聊天并玩学习游戏。',
  feed:'打开 Community Feed，然后选择 Create Post。你可以添加文字、照片或视频，也可以裁剪、移动和筛选照片。支持评论、保存、分享、定时发布和转发。',
  profile:'打开 Profile > Edit Profile。修改姓名、角色、位置、简介、技能、头像和封面，然后选择 Save Profile。',
  theme:'打开 Settings > Appearance。选择 Ocean、Rose 或 Classic，设置 Light/Dark 模式、强调色、背景和字体，然后选择 Save appearance。',
  market:'Marketplace 用于技能交换。请清楚说明你能提供什么和需要什么，其他成员可以查看你的资料或给你发消息。',
  chat:'打开 Chat，选择一位成员并发送文字或图片。对话保存在当前浏览器中，演示回复简短自然。',
  games:'Games Hub 包含 Skill Pinpoint、Focus Grid、Career Sprint、Color、Creator Quiz 和 Typing。分数和连续记录保存在本地。',
  auth:'使用 Signup 创建本地账户。如需 Google 登录，请在 config.js 中添加 Web OAuth Client ID。演示账户：jordan@skillswape.local / 123456。',
  google:'Google 登录已准备好。请在 config.js 中添加 Web OAuth Client ID，并在 Google Cloud 的 Authorized JavaScript origins 中加入 Live Server 或 Netlify 地址。',
  scope:'我是 SkillSwape AI 网站助手，只回答与此网站有关的问题。你可以询问 Feed、Profile、Theme、Marketplace、Chat、Login、Google signup 或 Games。'
};
AI_REPLIES.ja={
  greeting:'こんにちは！SkillSwape AI の機能、ページ、設定について案内できます。何をしたいですか？',
  overview:'SkillSwape AI はスキル交換コミュニティです。プロフィール作成、投稿、サービス交換、チャット、学習ゲームが利用できます。',
  feed:'Community Feed を開き、Create Post を選びます。文章、写真、動画を追加でき、写真の切り抜き、移動、フィルターも可能です。コメント、保存、共有、予約投稿、再投稿に対応しています。',
  profile:'Profile > Edit Profile を開きます。名前、役割、場所、自己紹介、スキル、プロフィール写真、カバーを変更し、Save Profile を選びます。',
  theme:'Settings > Appearance を開きます。Ocean、Rose、Classic、Light/Dark、アクセント色、背景、フォントを選び、Save appearance を押します。',
  market:'Marketplace はスキル交換の提案用です。提供できることと必要なことを明確に書くと、メンバーがプロフィールを開いたりメッセージを送ったりできます。',
  chat:'Chat を開き、メンバーを選んで文章または画像を送ります。会話はこのブラウザに保存され、デモ返信は短く自然です。',
  games:'Games Hub には Skill Pinpoint、Focus Grid、Career Sprint、Color、Creator Quiz、Typing があります。スコアと連続記録は端末内に保存されます。',
  auth:'ローカルアカウントは Signup から作成します。Google を使う場合は config.js に Web OAuth Client ID を追加します。デモ：jordan@skillswape.local / 123456。',
  google:'Google ログインは実装済みです。config.js に Web OAuth Client ID を追加し、Google Cloud の Authorized JavaScript origins に Live Server または Netlify のアドレスを登録してください。',
  scope:'私は SkillSwape AI 専用のサイトアシスタントです。このサイト以外の質問には回答しません。Feed、Profile、Theme、Marketplace、Chat、Login、Google signup、Games について聞いてください。'
};
AI_REPLIES.ko={
  greeting:'안녕하세요! SkillSwape AI의 기능, 페이지와 설정을 안내해 드릴 수 있습니다. 무엇을 하시겠어요?',
  overview:'SkillSwape AI는 기술 교환 커뮤니티입니다. 프로필을 만들고, 게시물을 올리고, 서비스를 교환하고, 채팅과 학습 게임을 이용할 수 있습니다.',
  feed:'Community Feed를 열고 Create Post를 선택하세요. 글, 사진 또는 동영상을 추가할 수 있으며 사진 자르기, 이동, 필터도 가능합니다. 댓글, 저장, 공유, 예약 게시와 재게시를 지원합니다.',
  profile:'Profile > Edit Profile을 여세요. 이름, 역할, 위치, 소개, 기술, 프로필 사진과 커버를 바꾼 뒤 Save Profile을 선택하세요.',
  theme:'Settings > Appearance를 여세요. Ocean, Rose 또는 Classic, Light/Dark 모드, 강조 색상, 배경과 글꼴을 고른 뒤 Save appearance를 선택하세요.',
  market:'Marketplace는 기술 교환 제안을 위한 공간입니다. 제공할 것과 필요한 것을 분명히 적으면 회원이 프로필을 열거나 메시지를 보낼 수 있습니다.',
  chat:'Chat을 열고 회원을 선택한 뒤 글이나 이미지를 보내세요. 대화는 이 브라우저에 저장되며 데모 답변은 짧고 자연스럽습니다.',
  games:'Games Hub에는 Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz와 Typing이 있습니다. 점수와 연속 기록은 로컬에 저장됩니다.',
  auth:'로컬 계정은 Signup에서 만드세요. Google을 사용하려면 config.js에 Web OAuth Client ID를 추가하세요. 데모: jordan@skillswape.local / 123456.',
  google:'Google 로그인 기능은 준비되어 있습니다. config.js에 Web OAuth Client ID를 넣고 Google Cloud의 Authorized JavaScript origins에 Live Server 또는 Netlify 주소를 추가하세요.',
  scope:'저는 SkillSwape AI 웹사이트 전용 도우미이며 이 사이트에 관한 질문만 답합니다. Feed, Profile, Theme, Marketplace, Chat, Login, Google signup 또는 Games를 물어보세요.'
};
AI_REPLIES.ru={
  greeting:'Здравствуйте! Я помогу с функциями, страницами и настройками SkillSwape AI. Что вы хотите сделать?',
  overview:'SkillSwape AI — сообщество для обмена навыками. Здесь можно создать профиль, публиковать записи, обмениваться услугами, общаться и играть в обучающие игры.',
  feed:'Откройте Community Feed и нажмите Create Post. Добавьте текст, фото или видео; фото можно обрезать, перемещать и фильтровать. Доступны комментарии, сохранение, публикация, расписание и репост.',
  profile:'Откройте Profile > Edit Profile. Измените имя, роль, местоположение, описание, навыки, фото и обложку, затем нажмите Save Profile.',
  theme:'Откройте Settings > Appearance. Выберите Ocean, Rose или Classic, режим Light/Dark, акцентный цвет, фон и шрифт, затем нажмите Save appearance.',
  market:'Marketplace предназначен для обмена навыками. Чётко опишите, что вы предлагаете и что ищете; участники смогут открыть ваш профиль или написать вам.',
  chat:'Откройте Chat, выберите участника и отправьте текст или изображение. Диалоги сохраняются в этом браузере, а демонстрационные ответы короткие и естественные.',
  games:'Games Hub включает Skill Pinpoint, Focus Grid, Career Sprint, Color, Creator Quiz и Typing. Очки и серии сохраняются локально.',
  auth:'Создайте локальную учётную запись через Signup. Для Google добавьте Web OAuth Client ID в config.js. Демо: jordan@skillswape.local / 123456.',
  google:'Вход через Google подготовлен. Добавьте Web OAuth Client ID в config.js, а адрес Live Server или Netlify — в Authorized JavaScript origins в Google Cloud.',
  scope:'Я помощник сайта SkillSwape AI и отвечаю только на вопросы об этом сайте. Спросите про Feed, Profile, Theme, Marketplace, Chat, Login, Google signup или Games.'
};
function siteKnowledgeV8(lang='en'){const set=AI_REPLIES[lang]||AI_REPLIES.en;return set.overview}
function assistantReplyV8(message,mode='ai',requestedLanguage='auto'){
  const lang=resolveAssistantLanguage(message,requestedLanguage),set=AI_REPLIES[lang]||AI_REPLIES.en,topic=assistantTopic(message);
  return set[topic]||set.scope;
}
async function assistantReplyAsync(message,mode='ai',requestedLanguage='auto'){
  const endpoint=String((window.SKILLSWAPE_CONFIG||{}).aiEndpoint||'').trim();
  if(endpoint){
    try{
      const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message,language:resolveAssistantLanguage(message,requestedLanguage),context:'SkillSwape AI website support only'})});
      const data=await response.json();if(response.ok&&data&&data.reply)return String(data.reply);
    }catch(_){}
  }
  return assistantReplyV8(message,mode,requestedLanguage);
}
function chatReplyForV8(userObj,msg){
  const lang=detectLanguageV8(msg),t=String(msg||'').toLowerCase(),role=String(userObj.role||'').toLowerCase(),roman=lang==='roman',urdu=lang==='ur';
  if(/hello|hi|hey|salam|assalam/.test(t)||/سلام/.test(msg))return urdu?'وعلیکم السلام! آپ سے رابطہ کر کے اچھا لگا۔':roman?'Walaikum assalam! Aap se connect karke acha laga.':'Hi! Nice to connect with you.';
  if(/thank|thanks|shukriya/.test(t)||/شکریہ/.test(msg))return urdu?'خوشی ہوئی!':roman?'Koi baat nahi, khushi hui.':'You are welcome!';
  if(/available|collaborat|exchange|help|project|کام|مدد/.test(t)){
    if(urdu)return 'جی، تفصیل اور مطلوبہ وقت بھیج دیں، پھر ہم اگلا قدم طے کر لیتے ہیں۔';
    if(roman)return 'Ji, project ki detail aur timeline bhej dein, phir next step decide kar lete hain.';
    return 'Sure. Send me the project details and timeline, and we can decide the next step.';
  }
  if(role.includes('design'))return roman?'Theek hai. Screen aur required style share kar dein, main dekh leti hoon.':'Sounds good. Share the screen and preferred style, and I will take a look.';
  if(role.includes('developer'))return roman?'Theek hai. Feature aur expected result share kar dein, main review kar leta hoon.':'Sounds good. Share the feature and expected result, and I will review it.';
  if(role.includes('marketing'))return roman?'Goal aur target audience share kar dein, phir idea discuss karte hain.':'Share the goal and target audience, and we can discuss the approach.';
  if(role.includes('video'))return roman?'Video length, style aur deadline share kar dein.':'Please share the video length, style and deadline.';
  return roman?'Samajh gaya. Thori detail aur deadline share kar dein.':'Got it. Please share a little more detail and the deadline.';
}
detectLanguage=detectLanguageV8;
siteKnowledge=siteKnowledgeV8;
assistantReply=assistantReplyV8;
chatReplyFor=chatReplyForV8;

/* v5 daily games statistics */
function localDateKey(date=new Date()){
  return date.getFullYear()+'-'+String(date.getMonth()+1).padStart(2,'0')+'-'+String(date.getDate()).padStart(2,'0');
}
function getGameStats(){
  return read('gameStats',{plays:0,best:{},days:{},lastPlayed:''});
}
function recordGamePlay(game,score=0){
  const stats=getGameStats();
  const today=localDateKey();
  stats.plays=(stats.plays||0)+1;
  stats.days=stats.days||{};
  stats.days[today]=true;
  stats.best=stats.best||{};
  stats.best[game]=Math.max(Number(stats.best[game]||0),Number(score||0));
  stats.lastPlayed=now();
  write('gameStats',stats);
  return stats;
}
function currentGameStreak(){
  const stats=getGameStats();
  const days=stats.days||{};
  let streak=0;
  const d=new Date();
  while(true){
    const key=localDateKey(d);
    if(!days[key])break;
    streak++;
    d.setDate(d.getDate()-1);
  }
  return streak;
}

/* Load the shared realtime layer on legacy pages (games, settings, assistant). */
(function loadSkillSwapeRealtimeLayer(){
  if(document.head&&!document.querySelector('link[href="live.css"]')){
    const link=document.createElement('link');link.rel='stylesheet';link.href='live.css';document.head.appendChild(link);
  }
  if(!window.SKILLSWAPE_CONFIG)document.write('<script src="config.js"><\/script>');
  if(!window.supabase)document.write('<script src="vendor/supabase.js"><\/script>');
  if(!window.SkillCloud)document.write('<script src="live-core.js"><\/script>');
})();
