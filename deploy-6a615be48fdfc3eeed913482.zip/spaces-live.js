(function () {
  'use strict';
  const type = document.body.dataset.spaceType || 'community';
  let spaces = [];

  function cover(space) { return space.cover_url ? '<img src="' + esc(space.cover_url) + '" alt="">' : ''; }

  async function initSpaces() {
    if (!SkillCloud.configured) { $('spacesLiveGrid').innerHTML = '<div class="cloud-state"><h2>Live setup required</h2><p>' + esc(SkillCloud.setupMessage()) + '</p><a class="btn" href="setup.html">Setup guide</a></div>'; return; }
    try {
      await SkillCloud.requireUser(); spaces = await SkillCloud.listSpaces(type); renderSpacesLive();
      if (new URLSearchParams(location.search).get('create') === '1') openSpaceCreator();
    } catch (error) { $('spacesLiveGrid').innerHTML = '<div class="cloud-state"><h2>Spaces could not load</h2><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>'; }
  }

  window.renderSpacesLive = function () {
    const query = String($('spaceSearchLive').value || '').trim().toLowerCase(); const category = $('spaceCategoryFilter').value;
    const filtered = spaces.filter(function (space) { return (category === 'All' || space.category === category) && [space.name,space.description,space.category].join(' ').toLowerCase().includes(query); });
    $('spacesLiveGrid').innerHTML = filtered.map(function (space) {
      const action = space.is_member ? '<a class="btn" href="space.html?id=' + encodeURIComponent(space.id) + '">Open</a>' : space.privacy === 'private' ? '<button class="btn" onclick="requestSpaceLive(\'' + space.id + '\')">Request access</button>' : '<button class="btn" onclick="joinSpaceLive(\'' + space.id + '\')">Join</button>';
      return '<article class="space-card-live"><div class="space-card-cover">' + cover(space) + '</div><div class="space-card-body"><span class="space-type-label" style="color:var(--accent)">' + esc(space.privacy) + ' ' + esc(space.space_type) + '</span><h3>' + esc(space.name) + '</h3><p>' + esc(space.description || 'A SkillSwape collaboration space.') + '</p><div class="space-card-meta"><span>' + space.member_count + ' members</span><span>' + space.post_count + ' posts</span><span>' + esc(space.category) + '</span></div><div class="space-card-actions">' + action + '<a class="btn secondary" href="space.html?id=' + encodeURIComponent(space.id) + '">Details</a></div></div></article>';
    }).join('') || '<div class="cloud-state"><div class="state-icon">+</div><h2>No ' + esc(type) + ' found</h2><p>Create the first one and invite people to collaborate.</p><button class="btn" onclick="openSpaceCreator()">Create ' + esc(type) + '</button></div>';
  };

  window.openSpaceCreator = function () { $('spaceCreatorModal').classList.add('open'); setTimeout(function () { $('spaceNameLive').focus(); }, 20); };
  window.closeSpaceCreator = function () { $('spaceCreatorModal').classList.remove('open'); };
  window.createSpaceLive = async function () {
    const name = $('spaceNameLive').value.trim(), description = $('spaceDescriptionLive').value.trim();
    if (name.length < 3 || !description) return toast('Name aur description required hain.');
    const button = $('spaceCreateButton'); button.disabled = true; button.textContent = 'Creating...';
    try {
      const id = await SkillCloud.createSpace({ name: name, description: description, space_type: type, privacy: type === 'community' ? 'public' : $('spacePrivacyLive').value, category: $('spaceCategoryLive').value }, $('spaceCoverLive').files[0]);
      toast((type === 'group' ? 'Group' : 'Community') + ' created'); location.href = 'space.html?id=' + encodeURIComponent(id);
    } catch (error) { $('spaceCreateStatus').textContent = SkillCloud.cleanError(error); toast(SkillCloud.cleanError(error)); }
    finally { button.disabled = false; button.textContent = 'Create ' + type; }
  };
  window.joinSpaceLive = async function (id) { try { await SkillCloud.joinSpace(id); toast('Joined successfully'); spaces = await SkillCloud.listSpaces(type); renderSpacesLive(); } catch (error) { toast(SkillCloud.cleanError(error)); } };
  window.requestSpaceLive = async function (id) { try { await SkillCloud.requestSpace(id); toast('Access request sent to group admin'); } catch (error) { toast(SkillCloud.cleanError(error)); } };
  initSpaces();
})();
