SKILLSWAPE AI — REALTIME NETLIFY EDITION

Start with README.md or open setup.html.

Required before live use:
1. Create a Supabase project.
2. Run supabase/schema.sql.
3. Run supabase/migrations/20260723_friendships_privacy.sql.
4. Run supabase/migrations/20260723_story_upload_repair.sql.
5. Run supabase/migrations/20260723_chat_attachments_50mb.sql.
6. config.js is already connected for this build; only change it when moving to another Supabase project.
7. Deploy this folder to Netlify (no build command; publish directory is .).

Included: real accounts, cross-device realtime chat, communities, public/private
groups, membership approval, group chat, 24-hour stories, cloud profiles/feed,
friend requests, private accounts, marketplace, PKR 1,000–10,000 ad packages,
campaign analytics and admin approval.

Chat: click + to send a private photo, video or document. The app accepts up to
50MB and uses resumable upload progress.

Never paste a service_role key or database password into config.js.
