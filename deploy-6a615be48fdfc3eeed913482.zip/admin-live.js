(function () {
  'use strict';
  let campaigns = [];
  function money(value) { return 'PKR ' + Number(value || 0).toLocaleString('en-PK'); }

  async function initAdmin() {
    if (!SkillCloud.configured) { $('adminRootLive').innerHTML = '<div class="cloud-state"><h2>Live setup required</h2><p>' + esc(SkillCloud.setupMessage()) + '</p></div>'; return; }
    try {
      await SkillCloud.requireUser(); await SkillCloud.ready();
      const role = SkillCloud.state.profile && SkillCloud.state.profile.account_role;
      if (!['admin','moderator'].includes(role)) { $('adminRootLive').innerHTML = '<div class="cloud-state"><div class="state-icon">!</div><h2>Admin access required</h2><p>This account cannot review campaigns. Promote the owner account using the command at the bottom of supabase/schema.sql.</p><a class="btn" href="daily-feed.html">Back to feed</a></div>'; return; }
      await loadAdminPanel();
    } catch (error) { $('adminRootLive').innerHTML = '<div class="cloud-state"><h2>Admin panel unavailable</h2><p>' + esc(SkillCloud.cleanError(error)) + '</p></div>'; }
  }

  window.loadAdminPanel = async function () {
    const stats = await SkillCloud.sidebarStats(); campaigns = await SkillCloud.pendingCampaigns();
    const pending = campaigns.filter(function (c) { return c.status === 'pending'; }).length;
    $('adminRootLive').innerHTML = '<div class="admin-grid-live"><div class="admin-stat-card"><span>MEMBERS</span><b>' + stats.members + '</b></div><div class="admin-stat-card"><span>COMMUNITY POSTS</span><b>' + stats.posts + '</b></div><div class="admin-stat-card"><span>PENDING ADS</span><b>' + pending + '</b></div></div><section><h2>Campaign review queue</h2><p class="muted">Verify the payment reference, creative quality and destination URL before activation.</p><div id="adminCampaignList">' + renderCampaigns() + '</div></section>';
  };

  function renderCampaigns() {
    return campaigns.map(function (campaign) {
      const url = campaign.target_url && /^https?:\/\//i.test(campaign.target_url) ? '<a href="' + esc(campaign.target_url) + '" target="_blank" rel="noopener">Open destination</a>' : '<span class="muted">No URL</span>';
      const paymentRef = campaign.payment && (Array.isArray(campaign.payment) ? campaign.payment[0] && campaign.payment[0].payment_reference : campaign.payment.payment_reference);
      return '<article class="admin-review-card"><img src="' + esc(campaign.creative_url) + '" alt=""><div><span class="status-chip ' + esc(campaign.status) + '">' + esc(campaign.status) + '</span><h3 style="margin:8px 0 5px">' + esc(campaign.title) + '</h3><p class="muted" style="margin:0 0 7px">' + esc(campaign.caption) + '</p><small>' + esc(campaign.owner && campaign.owner.full_name || 'Advertiser') + ' · ' + esc(campaign.package && campaign.package.name || '') + ' · ' + money(campaign.package && campaign.package.price_pkr) + ' · Ref: ' + esc(paymentRef || 'Not supplied') + '</small><div style="margin-top:7px">' + url + '</div></div><div class="admin-review-actions">' + (campaign.status !== 'active' ? '<button class="btn" onclick="adminReviewCampaign(\'' + campaign.id + '\',\'active\')">Approve</button>' : '<button class="btn secondary" onclick="adminReviewCampaign(\'' + campaign.id + '\',\'paused\')">Pause</button>') + '<button class="btn secondary" onclick="adminReviewCampaign(\'' + campaign.id + '\',\'rejected\')">Reject</button><button class="btn secondary" onclick="adminReviewCampaign(\'' + campaign.id + '\',\'ended\')">End</button></div></article>';
    }).join('') || '<div class="cloud-state"><h2>Review queue is clear</h2><p>No pending or active campaigns need attention.</p></div>';
  }

  window.adminReviewCampaign = async function (id, status) {
    const note = status === 'rejected' ? prompt('Reason for rejection (shown to advertiser):') || 'Creative or payment could not be approved.' : '';
    if (status === 'active' && !confirm('Activate this paid campaign now?')) return;
    try { await SkillCloud.reviewCampaign(id, status, note); toast('Campaign updated: ' + status); await loadAdminPanel(); }
    catch (error) { toast(SkillCloud.cleanError(error)); }
  };
  initAdmin();
})();
